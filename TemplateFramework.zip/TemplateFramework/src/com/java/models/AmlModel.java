package com.java.models;

public class AmlModel {
	
	String TPartnerName = "";
	String TPartnerNumber = "";
	String TPartnerItemNumber = "";
	public String getTPartnerName() {
		return TPartnerName;
	}
	public void setTPartnerName(String tPartnerName) {
		TPartnerName = tPartnerName;
	}
	public String getTPartnerNumber() {
		return TPartnerNumber;
	}
	public void setTPartnerNumber(String tPartnerNumber) {
		TPartnerNumber = tPartnerNumber;
	}
	public String getTPartnerItemNumber() {
		return TPartnerItemNumber;
	}
	public void setTPartnerItemNumber(String tPartnerItemNumber) {
		TPartnerItemNumber = tPartnerItemNumber;
	}
}
