package com.java.models;

public class ItemModel {

	String itemNumber ;
	String itemDescription;
	String itemClass;
     String itemId;
     String itemTitleBox;
     String itemLifeCycle;
     String itemRevision;
	
	public String getItemRevision() {
		return itemRevision;
	}
	public void setItemRevision(String itemRevision) {
		this.itemRevision = itemRevision;
	}
	public String getItemLifeCycle() {
		return itemLifeCycle;
	}
	public void setItemLifeCycle(String itemLifeCycle) {
		this.itemLifeCycle = itemLifeCycle;
	}
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getItemTitleBox() {
		return itemTitleBox;
	}
	public void setItemTitleBox(String itemTitleBox) {
		this.itemTitleBox = itemTitleBox;
	}
	public String getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	public String getItemClass() {
		return itemClass;
	}
	public void setItemClass(String itemClass) {
		this.itemClass = itemClass;
	}
	
	
	
	
}
