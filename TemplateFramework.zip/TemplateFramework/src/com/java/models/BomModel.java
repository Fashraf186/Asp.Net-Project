package com.java.models;

public class BomModel {
	
 String BomBillId = "";
 
 String BomOrgCode = "";
 
 String BomCommonNumber = "";
 
 String BomComponent = "";
 
 String BomComponentNumber = "";

public String getBomComponent() {
	return BomComponent;
}

public void setBomComponent(String bomComponent) {
	BomComponent = bomComponent;
}

public String getBomComponentNumber() {
	return BomComponentNumber;
}

public void setBomComponentNumber(String bomComponentNumber) {
	BomComponentNumber = bomComponentNumber;
}

public String getBomBillId() {
	return BomBillId;
}

public void setBomBillId(String bomBillId) {
	BomBillId = bomBillId;
}

public String getBomOrgCode() {
	return BomOrgCode;
}

public void setBomOrgCode(String bomOrgCode) {
	BomOrgCode = bomOrgCode;
}

public String getBomCommonNumber() {
	return BomCommonNumber;
}

public void setBomCommonNumber(String bomCommonNumber) {
	BomCommonNumber = bomCommonNumber;
}
	
}
