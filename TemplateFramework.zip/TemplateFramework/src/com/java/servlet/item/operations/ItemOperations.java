package com.java.servlet.item.operations;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;

import org.json.simple.JSONObject;

import com.google.gson.Gson;
import com.java.models.AmlModel;
import com.java.models.BomModel;
import com.java.models.ItemModel;
import com.oracle.xmlns.adf.svc.types.Conjunction;
import com.oracle.xmlns.adf.svc.types.DataObjectResult;
import com.oracle.xmlns.adf.svc.types.FindControl;
import com.oracle.xmlns.adf.svc.types.FindCriteria;
import com.oracle.xmlns.adf.svc.types.ViewCriteria;
import com.oracle.xmlns.adf.svc.types.ViewCriteriaItem;
import com.oracle.xmlns.adf.svc.types.ViewCriteriaRow;
import com.oracle.xmlns.apps.scm.productmodel.items.itemrelationshipservice.ItemRelationshipService;
import com.oracle.xmlns.apps.scm.productmodel.items.itemrelationshipservice.TradingPartnerItemCrossReference;
import com.oracle.xmlns.apps.scm.productmodel.items.itemservicev2.Item;
import com.oracle.xmlns.apps.scm.productmodel.items.itemservicev2.ItemRevision;
import com.oracle.xmlns.apps.scm.productmodel.items.itemservicev2.ItemService;
import com.oracle.xmlns.apps.scm.productmodel.items.itemservicev2.ServiceException;
import com.oracle.xmlns.apps.scm.productmodel.items.structures.structureservicev2.Component;
import com.oracle.xmlns.apps.scm.productmodel.items.structures.structureservicev2.ComponentResult;
import com.oracle.xmlns.apps.scm.productmodel.items.structures.structureservicev2.Pack;
import com.oracle.xmlns.apps.scm.productmodel.items.structures.structureservicev2.PackResult;
import com.oracle.xmlns.apps.scm.productmodel.items.structures.structureservicev2.Structure;
import com.oracle.xmlns.apps.scm.productmodel.items.structures.structureservicev2.StructureResult;
import com.oracle.xmlns.apps.scm.productmodel.items.structures.structureservicev2.StructureService;

import jdk.internal.dynalink.support.BottomGuardingDynamicLinker;

/**
 * Servlet implementation class ItemOperations
 */
@WebServlet("/ItemOperations")
public class ItemOperations extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		JSONObject responseObject = new JSONObject();
		String action = null;
		try {			
			JSONObject params = GenericUtils.getParamsFromRequest(request);
			action = params.get("action").toString();
			
			Method method = ItemOperations.class.getDeclaredMethod(action, JSONObject.class);
			Object[] parameters = new Object[1];
			parameters[0] = params;
			responseObject = (JSONObject) method.invoke(this, parameters);
			
		} catch (NoSuchMethodException nsmex) {
			//it catches exception occure during above written reflection code
			responseObject.put("status", "error");
			responseObject.put("message", "Invalid action: " + action);
		} catch (InvocationTargetException itex) {
			//this will catch the exact exception occure in below methods
			Throwable ex = itex.getTargetException();
			String msg = ex != null ? ex.getMessage(): "Null";
			responseObject.put("status", "error");
			responseObject.put("message", msg);
			ex.printStackTrace();
		} catch (Throwable ex) {
			//this will catch generic exception
			String msg = ex != null ? ex.getMessage(): "Null";
			responseObject.put("status", "error");
			responseObject.put("message", msg);
			ex.printStackTrace();
		}
		
		String jsonResponse = new Gson().toJson(responseObject);

		response.setContentType("application/json");
		response.getWriter().println(jsonResponse);
	}
	
	 public static ItemService getItemServicePort(final String WSDL_URL, final String NAMESPACE, final String SERVICE_NAME, final String USER, final String PASSWORD) throws MalformedURLException {	
		 URL wsdlLocation = new URL(WSDL_URL);
		 QName serviceName = new QName(NAMESPACE, SERVICE_NAME);

		 Service service = Service.create(wsdlLocation, serviceName);
		 ItemService port = service.getPort(ItemService.class);

		 BindingProvider provider = (BindingProvider) port;
		 provider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, USER);
		 provider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, PASSWORD);

		 return port;
		 }
	 
	 
	 public static StructureService getBomServicePort(final String WSDL_URL, final String NAMESPACE, final String SERVICE_NAME, final String USER, final String PASSWORD) throws MalformedURLException {	
		 URL wsdlLocation = new URL(WSDL_URL);
		 QName serviceName = new QName(NAMESPACE, SERVICE_NAME);

		 Service service = Service.create(wsdlLocation, serviceName);
		 StructureService portbom = service.getPort(StructureService.class);

		 BindingProvider provider = (BindingProvider) portbom;
		 provider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, USER);
		 provider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, PASSWORD);

		 return portbom;
		 }
	 
	 public static ItemRelationshipService getAmlServicePort(final String WSDL_URL, final String NAMESPACE, final String SERVICE_NAME, final String USER, final String PASSWORD) throws MalformedURLException {	
		 URL wsdlLocation = new URL(WSDL_URL);
		 QName serviceName = new QName(NAMESPACE, SERVICE_NAME);

		 Service service = Service.create(wsdlLocation, serviceName);
		 ItemRelationshipService portaml = service.getPort(ItemRelationshipService.class);

		 BindingProvider provider = (BindingProvider) portaml;
		 provider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, USER);
		 provider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, PASSWORD);

		 return portaml;
		 }
	 
	 
/******************************Item Operation Function to Find Item ************************************************************************************/
	 
		@SuppressWarnings({ "unchecked", "unused" })
		private JSONObject itemOperation(JSONObject params) throws MalformedURLException, ServiceException {

			JSONObject responseObject = new JSONObject();
			responseObject.put("status", "success");
			
			ItemService is = ItemOperations.getItemServicePort(
					"https://eerr-test.fs.us6.oraclecloud.com/fscmService/ItemServiceV2?WSDL",
					"http://xmlns.oracle.com/apps/scm/productModel/items/itemServiceV2/", "ItemService",
					"tnelson@xavor.com", "CloudR17D@Video1");
			
			
			FindCriteria findCriteria = new FindCriteria();
			FindControl findControl = new FindControl();

			ViewCriteriaItem item = new ViewCriteriaItem();
			ViewCriteriaItem item2 = new ViewCriteriaItem();
			ViewCriteria filter = new ViewCriteria();
			ViewCriteriaRow group = new ViewCriteriaRow();
			
			String res_item =  params.get("item_name").toString();
			
			item.setAttribute("ItemNumber");
			item.setOperator("CONTAINS");
			item.getValue().add( res_item );
			
		    item.setConjunction(Conjunction.OR);
			
			item2.setAttribute("ItemDescription");
			item2.setOperator("CONTAINS");
			item2.getValue().add( res_item );
			
			group.getItem().add(item);
			group.getItem().add(item2);
			
			filter.getGroup().add(group);
			
			
			findCriteria.setFilter(filter);
			
			
			findCriteria.setFetchSize(500);
			findCriteria.setFetchStart(0);
			
			DataObjectResult dataObjectResult =  is.findItem(findCriteria, findControl);
			List<Object> itemList =  dataObjectResult.getValue();
			List<ItemModel> itemModelList = new ArrayList<>();
	
			for(Object i :  itemList) {
				
			Item it = (Item) i; 
			ItemModel itemModel = new ItemModel();
			itemModel.setItemNumber(it.getItemNumber().getValue());
			itemModel.setItemDescription(it.getItemDescription());
			itemModel.setItemClass(it.getItemClass().getValue());
		
			itemModelList.add(itemModel);
            System.out.println(it.getItemClass().getValue());
			}
			
			responseObject.put("items",itemModelList);

			return responseObject;
		}	 
		
/**********************************************************************************************************************************************************/
		
/******************************************* ITEM DETAILS ****************************************************************/
		
/**********************************************************************************************************************************************************/
		
		
/*		private JSONObject itemdetails(JSONObject params) throws MalformedURLException, ServiceException {

			JSONObject responseObject = new JSONObject();
			responseObject.put("status", "success");
			
			String res_item = "";
			
			ItemService is = ItemOperations.getItemServicePort(
					"https://eerr-test.fs.us6.oraclecloud.com/fscmService/ItemServiceV2?WSDL",
					"http://xmlns.oracle.com/apps/scm/productModel/items/itemServiceV2/", "ItemService",
					"tnelson@xavor.com", "CloudR17D@Video1");
			
			
			FindCriteria findCriteria = new FindCriteria();
			FindControl findControl = new FindControl();

			ViewCriteriaItem item = new ViewCriteriaItem();
			ViewCriteriaItem item2 = new ViewCriteriaItem();
			ViewCriteria filter = new ViewCriteria();
			ViewCriteriaRow group = new ViewCriteriaRow();
			
			 res_item =  params.get("item_Id").toString();
			
			
			 System.out.println(res_item);
		
			 
			item.setAttribute("ItemNumber");
			item.setOperator("=");
			item.getValue().add( res_item );
			
			item.setConjunction(Conjunction.OR);
			
			item2.setAttribute("ItemDescription");
			item2.setOperator("=");
			item2.getValue().add( res_item );
			
			group.getItem().add(item);
			group.getItem().add(item2);
			
			filter.getGroup().add(group);
			
			
			findCriteria.setFilter(filter);
			
			
			findCriteria.setFetchSize(500);
			findCriteria.setFetchStart(0);
			
			DataObjectResult dataObjectResult =  is.findItem(findCriteria, findControl);
			List<Object> itemList =  dataObjectResult.getValue();
		
			
			List<ItemModel> itemModelDetails = new ArrayList<>();
			
//			List<String> opt = new  ArrayList<>();
//			List<String> Des = new  ArrayList<>();
			
			for(Object i :  itemList) {
				
				Item it = (Item) i; 
				ItemModel itemDetails = new ItemModel();
				itemModel.setItemNumber(it.getItemNumber().getValue());
				itemModel.setItemDescription(it.getItemDescription());
				itemModel.setItemClass(it.getItemClass().getValue());
				itemDetails.setitemId(it.getItemId().toString());
				itemDetails.setItemTitleBox(it.getOrganizationCode().getValue());
				
				itemModelDetails.add(itemDetails);
				
//				String itemNumber =  it.getItemNumber().getValue();
//			
//	            
//	            Des.add(it.getItemDescription());
//	            
//			    opt.add(itemNumber);
//				
			System.out.println(it.getItemId() + "item details");
			
//				responseObject.put("Item_Number", opt);
//				responseObject.put("Des_Number", Des);
			}
			
			responseObject.put("itemsdetails",itemModelDetails);
			//
			System.out.println("there we are 1");
			
			String item =  params.get("item_name").toString();
			
			System.out.println(item);
			
			ViewCriteria filter = new ViewCriteria();
			ViewCriteriaRow group = new ViewCriteriaRow();
			ViewCriteriaItem item1 = new ViewCriteriaItem();
		
			FindItem find_item = new FindItem();
			
			FindCriteria find_citerm =  find_item.getFindCriteria();
			FindControl  find_contrl = find_item.getFindControl();
 			
			
			find_citerm.setFetchStart(0);
			find_citerm.setFetchSize(1);
			
			find_contrl.setRetrieveAllTranslations(false);
	        
		     FindItemResponse fitem = new  FindItemResponse() ;
		     
		    DataObjectResult res = fitem.getResult();
		    
		      Item ires = (Item) res.getValue();
		      
		      ires.getItemId();
		   
		   
		    		
			 System.out.println(ires.getItemId());
			 
			
		//	  FindItemResponse res = new FindItemResponse();
			
			
	
			 
			//39020000
			
			
	 
			responseObject.put("BranchCode", dt.getBic());
			responseObject.put("BranchName ", dt.getBezeichnung());
			responseObject.put("BranchCity", dt.getOrt());
			responseObject.put("BranchScode",  dt.getPlz());

			
			
				try{
					result = firstOperand / secondOperand;
				}catch (Exception ex) {
					String msg = ex != null ? ex.getMessage(): "Null";
					responseObject.put("status", "error");
					responseObject.put("message", msg);
					ex.printStackTrace();
				}
				
			
		
			
			
			responseObject.put("result", result);
			
			return responseObject;
		}	
		
		*//**
		 * @throws com.oracle.xmlns.apps.scm.productmodel.items.structures.structureservicev2.ServiceException ***********************************************************************************************//*
		
		@SuppressWarnings({ "unchecked", "unused" })
		private JSONObject bomOperation(JSONObject params) throws MalformedURLException, ServiceException, com.oracle.xmlns.apps.scm.productmodel.items.structures.structureservicev2.ServiceException {

			System.out.println("Bom start");
			
			JSONObject responseObject = new JSONObject();
			responseObject.put("status", "success");
			
			StructureService ss = ItemOperations.getBomServicePort(
					"https://eerr-test.fs.us6.oraclecloud.com/fscmService/StructureServiceV2?WSDL",
					"http://xmlns.oracle.com/apps/scm/productModel/items/structures/structureServiceV2/", "StructureService",
					"tnelson@xavor.com", "CloudR17D@Video1");
			
			System.out.println("Bom 0");
		
			
			
			FindCriteria findCriteria = new FindCriteria();
			FindControl findControl = new FindControl();
			
			ViewCriteriaItem Bom = new ViewCriteriaItem();
		
			ViewCriteria filter = new ViewCriteria();
			ViewCriteriaRow group = new ViewCriteriaRow();
			
			
	
			String res_item =  params.get("item_Id").toString();
			
			System.out.println("Bom 1");
			
		
			System.out.println(res_item);
			
			
			Bom.setAttribute("ItemNumber");
			Bom.setOperator("=");
			Bom.getValue().add( res_item );
			
			group.getItem().add(Bom);
		
			
			filter.getGroup().add(group);
			
			
			findCriteria.setFilter(filter);
			
			
			findCriteria.setFetchSize(50);
			findCriteria.setFetchStart(2);
			
			System.out.println("Bom 2");
			


			
			StructureResult StructureObjectResult	= ss.findStructure(findCriteria, findControl);
			
		
			List<Structure> bomList = StructureObjectResult.getValue();
			
			List<BomModel> BomModelList = new ArrayList<>();
			
			
			
			for(Structure i :  bomList) 
			{
				
				Structure it = i;
				
				BomModel bomModel = new BomModel();
				
			     
			
			     System.out.println("Bom 3");
			     
				bomModel.setBomBillId(it.getBillSequenceId().toString());
				bomModel.setBomOrgCode(it.getOrganizationCode().getValue());
				bomModel.setBomCommonNumber(it.getCommonItemNumber().getValue());
				
				
	
				
				System.out.println(it.getBillSequenceId().toString() + "BILL");
				System.out.println(it.getCommonOrganizationCode().getValue() + "Org");
				System.out.println(it.getCommonItemNumber().getValue() + "Item Number");
				BomModelList.add(bomModel);
				System.out.println("Bom 4");
		
				
			}
			
			System.out.println("Bom 5");
			responseObject.put("BomsDetails",BomModelList);

			
			return responseObject;
		}
		
		
		*//***********************************************************************************************************************//*
		
		private JSONObject amlOperation(JSONObject params) throws MalformedURLException, ServiceException, com.oracle.xmlns.apps.scm.productmodel.items.structures.structureservicev2.ServiceException, com.oracle.xmlns.apps.scm.productmodel.items.itemrelationshipservice.ServiceException {

			System.out.println("Bom start");
			
			JSONObject responseObject = new JSONObject();
			responseObject.put("status", "success");
			
			ItemRelationshipService irs = ItemOperations.getAmlServicePort(
					"https://eerr-test.fs.us6.oraclecloud.com/fscmService/ItemRelationshipService?WSDL",
					"http://xmlns.oracle.com/apps/scm/productModel/items/itemRelationshipService/", "ItemRelationshipService",
					"tnelson@xavor.com", "CloudR17D@Video1");
			
			System.out.println("aml 0");
		
			
			
			FindCriteria findCriteria = new FindCriteria();
			FindControl findControl = new FindControl();
			
			ViewCriteriaItem Aml = new ViewCriteriaItem();
		
			ViewCriteria filter = new ViewCriteria();
			ViewCriteriaRow group = new ViewCriteriaRow();
			
			
	
			String res_item =  params.get("item_Id").toString();
			
			System.out.println("aml 1");
			
		
			System.out.println(res_item);
			
			
			Aml.setAttribute("ItemNumber");
			Aml.setOperator("=");
			Aml.getValue().add( res_item );
			
			group.getItem().add(Aml);
		
			
			filter.getGroup().add(group);
			
			
			findCriteria.setFilter(filter);
			
			
			findCriteria.setFetchSize(50);
			findCriteria.setFetchStart(0);
			
			System.out.println("aml 2");
			


			
			DataObjectResult dataObjectResult	= irs.findTradingPartnerItemRelationship(findCriteria, findControl);		
		
			List<Object> amlList = dataObjectResult.getValue();
			
			List<AmlModel> AmlModelList = new ArrayList<>();
		
			
			
			for(Object i : amlList) 
			{
				
				TradingPartnerItemCrossReference it =  (TradingPartnerItemCrossReference) i;
				
				AmlModel amlModel = new AmlModel();
				
			    
				  
				 amlModel.setTPartnerName(it.getTradingPartnerName().getValue()); 
				  amlModel.setTPartnerItemNumber(it.getTradingPartnerItemNumber().getValue());
				  amlModel.setTPartnerNumber(it.getTradingPartnerNumber().getValue());
				  
			
			     System.out.println(it.getTradingPartnerNumber().getValue());
			     
		      AmlModelList.add(amlModel);
				
					
	
				
				//System.out.println(it.getBillSequenceId().toString() + "BOM");
				System.out.println("aml 4");
		
				
			}
			
			System.out.println("Bom 5");
			responseObject.put("AmlsDetails",AmlModelList);

			
			return responseObject;
		}
		
*//**********************************************************************************************************************************************************//*
*//******************************************* ITEM DETAILS ****************************************************************//*
				
*//**********************************************************************************************************************************************************//*
				
				
				private JSONObject itemdes(JSONObject params) throws MalformedURLException, ServiceException {

					JSONObject responseObject = new JSONObject();
					responseObject.put("status", "success");
					
					String edit_item = "";
					
					ItemService is = ItemOperations.getItemServicePort(
							"https://eerr-test.fs.us6.oraclecloud.com/fscmService/ItemServiceV2?WSDL",
							"http://xmlns.oracle.com/apps/scm/productModel/items/itemServiceV2/", "ItemService",
							"tnelson@xavor.com", "CloudR17D@Video1");
					
					
					FindCriteria findCriteria = new FindCriteria();
					FindControl findControl = new FindControl();

					ViewCriteriaItem item = new ViewCriteriaItem();
					ViewCriteriaItem item2 = new ViewCriteriaItem();
					ViewCriteria filter = new ViewCriteria();
					ViewCriteriaRow group = new ViewCriteriaRow();
					
					edit_item =  params.get("Edit_item").toString();
					
				     Item itemDes = new Item();
					
					 System.out.println(edit_item);
				
					 itemDes.
					 
					 itemDes.setAttribute("ItemNumber");
					 itemDes.setOperator("CONTAINS");
					 itemDes.getValue().add( res_item );
						
					 itemDes.setConjunction(Conjunction.OR);
						
					 itemDes.setAttribute("ItemDescription");
					 itemDes.setOperator("CONTAINS");
					 itemDes.getValue().add( res_item );
					 
					 
					itemDes.setItemDescription(edit_item);
					
					
					
					group.getItem().add(item);
				
					
					filter.getGroup().add(group);
					
					
					findCriteria.setFilter(filter);
					
					
					findCriteria.setFetchSize(50);
					findCriteria.setFetchStart(0);
					
					DataObjectResult dataObjectResult =  is.findItem(findCriteria, findControl);
					List<Object> itemList =  dataObjectResult.getValue();
				
				
					
				    is.updateItem(itemDes);
				    
				    if( is.updateItem(itemDes).equals(true)) {
				    	
				    	responseObject.put("result", itemDes);
				    }
				    
					
					List<ItemModel> itemModelDetails = new ArrayList<>();
					
//					List<String> opt = new  ArrayList<>();
//					List<String> Des = new  ArrayList<>();
					
					for(Object i :  itemList) {
						
						Item it = (Item) i; 
						ItemModel itemDetails = new ItemModel();
						itemModel.setItemNumber(it.getItemNumber().getValue());
						itemModel.setItemDescription(it.getItemDescription());
						itemModel.setItemClass(it.getItemClass().getValue());
						itemDetails.setItemId(it.getItemId());
						itemDetails.setItemTitleBox(it.getOrganizationCode().getValue());
						
						itemModelDetails.add(itemDetails);
						
//						String itemNumber =  it.getItemNumber().getValue();
//					
//			            
//			            Des.add(it.getItemDescription());
//			            
//					    opt.add(itemNumber);
//						
					System.out.println(it.getItemId() + "item details");
					
//						responseObject.put("Item_Number", opt);
//						responseObject.put("Des_Number", Des);
					}
					
					responseObject.put("itemsdetails",itemModelDetails);
					//
					System.out.println("there we are 1");
					
					String item =  params.get("item_name").toString();
					
					System.out.println(item);
					
					ViewCriteria filter = new ViewCriteria();
					ViewCriteriaRow group = new ViewCriteriaRow();
					ViewCriteriaItem item1 = new ViewCriteriaItem();
				
					FindItem find_item = new FindItem();
					
					FindCriteria find_citerm =  find_item.getFindCriteria();
					FindControl  find_contrl = find_item.getFindControl();
		 			
					
					find_citerm.setFetchStart(0);
					find_citerm.setFetchSize(1);
					
					find_contrl.setRetrieveAllTranslations(false);
			        
				     FindItemResponse fitem = new  FindItemResponse() ;
				     
				    DataObjectResult res = fitem.getResult();
				    
				      Item ires = (Item) res.getValue();
				      
				      ires.getItemId();
				   
				   
				    		
					 System.out.println(ires.getItemId());
					 
					
				//	  FindItemResponse res = new FindItemResponse();
					
					
			
					 
					//39020000
					
					
			 
					responseObject.put("BranchCode", dt.getBic());
					responseObject.put("BranchName ", dt.getBezeichnung());
					responseObject.put("BranchCity", dt.getOrt());
					responseObject.put("BranchScode",  dt.getPlz());

					
					
						try{
							result = firstOperand / secondOperand;
						}catch (Exception ex) {
							String msg = ex != null ? ex.getMessage(): "Null";
							responseObject.put("status", "error");
							responseObject.put("message", msg);
							ex.printStackTrace();
						}
						
					
				
					
					
					responseObject.put("result", result);
					
					return responseObject;
				}*/	
				
/**********************************************************************************************************************************************************/
/*******************************************     Find Item & BOM & AML               ****************************************************************/
/************************************************Item Data Function ************************************************************************************/								

   private JSONObject ItemData(JSONObject params) throws MalformedURLException, ServiceException, com.oracle.xmlns.apps.scm.productmodel.items.structures.structureservicev2.ServiceException, com.oracle.xmlns.apps.scm.productmodel.items.itemrelationshipservice.ServiceException { 
	   JSONObject responseObject = new JSONObject();
		responseObject.put("status", "success");
		
		String res_item = "";
		
		ItemService is = ItemOperations.getItemServicePort(
				"https://eerr-test.fs.us6.oraclecloud.com/fscmService/ItemServiceV2?WSDL",
				"http://xmlns.oracle.com/apps/scm/productModel/items/itemServiceV2/", "ItemService",
				"tnelson@xavor.com", "CloudR17D@Video1");
		
		
		FindCriteria findCriteria = new FindCriteria();
		FindControl findControl = new FindControl();

		ViewCriteriaItem item = new ViewCriteriaItem();
		ViewCriteriaItem item2 = new ViewCriteriaItem();
		ViewCriteria filter = new ViewCriteria();
		ViewCriteriaRow group = new ViewCriteriaRow();
		
		 res_item =  params.get("item_Id").toString();
		
		
		 System.out.println(res_item);
	
		 
		item.setAttribute("ItemNumber");
		item.setOperator("=");
		item.getValue().add(  res_item );
		
	/*	item.setConjunction(Conjunction.OR);
		
		item2.setAttribute("ItemDescription");
		item2.setOperator("=");
		item2.getValue().add( res_item );*/
		
		group.getItem().add(item);
	//	group.getItem().add(item2);
		
		filter.getGroup().add(group);
		
		
		findCriteria.setFilter(filter);
		
		
		findCriteria.setFetchSize(100);
		findCriteria.setFetchStart(0);
		
		DataObjectResult dataObjectResult =  is.findItem(findCriteria, findControl);
		List<Object> itemList =  dataObjectResult.getValue();
	
		
		List<ItemModel> itemModelDetails = new ArrayList<>();
		
		List<ItemRevision> itemRevision = new ArrayList<>();
		
		ItemModel itemDetails = new ItemModel();

		for(Object i :  itemList) {
			
		Item it = (Item) i; 
		
	
		
		itemDetails.setItemNumber(it.getItemNumber().getValue());
		
		//itemDetails.setItemTitleBox(it.getOrganizationCode().getValue());
		
		itemDetails.setItemLifeCycle(it.getLifecyclePhaseValue().getValue());
		itemDetails.setItemTitleBox(it.getOrganizationId().toString());
		
		itemRevision = it.getItemRevision();
		
		
		responseObject.put("itemNumber",it.getItemNumber().getValue());
		responseObject.put("itemLifeCycle",it.getLifecyclePhaseValue().getValue());
		responseObject.put("itemOrgId",it.getOrganizationId().toString());
	
		for(ItemRevision ir :  itemRevision) 
		{
		
		ItemRevision rt = ir;
		
	
		itemDetails.setItemRevision(rt.getRevisionId().toString());
		
	
		     
		responseObject.put("itemRevision",rt.getRevisionCode());
		
		System.out.println("item 3");
			
		}


		System.out.println(it.getItemId() + "item details");
		}
		
		
		//itemModelDetails.add(itemDetails);

		
		//responseObject.put("itemsdetails",itemModelDetails);

/***************************************************************************************************************************************************/
/**********************************************BOM DETAILS******************************************************************************************/
/****************************************************************************************************************************************************/
		
		
		StructureService ss = ItemOperations.getBomServicePort(
				"https://eerr-test.fs.us6.oraclecloud.com/fscmService/StructureServiceV2?WSDL",
				"http://xmlns.oracle.com/apps/scm/productModel/items/structures/structureServiceV2/", "StructureService",
				"tnelson@xavor.com", "CloudR17D@Video1");
		
		System.out.println("Bom 0");
	
		
		
		FindCriteria findCriteriabom = new FindCriteria();
		FindControl findControlbom = new FindControl();
		
		ViewCriteriaItem Bom = new ViewCriteriaItem();
	
		ViewCriteria filterbom = new ViewCriteria();
		ViewCriteriaRow groupbom = new ViewCriteriaRow();
		
		

		String res_itembom =  params.get("item_Id").toString();
		
	
		System.out.println(res_item);
		
		
		Bom.setAttribute("ItemNumber");
		Bom.setOperator("=");
		Bom.getValue().add( res_itembom );
		
		
		groupbom.getItem().add(Bom);
	
		
		filterbom.getGroup().add(groupbom);
		
		
		findCriteriabom.setFilter(filterbom);
		
		
		findCriteriabom.setFetchSize(500);
		findCriteriabom.setFetchStart(0);
		
		System.out.println("Bom 2");
		


		
		StructureResult StructureObjectResult	= ss.findStructure(findCriteriabom, findControlbom);
		
	
		
		List<Structure> bomList = StructureObjectResult.getValue();
		
	
			
		List<BomModel> BomModelList = new ArrayList<>();
		
		
		
		List<Component> BomcList = new ArrayList<>();
		
		
		
		
		for(Structure i :  bomList) 
		{
			BomModel bomModel = new BomModel();
		Structure it = i;

		System.out.println("Bom 3");
		    
		bomModel.setBomBillId(it.getBillSequenceId().toString());
		bomModel.setBomOrgCode(it.getOrganizationCode().getValue());
		bomModel.setBomCommonNumber(it.getCommonItemNumber().getValue());
		
		BomcList = it.getComponent();
/*
		System.out.println(it.getBillSequenceId().toString() + "BILL");
		System.out.println(it.getCommonOrganizationCode().getValue() + "Org");
		System.out.println(it.getCommonItemNumber().getValue() + "Item Number");

		System.out.println("Bom 4");

		BomModelList.add(bomModel);*/
		
		}
		
		for(Component c :  BomcList) 
		{
		BomModel bomModel = new BomModel();
		BomModel bomModelComp = new BomModel();
			
		Component ct = c;
			
		
		bomModel.setBomComponent(ct.getComponentItemNumber().getValue());
		bomModel.setBomComponentNumber(ct.getComponentSequenceId().toString());     
		System.out.println(ct.getComponentSequenceId().toString() + "Org");
		System.out.println(ct.getComponentItemNumber().getValue() + "Item Number");
		System.out.println("Bom 001");
		
		BomModelList.add(bomModel);		
		}
		
	
		
	
		
		System.out.println("Bom 5");
		responseObject.put("BomsDetails",BomModelList);
		
		
/***************************************************************************************************************************************************/
/**********************************************AML DETAILS******************************************************************************************/
/****************************************************************************************************************************************************/
						
		
/*		ItemRelationshipService irs = ItemOperations.getAmlServicePort(
				"https://eerr-test.fs.us6.oraclecloud.com/fscmService/ItemRelationshipService?WSDL",
				"http://xmlns.oracle.com/apps/scm/productModel/items/itemRelationshipService/", "ItemRelationshipService",
				"tnelson@xavor.com", "CloudR17D@Video1");
		
		System.out.println("aml 0");
	
		FindCriteria findCriteriaaml = new FindCriteria();
		FindControl findControlaml = new FindControl();
		
		ViewCriteriaItem Aml = new ViewCriteriaItem();
	
		ViewCriteria filteraml = new ViewCriteria();
		ViewCriteriaRow groupaml = new ViewCriteriaRow();	

		String res_itemaml =  params.get("item_Id").toString();
		
		System.out.println("aml 1");

		System.out.println(res_itemaml);
		
		Aml.setAttribute("ItemNumber");
		Aml.setOperator("=");
		Aml.getValue().add( res_itemaml );
		
		groupaml.getItem().add(Aml);

		filteraml.getGroup().add(groupaml);

		findCriteriaaml.setFilter(filteraml);
	
		findCriteriaaml.setFetchSize(500);
		findCriteriaaml.setFetchStart(0);
		
		System.out.println("aml 2");

		DataObjectResult dataObjectResultaml	= irs.findTradingPartnerItemRelationship(findCriteriaaml, findControlaml);		
	
		List<Object> amlList = dataObjectResultaml.getValue();
		
		List<AmlModel> AmlModelList = new ArrayList<>();
	
		
		
		for(Object i : amlList) 
		{
			
		TradingPartnerItemCrossReference it =  (TradingPartnerItemCrossReference) i;
			
		AmlModel amlModel = new AmlModel();
	  
		amlModel.setTPartnerName(it.getTradingPartnerName().getValue()); 
		amlModel.setTPartnerItemNumber(it.getTradingPartnerItemNumber().getValue());
        amlModel.setTPartnerNumber(it.getTradingPartnerNumber().getValue());
			  
		
		System.out.println(it.getTradingPartnerNumber().getValue());
		     
	    AmlModelList.add(amlModel);
	
		//System.out.println(it.getBillSequenceId().toString() + "BOM");
	    System.out.println("aml 4");
	
		}

		responseObject.put("AmlsDetails",AmlModelList);*/
		
		return responseObject;
       
   }
		

}
