
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.EnvironmentalGovernanceAndComp;


/**
 * <p>Java class for j_ItemRootIccPrivate complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="j_ItemRootIccPrivate">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}j_ItemEffCategory">
 *       &lt;sequence>
 *         &lt;element name="ItemEFFBEnvironmentalGovernanceAndCompPrivateVO" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}EnvironmentalGovernanceAndComp" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "j_ItemRootIccPrivate", propOrder = {
    "itemEFFBEnvironmentalGovernanceAndCompPrivateVO"
})
@XmlSeeAlso({
    IngredientN.class,
    ZtestItemClass.class,
    Cto.class,
    KitFg.class,
    ItemSku.class,
    Folder.class,
    Chemical.class,
    FilleGoodssa.class,
    SubstanceGroup.class,
    TestAttributesClass.class,
    Component.class,
    HoverBoard.class,
    PackageAssembly.class,
    PartFamily.class,
    EquipmentFixturesTools.class,
    Fg.class,
    PartParent.class,
    DocumentParent.class,
    Declaration.class,
    Substance.class,
    Specification.class,
    Fbom.class,
    Part.class,
    FinishedGood.class,
    Document.class
})
public class JItemRootIccPrivate
    extends JItemEffCategory
{

    @XmlElement(name = "ItemEFFBEnvironmentalGovernanceAndCompPrivateVO")
    protected EnvironmentalGovernanceAndComp itemEFFBEnvironmentalGovernanceAndCompPrivateVO;

    /**
     * Gets the value of the itemEFFBEnvironmentalGovernanceAndCompPrivateVO property.
     * 
     * @return
     *     possible object is
     *     {@link EnvironmentalGovernanceAndComp }
     *     
     */
    public EnvironmentalGovernanceAndComp getItemEFFBEnvironmentalGovernanceAndCompPrivateVO() {
        return itemEFFBEnvironmentalGovernanceAndCompPrivateVO;
    }

    /**
     * Sets the value of the itemEFFBEnvironmentalGovernanceAndCompPrivateVO property.
     * 
     * @param value
     *     allowed object is
     *     {@link EnvironmentalGovernanceAndComp }
     *     
     */
    public void setItemEFFBEnvironmentalGovernanceAndCompPrivateVO(EnvironmentalGovernanceAndComp value) {
        this.itemEFFBEnvironmentalGovernanceAndCompPrivateVO = value;
    }

}
