
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.itemsupplier.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Clinical complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Clinical">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemSupplier/categories/}Regulatorysubmission">
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Clinical")
@XmlSeeAlso({
    EfficacyAndSafety.class,
    HumanPharmacokineticPkStudies.class,
    BiopharmaceuticStudyReports.class,
    HumanPharmacodynamicPd.class,
    OtherStudyReports.class,
    LiteratureReferences.class,
    AnalysisOfDataFromMoreThanOneS.class,
    Summaries.class
})
public class Clinical
    extends Regulatorysubmission
{


}
