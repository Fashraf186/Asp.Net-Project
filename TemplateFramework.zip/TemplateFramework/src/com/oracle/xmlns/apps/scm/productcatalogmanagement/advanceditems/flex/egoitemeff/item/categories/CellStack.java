
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.CellStackSection;


/**
 * <p>Java class for CellStack complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CellStack">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Battery">
 *       &lt;sequence>
 *         &lt;element name="CellStackSection" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}CellStackSection" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CellStack", propOrder = {
    "cellStackSection"
})
public class CellStack
    extends Battery
{

    @XmlElement(name = "CellStackSection")
    protected CellStackSection cellStackSection;

    /**
     * Gets the value of the cellStackSection property.
     * 
     * @return
     *     possible object is
     *     {@link CellStackSection }
     *     
     */
    public CellStackSection getCellStackSection() {
        return cellStackSection;
    }

    /**
     * Sets the value of the cellStackSection property.
     * 
     * @param value
     *     allowed object is
     *     {@link CellStackSection }
     *     
     */
    public void setCellStackSection(CellStackSection value) {
        this.cellStackSection = value;
    }

}
