
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.QualityInformationDetails;


/**
 * <p>Java class for QualityInformation complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="QualityInformation">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Quality">
 *       &lt;sequence>
 *         &lt;element name="QualityInformationDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}QualityInformationDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "QualityInformation", propOrder = {
    "qualityInformationDetails"
})
public class QualityInformation
    extends Quality
{

    @XmlElement(name = "QualityInformationDetails")
    protected QualityInformationDetails qualityInformationDetails;

    /**
     * Gets the value of the qualityInformationDetails property.
     * 
     * @return
     *     possible object is
     *     {@link QualityInformationDetails }
     *     
     */
    public QualityInformationDetails getQualityInformationDetails() {
        return qualityInformationDetails;
    }

    /**
     * Sets the value of the qualityInformationDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link QualityInformationDetails }
     *     
     */
    public void setQualityInformationDetails(QualityInformationDetails value) {
        this.qualityInformationDetails = value;
    }

}
