
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BiopharmaceuticStudyReports complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BiopharmaceuticStudyReports">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Clinical">
 *       &lt;sequence>
 *         &lt;element name="BiopharmaceuticStudyReports" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}BiopharmaceuticStudyReports" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BiopharmaceuticStudyReports", propOrder = {
    "biopharmaceuticStudyReports"
})
public class BiopharmaceuticStudyReports
    extends Clinical
{

    @XmlElement(name = "BiopharmaceuticStudyReports")
    protected com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.BiopharmaceuticStudyReports biopharmaceuticStudyReports;

    /**
     * Gets the value of the biopharmaceuticStudyReports property.
     * 
     * @return
     *     possible object is
     *     {@link com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.BiopharmaceuticStudyReports }
     *     
     */
    public com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.BiopharmaceuticStudyReports getBiopharmaceuticStudyReports() {
        return biopharmaceuticStudyReports;
    }

    /**
     * Sets the value of the biopharmaceuticStudyReports property.
     * 
     * @param value
     *     allowed object is
     *     {@link com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.BiopharmaceuticStudyReports }
     *     
     */
    public void setBiopharmaceuticStudyReports(com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.BiopharmaceuticStudyReports value) {
        this.biopharmaceuticStudyReports = value;
    }

}
