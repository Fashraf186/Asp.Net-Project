
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.EfficacyAndSafetyDetails;


/**
 * <p>Java class for EfficacyAndSafety complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EfficacyAndSafety">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Clinical">
 *       &lt;sequence>
 *         &lt;element name="EfficacyAndSafetyDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}EfficacyAndSafetyDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EfficacyAndSafety", propOrder = {
    "efficacyAndSafetyDetails"
})
public class EfficacyAndSafety
    extends Clinical
{

    @XmlElement(name = "EfficacyAndSafetyDetails")
    protected EfficacyAndSafetyDetails efficacyAndSafetyDetails;

    /**
     * Gets the value of the efficacyAndSafetyDetails property.
     * 
     * @return
     *     possible object is
     *     {@link EfficacyAndSafetyDetails }
     *     
     */
    public EfficacyAndSafetyDetails getEfficacyAndSafetyDetails() {
        return efficacyAndSafetyDetails;
    }

    /**
     * Sets the value of the efficacyAndSafetyDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link EfficacyAndSafetyDetails }
     *     
     */
    public void setEfficacyAndSafetyDetails(EfficacyAndSafetyDetails value) {
        this.efficacyAndSafetyDetails = value;
    }

}
