
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.UltrasoundScanners;


/**
 * <p>Java class for C7Microconvex complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="C7Microconvex">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Fbom">
 *       &lt;sequence>
 *         &lt;element name="UltrasoundScanners" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}UltrasoundScanners" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "C7Microconvex", propOrder = {
    "ultrasoundScanners"
})
public class C7Microconvex
    extends Fbom
{

    @XmlElement(name = "UltrasoundScanners")
    protected UltrasoundScanners ultrasoundScanners;

    /**
     * Gets the value of the ultrasoundScanners property.
     * 
     * @return
     *     possible object is
     *     {@link UltrasoundScanners }
     *     
     */
    public UltrasoundScanners getUltrasoundScanners() {
        return ultrasoundScanners;
    }

    /**
     * Sets the value of the ultrasoundScanners property.
     * 
     * @param value
     *     allowed object is
     *     {@link UltrasoundScanners }
     *     
     */
    public void setUltrasoundScanners(UltrasoundScanners value) {
        this.ultrasoundScanners = value;
    }

}
