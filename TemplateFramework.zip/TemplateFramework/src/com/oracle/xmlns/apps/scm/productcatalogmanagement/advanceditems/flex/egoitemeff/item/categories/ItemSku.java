
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.StyleSKU;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.UnitProperties;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.VariantProperties;


/**
 * <p>Java class for ItemSku complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ItemSku">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}j_ItemRootIccPrivate">
 *       &lt;sequence>
 *         &lt;element name="UnitProperties" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}UnitProperties" minOccurs="0"/>
 *         &lt;element name="VariantProperties" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}VariantProperties" minOccurs="0"/>
 *         &lt;element name="StyleSKU" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}StyleSKU" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ItemSku", propOrder = {
    "unitProperties",
    "variantProperties",
    "styleSKU"
})
public class ItemSku
    extends JItemRootIccPrivate
{

    @XmlElement(name = "UnitProperties")
    protected UnitProperties unitProperties;
    @XmlElement(name = "VariantProperties")
    protected VariantProperties variantProperties;
    @XmlElement(name = "StyleSKU")
    protected StyleSKU styleSKU;

    /**
     * Gets the value of the unitProperties property.
     * 
     * @return
     *     possible object is
     *     {@link UnitProperties }
     *     
     */
    public UnitProperties getUnitProperties() {
        return unitProperties;
    }

    /**
     * Sets the value of the unitProperties property.
     * 
     * @param value
     *     allowed object is
     *     {@link UnitProperties }
     *     
     */
    public void setUnitProperties(UnitProperties value) {
        this.unitProperties = value;
    }

    /**
     * Gets the value of the variantProperties property.
     * 
     * @return
     *     possible object is
     *     {@link VariantProperties }
     *     
     */
    public VariantProperties getVariantProperties() {
        return variantProperties;
    }

    /**
     * Sets the value of the variantProperties property.
     * 
     * @param value
     *     allowed object is
     *     {@link VariantProperties }
     *     
     */
    public void setVariantProperties(VariantProperties value) {
        this.variantProperties = value;
    }

    /**
     * Gets the value of the styleSKU property.
     * 
     * @return
     *     possible object is
     *     {@link StyleSKU }
     *     
     */
    public StyleSKU getStyleSKU() {
        return styleSKU;
    }

    /**
     * Sets the value of the styleSKU property.
     * 
     * @param value
     *     allowed object is
     *     {@link StyleSKU }
     *     
     */
    public void setStyleSKU(StyleSKU value) {
        this.styleSKU = value;
    }

}
