
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.CellSection;


/**
 * <p>Java class for Cell complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Cell">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Battery">
 *       &lt;sequence>
 *         &lt;element name="CellSection" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}CellSection" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Cell", propOrder = {
    "cellSection"
})
public class Cell
    extends Battery
{

    @XmlElement(name = "CellSection")
    protected CellSection cellSection;

    /**
     * Gets the value of the cellSection property.
     * 
     * @return
     *     possible object is
     *     {@link CellSection }
     *     
     */
    public CellSection getCellSection() {
        return cellSection;
    }

    /**
     * Sets the value of the cellSection property.
     * 
     * @param value
     *     allowed object is
     *     {@link CellSection }
     *     
     */
    public void setCellSection(CellSection value) {
        this.cellSection = value;
    }

}
