
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.DhfDetails;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.StyleSKU;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.WizardDetails;


/**
 * <p>Java class for IngredientN complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="IngredientN">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}j_ItemRootIccPrivate">
 *       &lt;sequence>
 *         &lt;element name="DhfDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}DhfDetails" minOccurs="0"/>
 *         &lt;element name="WizardDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}WizardDetails" minOccurs="0"/>
 *         &lt;element name="StyleSKU" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}StyleSKU" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IngredientN", propOrder = {
    "dhfDetails",
    "wizardDetails",
    "styleSKU"
})
public class IngredientN
    extends JItemRootIccPrivate
{

    @XmlElement(name = "DhfDetails")
    protected DhfDetails dhfDetails;
    @XmlElement(name = "WizardDetails")
    protected WizardDetails wizardDetails;
    @XmlElement(name = "StyleSKU")
    protected StyleSKU styleSKU;

    /**
     * Gets the value of the dhfDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DhfDetails }
     *     
     */
    public DhfDetails getDhfDetails() {
        return dhfDetails;
    }

    /**
     * Sets the value of the dhfDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DhfDetails }
     *     
     */
    public void setDhfDetails(DhfDetails value) {
        this.dhfDetails = value;
    }

    /**
     * Gets the value of the wizardDetails property.
     * 
     * @return
     *     possible object is
     *     {@link WizardDetails }
     *     
     */
    public WizardDetails getWizardDetails() {
        return wizardDetails;
    }

    /**
     * Sets the value of the wizardDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link WizardDetails }
     *     
     */
    public void setWizardDetails(WizardDetails value) {
        this.wizardDetails = value;
    }

    /**
     * Gets the value of the styleSKU property.
     * 
     * @return
     *     possible object is
     *     {@link StyleSKU }
     *     
     */
    public StyleSKU getStyleSKU() {
        return styleSKU;
    }

    /**
     * Sets the value of the styleSKU property.
     * 
     * @param value
     *     allowed object is
     *     {@link StyleSKU }
     *     
     */
    public void setStyleSKU(StyleSKU value) {
        this.styleSKU = value;
    }

}
