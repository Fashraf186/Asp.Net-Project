
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.FgAttribute;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.TestGroup;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.TestGroup1;


/**
 * <p>Java class for FinishedGood complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FinishedGood">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}j_ItemRootIccPrivate">
 *       &lt;sequence>
 *         &lt;element name="FgAttribute" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}FgAttribute" minOccurs="0"/>
 *         &lt;element name="TestGroup1" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}TestGroup1" minOccurs="0"/>
 *         &lt;element name="TestGroup" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}TestGroup" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FinishedGood", propOrder = {
    "fgAttribute",
    "testGroup1",
    "testGroup"
})
@XmlSeeAlso({
    ChangeOrder.class
})
public class FinishedGood
    extends JItemRootIccPrivate
{

    @XmlElement(name = "FgAttribute")
    protected FgAttribute fgAttribute;
    @XmlElement(name = "TestGroup1")
    protected TestGroup1 testGroup1;
    @XmlElement(name = "TestGroup")
    protected TestGroup testGroup;

    /**
     * Gets the value of the fgAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link FgAttribute }
     *     
     */
    public FgAttribute getFgAttribute() {
        return fgAttribute;
    }

    /**
     * Sets the value of the fgAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link FgAttribute }
     *     
     */
    public void setFgAttribute(FgAttribute value) {
        this.fgAttribute = value;
    }

    /**
     * Gets the value of the testGroup1 property.
     * 
     * @return
     *     possible object is
     *     {@link TestGroup1 }
     *     
     */
    public TestGroup1 getTestGroup1() {
        return testGroup1;
    }

    /**
     * Sets the value of the testGroup1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link TestGroup1 }
     *     
     */
    public void setTestGroup1(TestGroup1 value) {
        this.testGroup1 = value;
    }

    /**
     * Gets the value of the testGroup property.
     * 
     * @return
     *     possible object is
     *     {@link TestGroup }
     *     
     */
    public TestGroup getTestGroup() {
        return testGroup;
    }

    /**
     * Sets the value of the testGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link TestGroup }
     *     
     */
    public void setTestGroup(TestGroup value) {
        this.testGroup = value;
    }

}
