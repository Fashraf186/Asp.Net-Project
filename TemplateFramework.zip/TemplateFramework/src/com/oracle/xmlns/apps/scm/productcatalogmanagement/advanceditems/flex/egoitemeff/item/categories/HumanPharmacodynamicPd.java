
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.HumanPharmacodynamicPdDetail;


/**
 * <p>Java class for HumanPharmacodynamicPd complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="HumanPharmacodynamicPd">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Clinical">
 *       &lt;sequence>
 *         &lt;element name="HumanPharmacodynamicPdDetail" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}HumanPharmacodynamicPdDetail" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "HumanPharmacodynamicPd", propOrder = {
    "humanPharmacodynamicPdDetail"
})
public class HumanPharmacodynamicPd
    extends Clinical
{

    @XmlElement(name = "HumanPharmacodynamicPdDetail")
    protected HumanPharmacodynamicPdDetail humanPharmacodynamicPdDetail;

    /**
     * Gets the value of the humanPharmacodynamicPdDetail property.
     * 
     * @return
     *     possible object is
     *     {@link HumanPharmacodynamicPdDetail }
     *     
     */
    public HumanPharmacodynamicPdDetail getHumanPharmacodynamicPdDetail() {
        return humanPharmacodynamicPdDetail;
    }

    /**
     * Sets the value of the humanPharmacodynamicPdDetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link HumanPharmacodynamicPdDetail }
     *     
     */
    public void setHumanPharmacodynamicPdDetail(HumanPharmacodynamicPdDetail value) {
        this.humanPharmacodynamicPdDetail = value;
    }

}
