
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.DhfDetails;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.DieItemDetails;


/**
 * <p>Java class for Newdhf complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Newdhf">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Document">
 *       &lt;sequence>
 *         &lt;element name="DieItemDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}DieItemDetails" minOccurs="0"/>
 *         &lt;element name="DhfDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}DhfDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Newdhf", propOrder = {
    "dieItemDetails",
    "dhfDetails"
})
public class Newdhf
    extends Document
{

    @XmlElement(name = "DieItemDetails")
    protected DieItemDetails dieItemDetails;
    @XmlElement(name = "DhfDetails")
    protected DhfDetails dhfDetails;

    /**
     * Gets the value of the dieItemDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DieItemDetails }
     *     
     */
    public DieItemDetails getDieItemDetails() {
        return dieItemDetails;
    }

    /**
     * Sets the value of the dieItemDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DieItemDetails }
     *     
     */
    public void setDieItemDetails(DieItemDetails value) {
        this.dieItemDetails = value;
    }

    /**
     * Gets the value of the dhfDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DhfDetails }
     *     
     */
    public DhfDetails getDhfDetails() {
        return dhfDetails;
    }

    /**
     * Sets the value of the dhfDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DhfDetails }
     *     
     */
    public void setDhfDetails(DhfDetails value) {
        this.dhfDetails = value;
    }

}
