
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.LiteratureReferenceDetails;


/**
 * <p>Java class for LiteratureReference complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LiteratureReference">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Quality">
 *       &lt;sequence>
 *         &lt;element name="LiteratureReferenceDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}LiteratureReferenceDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LiteratureReference", propOrder = {
    "literatureReferenceDetails"
})
public class LiteratureReference
    extends Quality
{

    @XmlElement(name = "LiteratureReferenceDetails")
    protected LiteratureReferenceDetails literatureReferenceDetails;

    /**
     * Gets the value of the literatureReferenceDetails property.
     * 
     * @return
     *     possible object is
     *     {@link LiteratureReferenceDetails }
     *     
     */
    public LiteratureReferenceDetails getLiteratureReferenceDetails() {
        return literatureReferenceDetails;
    }

    /**
     * Sets the value of the literatureReferenceDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link LiteratureReferenceDetails }
     *     
     */
    public void setLiteratureReferenceDetails(LiteratureReferenceDetails value) {
        this.literatureReferenceDetails = value;
    }

}
