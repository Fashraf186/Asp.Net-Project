
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.PCBSpecsDetails;


/**
 * <p>Java class for PCBSpecs complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PCBSpecs">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Document">
 *       &lt;sequence>
 *         &lt;element name="PCBSpecsDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}PCBSpecsDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PCBSpecs", propOrder = {
    "pcbSpecsDetails"
})
public class PCBSpecs
    extends Document
{

    @XmlElement(name = "PCBSpecsDetails")
    protected PCBSpecsDetails pcbSpecsDetails;

    /**
     * Gets the value of the pcbSpecsDetails property.
     * 
     * @return
     *     possible object is
     *     {@link PCBSpecsDetails }
     *     
     */
    public PCBSpecsDetails getPCBSpecsDetails() {
        return pcbSpecsDetails;
    }

    /**
     * Sets the value of the pcbSpecsDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link PCBSpecsDetails }
     *     
     */
    public void setPCBSpecsDetails(PCBSpecsDetails value) {
        this.pcbSpecsDetails = value;
    }

}
