
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ExternalDocumentDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "externalDocumentDetails");
    private final static QName _PCBSpecsDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "pCBSpecsDetails");
    private final static QName _MedicalDeviceDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "medicalDeviceDetails");
    private final static QName _EnvironmentalGovernanceAndComp_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "environmentalGovernanceAndComp");
    private final static QName _TestAttributes_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "testAttributes");
    private final static QName _QualityInformationDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "qualityInformationDetails");
    private final static QName _FgAttribute_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "fgAttribute");
    private final static QName _CellSection_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "cellSection");
    private final static QName _Kit_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "kit");
    private final static QName _AgileWizardDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "agileWizardDetails");
    private final static QName _DrugSubstanceDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "drugSubstanceDetails");
    private final static QName _LiteratureReferenceDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "literatureReferenceDetails");
    private final static QName _Details_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "details");
    private final static QName _ZtestGroup_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "ztestGroup");
    private final static QName _SOPDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "sOPDetails");
    private final static QName _FilledGoodDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "filledGoodDetails");
    private final static QName _StyleSKU_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "styleSKU");
    private final static QName _InternalDocumentDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "internalDocumentDetails");
    private final static QName _TestGroup1_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "testGroup1");
    private final static QName _DrugProductDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "drugProductDetails");
    private final static QName _AssemblyInstructions_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "assemblyInstructions");
    private final static QName _COMPResistorDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "cOMPResistorDetails");
    private final static QName _AdventitiousAgentsDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "adventitiousAgentsDetails");
    private final static QName _MultiRow_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "multiRow");
    private final static QName _DocumentsDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "documentsDetails");
    private final static QName _BiopharmaceuticStudyReports_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "biopharmaceuticStudyReports");
    private final static QName _QualityOverallSummaryDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "qualityOverallSummaryDetails");
    private final static QName _SOPDocumentDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "sOPDocumentDetails");
    private final static QName _DhfDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "dhfDetails");
    private final static QName _ToxicologyStudyReportsDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "toxicologyStudyReportsDetails");
    private final static QName _FormulaDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "formulaDetails");
    private final static QName _SocketDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "socketDetails");
    private final static QName _SummariesDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "summariesDetails");
    private final static QName _AnalysesOfDataFromMoreThanOneS_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "analysesOfDataFromMoreThanOneS");
    private final static QName _WizardDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "wizardDetails");
    private final static QName _TransistorFETDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "transistorFETDetails");
    private final static QName _UnitProperties_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "unitProperties");
    private final static QName _DmrDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "dmrDetails");
    private final static QName _LiteratureReferencesDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "literatureReferencesDetails");
    private final static QName _VariantProperties_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "variantProperties");
    private final static QName _DieItemDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "dieItemDetails");
    private final static QName _AdministrativeInformationDetai_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "administrativeInformationDetai");
    private final static QName _SOPProcedureDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "sOPProcedureDetails");
    private final static QName _ApplicantInformationDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "applicantInformationDetails");
    private final static QName _TestGroup_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "testGroup");
    private final static QName _DmrSection_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "dmrSection");
    private final static QName _HumanPharmacodynamicPdDetail_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "humanPharmacodynamicPdDetail");
    private final static QName _ModuleDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "moduleDetails");
    private final static QName _LabelingDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "labelingDetails");
    private final static QName _OtherStudyReportsDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "otherStudyReportsDetails");
    private final static QName _SMSDocumentDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "sMSDocumentDetails");
    private final static QName _COMPCapacitorALTantalumDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "cOMPCapacitorALTantalumDetails");
    private final static QName _PartsDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "partsDetails");
    private final static QName _HumanPharmacokineticPkStudies_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "humanPharmacokineticPkStudies");
    private final static QName _MarketRestrictions_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "marketRestrictions");
    private final static QName _DatasheetsDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "datasheetsDetails");
    private final static QName _HbAttributesGroup_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "hbAttributesGroup");
    private final static QName _Comments_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "comments");
    private final static QName _ComponentDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "componentDetails");
    private final static QName _EfficacyAndSafetyDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "efficacyAndSafetyDetails");
    private final static QName _UltrasoundScanners_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "ultrasoundScanners");
    private final static QName _CellStackSection_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "cellStackSection");
    private final static QName _ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "IsAddedToChildEntitiesMap");
    private final static QName _ApplicantInformationDetailsRedLineprojectName_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineprojectName");
    private final static QName _ApplicantInformationDetailsRaiseEvent_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RaiseEvent");
    private final static QName _ApplicantInformationDetailsSubGroup_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "subGroup");
    private final static QName _ApplicantInformationDetailsBulkloadRecCreated_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "BulkloadRecCreated");
    private final static QName _ApplicantInformationDetailsIsImportCase_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "IsImportCase");
    private final static QName _ApplicantInformationDetailsRedLinesubGroup_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinesubGroup");
    private final static QName _ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "IsPersistentAttributeUpdated");
    private final static QName _ApplicantInformationDetailsProjectName_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "projectName");
    private final static QName _CellSectionSize_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "size");
    private final static QName _CellSectionMaterial_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "material");
    private final static QName _CellSectionVoltage_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "voltage");
    private final static QName _CellSectionRedLinematerial_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinematerial");
    private final static QName _CellSectionRedLinesize_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinesize");
    private final static QName _CellSectionRedLinevoltage_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinevoltage");
    private final static QName _WizardDetailsIsTemplate_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "IsTemplate");
    private final static QName _WizardDetailsRedLineWizardStatus_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineWizardStatus");
    private final static QName _WizardDetailsWizardStatus_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "WizardStatus");
    private final static QName _WizardDetailsRedLineIsTemplate_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineIsTemplate");
    private final static QName _DatasheetsDetailsExternalDocumentTitle_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "ExternalDocumentTitle");
    private final static QName _DatasheetsDetailsExternalDocumentNumber_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "ExternalDocumentNumber");
    private final static QName _DatasheetsDetailsExternalDocumentRev_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "ExternalDocumentRev");
    private final static QName _DatasheetsDetailsRedLineExternalDocumentTitle_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineExternalDocumentTitle");
    private final static QName _DatasheetsDetailsRedLineExternalDocumentRev_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineExternalDocumentRev");
    private final static QName _DatasheetsDetailsRedLineExternalDocumentNumber_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineExternalDocumentNumber");
    private final static QName _DetailsSystem_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "system");
    private final static QName _DetailsRedLinestorageConditions_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinestorageConditions");
    private final static QName _DetailsMaterialCompositionChemicalPro_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "materialCompositionChemicalPro");
    private final static QName _DetailsDocumentsToSendToVendor_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "documentsToSendToVendor");
    private final static QName _DetailsRedLineother_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineother");
    private final static QName _DetailsRedLinesystem_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinesystem");
    private final static QName _DetailsOther_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "other");
    private final static QName _DetailsRedLinematerialCompositionChemicalPro_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinematerialCompositionChemicalPro");
    private final static QName _DetailsRedLinesupplierCode_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinesupplierCode");
    private final static QName _DetailsSupplierCode_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "supplierCode");
    private final static QName _DetailsStorageConditions_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "storageConditions");
    private final static QName _DetailsRedLinedocumentsToSendToVendor_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinedocumentsToSendToVendor");
    private final static QName _HbAttributesGroupRedLinematerialCostDisplay_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinematerialCost_Display");
    private final static QName _HbAttributesGroupNumberOfPages_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "numberOfPages");
    private final static QName _HbAttributesGroupRedLinenumberOfPages_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinenumberOfPages");
    private final static QName _HbAttributesGroupMaterialCost_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "materialCost");
    private final static QName _HbAttributesGroupMaterialCostDisplay_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "materialCost_Display");
    private final static QName _HbAttributesGroupRedLinematerialCost_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinematerialCost");
    private final static QName _SocketDetailsApprovers_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "Approvers");
    private final static QName _SocketDetailsReviewers_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "Reviewers");
    private final static QName _SocketDetailsRedLineReviewers_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineReviewers");
    private final static QName _SocketDetailsRedLineApprovers_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineApprovers");
    private final static QName _SocketDetailsRedLineAcknowledgers_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineAcknowledgers");
    private final static QName _SocketDetailsAcknowledgers_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "Acknowledgers");
    private final static QName _VariantPropertiesRedLinecolor_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinecolor");
    private final static QName _VariantPropertiesColor_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "color");
    private final static QName _FilledGoodDetailsData_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "data");
    private final static QName _FilledGoodDetailsLabel_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "label");
    private final static QName _FilledGoodDetailsRedLinelabel_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinelabel");
    private final static QName _FilledGoodDetailsRedLinedata_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinedata");
    private final static QName _PCBSpecsDetailsDepartmentGroup2_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "DepartmentGroup2");
    private final static QName _PCBSpecsDetailsDepartmentGroup1_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "DepartmentGroup1");
    private final static QName _PCBSpecsDetailsDepartmentGroup3_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "DepartmentGroup3");
    private final static QName _PCBSpecsDetailsRedLineDepartmentGroup2_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineDepartmentGroup2");
    private final static QName _PCBSpecsDetailsRedLineAccountTypes_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineAccountTypes");
    private final static QName _PCBSpecsDetailsRedLineDepartmentGroup3_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineDepartmentGroup3");
    private final static QName _PCBSpecsDetailsRedLineDepartmentGroup1_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineDepartmentGroup1");
    private final static QName _PCBSpecsDetailsRedLineDocumentCategory_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineDocumentCategory");
    private final static QName _PCBSpecsDetailsRedLineRecordDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineRecordDetails");
    private final static QName _PCBSpecsDetailsRecordDetails_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RecordDetails");
    private final static QName _PCBSpecsDetailsDocumentCategory_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "DocumentCategory");
    private final static QName _PCBSpecsDetailsAccountTypes_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "AccountTypes");
    private final static QName _ComponentDetailsRedLinestatus_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinestatus");
    private final static QName _ComponentDetailsStatus_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "status");
    private final static QName _SOPProcedureDetailsCategory_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "Category");
    private final static QName _SOPProcedureDetailsRedLineNotes_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineNotes");
    private final static QName _SOPProcedureDetailsRedLineCategory_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineCategory");
    private final static QName _SOPProcedureDetailsNotes_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "Notes");
    private final static QName _CellStackSectionRedLinetotalPowerAh_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinetotalPowerAh");
    private final static QName _CellStackSectionNumberOfCells_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "numberOfCells");
    private final static QName _CellStackSectionTotalPowerAh_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "totalPowerAh");
    private final static QName _CellStackSectionRedLinenumberOfCells_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinenumberOfCells");
    private final static QName _UltrasoundScannersRedLinewebManagementPortal_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinewebManagementPortal");
    private final static QName _UltrasoundScannersPowerDoppler_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "powerDoppler");
    private final static QName _UltrasoundScannersColorDoppler_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "colorDoppler");
    private final static QName _UltrasoundScannersRedLinecolorDoppler_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinecolorDoppler");
    private final static QName _UltrasoundScannersNeedleEnhancement_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "needleEnhancement");
    private final static QName _UltrasoundScannersRedLinevirtualLinear_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinevirtualLinear");
    private final static QName _UltrasoundScannersRedLineneedleEnhancement_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineneedleEnhancement");
    private final static QName _UltrasoundScannersVirtualLinear_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "virtualLinear");
    private final static QName _UltrasoundScannersRedLinepulsedWaveDoppler_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinepulsedWaveDoppler");
    private final static QName _UltrasoundScannersWebManagementPortal_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "webManagementPortal");
    private final static QName _UltrasoundScannersRedLinedicom_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinedicom");
    private final static QName _UltrasoundScannersPulsedWaveDoppler_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "pulsedWaveDoppler");
    private final static QName _UltrasoundScannersDicom_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "dicom");
    private final static QName _UltrasoundScannersRedLinepowerDoppler_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinepowerDoppler");
    private final static QName _ModuleDetailsText1_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "text1");
    private final static QName _ModuleDetailsText_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "text");
    private final static QName _ModuleDetailsRedLinetext_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinetext");
    private final static QName _ModuleDetailsRedLinetext1_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinetext1");
    private final static QName _DmrDetailsDmrDescription_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "dmrDescription");
    private final static QName _DmrDetailsRedLinedeviceName_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinedeviceName");
    private final static QName _DmrDetailsRedLinedmrDescription_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinedmrDescription");
    private final static QName _DmrDetailsRedLinefinishedGoodNumber_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinefinishedGoodNumber");
    private final static QName _DmrDetailsDhf_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "dhf");
    private final static QName _DmrDetailsRedLinedhf_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinedhf");
    private final static QName _DmrDetailsFinishedGoodNumber_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "finishedGoodNumber");
    private final static QName _DmrDetailsDeviceName_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "deviceName");
    private final static QName _DieItemDetailsRedLinechangeType_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinechangeType");
    private final static QName _DieItemDetailsBaseDevice_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "baseDevice");
    private final static QName _DieItemDetailsDieDeviceVersion_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "dieDeviceVersion");
    private final static QName _DieItemDetailsChangeType_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "changeType");
    private final static QName _DieItemDetailsRedLinebaseDevice_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinebaseDevice");
    private final static QName _DieItemDetailsRedLinedieDeviceVersion_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinedieDeviceVersion");
    private final static QName _KitSegment_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "segment");
    private final static QName _KitRedLinekitSize_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinekitSize");
    private final static QName _KitRedLinesegment_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinesegment");
    private final static QName _KitKitSize_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "kitSize");
    private final static QName _TestGroupTestAttribute_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "testAttribute");
    private final static QName _TestGroupRedLinetestAttribute_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinetestAttribute");
    private final static QName _CommentsRedLinecommentNotes_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinecommentNotes");
    private final static QName _CommentsRedLinecommentId_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinecommentId");
    private final static QName _CommentsRedLinecreatedOn_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinecreatedOn");
    private final static QName _CommentsCommentId_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "commentId");
    private final static QName _CommentsCommentNotes_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "commentNotes");
    private final static QName _CommentsCreatedOn_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "createdOn");
    private final static QName _PartsDetailsRedLineEBSOrg_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineEBSOrg");
    private final static QName _PartsDetailsItemCost_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "ItemCost");
    private final static QName _PartsDetailsBaseID_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "BaseID");
    private final static QName _PartsDetailsRedLineItemCost_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineItemCost");
    private final static QName _PartsDetailsRedLineBaseID_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineBaseID");
    private final static QName _PartsDetailsEBSOrg_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "EBSOrg");
    private final static QName _DocumentsDetailsRedLineDocCategory_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineDocCategory");
    private final static QName _DocumentsDetailsRedLineBusinessUnit_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineBusinessUnit");
    private final static QName _DocumentsDetailsBusinessUnit_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "BusinessUnit");
    private final static QName _DocumentsDetailsDateofActivation_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "DateofActivation");
    private final static QName _DocumentsDetailsDocCategory_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "DocCategory");
    private final static QName _DocumentsDetailsRedLineDateofActivation_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineDateofActivation");
    private final static QName _FgAttributeRedLinetestCycle_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinetestCycle");
    private final static QName _FgAttributeRedLinesku_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinesku");
    private final static QName _FgAttributeRedLinesampleText_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinesampleText");
    private final static QName _FgAttributeTestCycle_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "testCycle");
    private final static QName _FgAttributeRedLinesampleList_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinesampleList");
    private final static QName _FgAttributeSampleText_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "sampleText");
    private final static QName _FgAttributeSampleList_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "sampleList");
    private final static QName _AgileWizardDetailsRedLineAssignmentComments_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineAssignmentComments");
    private final static QName _AgileWizardDetailsRedLineCurrentScreen_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineCurrentScreen");
    private final static QName _AgileWizardDetailsCurrentScreen_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "CurrentScreen");
    private final static QName _AgileWizardDetailsAssignmentComments_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "AssignmentComments");
    private final static QName _TestAttributesRedLinesubsetList_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinesubsetList");
    private final static QName _TestAttributesIndependentValues_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "independentValues");
    private final static QName _TestAttributesFormatonly_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "formatonly");
    private final static QName _TestAttributesRedLineindependentValues_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineindependentValues");
    private final static QName _TestAttributesRedLineformatonly_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineformatonly");
    private final static QName _TestAttributesDependentList_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "dependentList");
    private final static QName _TestAttributesSubsetList_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "subsetList");
    private final static QName _TestAttributesRedLinedependentList_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinedependentList");
    private final static QName _EnvironmentalGovernanceAndCompRedLinedeclarationStatus_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinedeclarationStatus");
    private final static QName _EnvironmentalGovernanceAndCompDeclarationStatus_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "declarationStatus");
    private final static QName _DmrSectionRedLinedmrSection_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinedmrSection");
    private final static QName _AssemblyInstructionsRedLineassemblyInstructions_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineassemblyInstructions");
    private final static QName _AssemblyInstructionsAttribute_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "attribute");
    private final static QName _AssemblyInstructionsRedLineattribute_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineattribute");
    private final static QName _AssemblyInstructionsTest_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "test");
    private final static QName _AssemblyInstructionsRedLinetest_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinetest");
    private final static QName _TransistorFETDetailsRedLineTransistorType_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineTransistorType");
    private final static QName _TransistorFETDetailsRedLineIsBipolar_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineIsBipolar");
    private final static QName _TransistorFETDetailsTransistorType_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "TransistorType");
    private final static QName _TransistorFETDetailsIsBipolar_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "IsBipolar");
    private final static QName _DhfDetailsRedLineapprovalFunctions_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineapprovalFunctions");
    private final static QName _DhfDetailsApprovalFunctions_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "approvalFunctions");
    private final static QName _DhfDetailsRedLinecomments_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinecomments");
    private final static QName _MultiRowRedLinespecs_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinespecs");
    private final static QName _ZtestGroupRedLineztest2_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineztest2");
    private final static QName _ZtestGroupRedLineSurfaceMountDeviceSAP_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineSurfaceMountDeviceSAP");
    private final static QName _ZtestGroupZtest2_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "ztest2");
    private final static QName _ZtestGroupRedLineztest3_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineztest3");
    private final static QName _ZtestGroupZtest3_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "ztest3");
    private final static QName _ZtestGroupSurfaceMountDeviceSAP_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "SurfaceMountDeviceSAP");
    private final static QName _FormulaDetailsUnit_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "unit");
    private final static QName _FormulaDetailsRedLineunit_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineunit");
    private final static QName _FormulaDetailsOwnership_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "ownership");
    private final static QName _FormulaDetailsState_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "state");
    private final static QName _FormulaDetailsName_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "name");
    private final static QName _FormulaDetailsRedLinestate_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinestate");
    private final static QName _FormulaDetailsRedLineownership_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLineownership");
    private final static QName _FormulaDetailsRedLinename_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", "RedLinename");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SOPProcedureDetails }
     * 
     */
    public SOPProcedureDetails createSOPProcedureDetails() {
        return new SOPProcedureDetails();
    }

    /**
     * Create an instance of {@link FormulaDetails }
     * 
     */
    public FormulaDetails createFormulaDetails() {
        return new FormulaDetails();
    }

    /**
     * Create an instance of {@link SOPDetails }
     * 
     */
    public SOPDetails createSOPDetails() {
        return new SOPDetails();
    }

    /**
     * Create an instance of {@link DocumentsDetails }
     * 
     */
    public DocumentsDetails createDocumentsDetails() {
        return new DocumentsDetails();
    }

    /**
     * Create an instance of {@link ZtestGroup }
     * 
     */
    public ZtestGroup createZtestGroup() {
        return new ZtestGroup();
    }

    /**
     * Create an instance of {@link COMPCapacitorALTantalumDetails }
     * 
     */
    public COMPCapacitorALTantalumDetails createCOMPCapacitorALTantalumDetails() {
        return new COMPCapacitorALTantalumDetails();
    }

    /**
     * Create an instance of {@link EfficacyAndSafetyDetails }
     * 
     */
    public EfficacyAndSafetyDetails createEfficacyAndSafetyDetails() {
        return new EfficacyAndSafetyDetails();
    }

    /**
     * Create an instance of {@link UltrasoundScanners }
     * 
     */
    public UltrasoundScanners createUltrasoundScanners() {
        return new UltrasoundScanners();
    }

    /**
     * Create an instance of {@link PartsDetails }
     * 
     */
    public PartsDetails createPartsDetails() {
        return new PartsDetails();
    }

    /**
     * Create an instance of {@link UnitProperties }
     * 
     */
    public UnitProperties createUnitProperties() {
        return new UnitProperties();
    }

    /**
     * Create an instance of {@link ComponentDetails }
     * 
     */
    public ComponentDetails createComponentDetails() {
        return new ComponentDetails();
    }

    /**
     * Create an instance of {@link EnvironmentalGovernanceAndComp }
     * 
     */
    public EnvironmentalGovernanceAndComp createEnvironmentalGovernanceAndComp() {
        return new EnvironmentalGovernanceAndComp();
    }

    /**
     * Create an instance of {@link AdministrativeInformationDetai }
     * 
     */
    public AdministrativeInformationDetai createAdministrativeInformationDetai() {
        return new AdministrativeInformationDetai();
    }

    /**
     * Create an instance of {@link TestAttributes }
     * 
     */
    public TestAttributes createTestAttributes() {
        return new TestAttributes();
    }

    /**
     * Create an instance of {@link QualityInformationDetails }
     * 
     */
    public QualityInformationDetails createQualityInformationDetails() {
        return new QualityInformationDetails();
    }

    /**
     * Create an instance of {@link MultiRow }
     * 
     */
    public MultiRow createMultiRow() {
        return new MultiRow();
    }

    /**
     * Create an instance of {@link Details }
     * 
     */
    public Details createDetails() {
        return new Details();
    }

    /**
     * Create an instance of {@link SMSDocumentDetails }
     * 
     */
    public SMSDocumentDetails createSMSDocumentDetails() {
        return new SMSDocumentDetails();
    }

    /**
     * Create an instance of {@link CellStackSection }
     * 
     */
    public CellStackSection createCellStackSection() {
        return new CellStackSection();
    }

    /**
     * Create an instance of {@link HumanPharmacokineticPkStudies }
     * 
     */
    public HumanPharmacokineticPkStudies createHumanPharmacokineticPkStudies() {
        return new HumanPharmacokineticPkStudies();
    }

    /**
     * Create an instance of {@link TestGroup1 }
     * 
     */
    public TestGroup1 createTestGroup1() {
        return new TestGroup1();
    }

    /**
     * Create an instance of {@link DrugProductDetails }
     * 
     */
    public DrugProductDetails createDrugProductDetails() {
        return new DrugProductDetails();
    }

    /**
     * Create an instance of {@link FilledGoodDetails }
     * 
     */
    public FilledGoodDetails createFilledGoodDetails() {
        return new FilledGoodDetails();
    }

    /**
     * Create an instance of {@link BiopharmaceuticStudyReports }
     * 
     */
    public BiopharmaceuticStudyReports createBiopharmaceuticStudyReports() {
        return new BiopharmaceuticStudyReports();
    }

    /**
     * Create an instance of {@link StyleSKU }
     * 
     */
    public StyleSKU createStyleSKU() {
        return new StyleSKU();
    }

    /**
     * Create an instance of {@link InternalDocumentDetails }
     * 
     */
    public InternalDocumentDetails createInternalDocumentDetails() {
        return new InternalDocumentDetails();
    }

    /**
     * Create an instance of {@link FgAttribute }
     * 
     */
    public FgAttribute createFgAttribute() {
        return new FgAttribute();
    }

    /**
     * Create an instance of {@link HumanPharmacodynamicPdDetail }
     * 
     */
    public HumanPharmacodynamicPdDetail createHumanPharmacodynamicPdDetail() {
        return new HumanPharmacodynamicPdDetail();
    }

    /**
     * Create an instance of {@link QualityOverallSummaryDetails }
     * 
     */
    public QualityOverallSummaryDetails createQualityOverallSummaryDetails() {
        return new QualityOverallSummaryDetails();
    }

    /**
     * Create an instance of {@link SOPDocumentDetails }
     * 
     */
    public SOPDocumentDetails createSOPDocumentDetails() {
        return new SOPDocumentDetails();
    }

    /**
     * Create an instance of {@link AnalysesOfDataFromMoreThanOneS }
     * 
     */
    public AnalysesOfDataFromMoreThanOneS createAnalysesOfDataFromMoreThanOneS() {
        return new AnalysesOfDataFromMoreThanOneS();
    }

    /**
     * Create an instance of {@link WizardDetails }
     * 
     */
    public WizardDetails createWizardDetails() {
        return new WizardDetails();
    }

    /**
     * Create an instance of {@link AgileWizardDetails }
     * 
     */
    public AgileWizardDetails createAgileWizardDetails() {
        return new AgileWizardDetails();
    }

    /**
     * Create an instance of {@link TransistorFETDetails }
     * 
     */
    public TransistorFETDetails createTransistorFETDetails() {
        return new TransistorFETDetails();
    }

    /**
     * Create an instance of {@link DhfDetails }
     * 
     */
    public DhfDetails createDhfDetails() {
        return new DhfDetails();
    }

    /**
     * Create an instance of {@link MedicalDeviceDetails }
     * 
     */
    public MedicalDeviceDetails createMedicalDeviceDetails() {
        return new MedicalDeviceDetails();
    }

    /**
     * Create an instance of {@link ModuleDetails }
     * 
     */
    public ModuleDetails createModuleDetails() {
        return new ModuleDetails();
    }

    /**
     * Create an instance of {@link LiteratureReferencesDetails }
     * 
     */
    public LiteratureReferencesDetails createLiteratureReferencesDetails() {
        return new LiteratureReferencesDetails();
    }

    /**
     * Create an instance of {@link DatasheetsDetails }
     * 
     */
    public DatasheetsDetails createDatasheetsDetails() {
        return new DatasheetsDetails();
    }

    /**
     * Create an instance of {@link SocketDetails }
     * 
     */
    public SocketDetails createSocketDetails() {
        return new SocketDetails();
    }

    /**
     * Create an instance of {@link DmrDetails }
     * 
     */
    public DmrDetails createDmrDetails() {
        return new DmrDetails();
    }

    /**
     * Create an instance of {@link CellSection }
     * 
     */
    public CellSection createCellSection() {
        return new CellSection();
    }

    /**
     * Create an instance of {@link ExternalDocumentDetails }
     * 
     */
    public ExternalDocumentDetails createExternalDocumentDetails() {
        return new ExternalDocumentDetails();
    }

    /**
     * Create an instance of {@link ApplicantInformationDetails }
     * 
     */
    public ApplicantInformationDetails createApplicantInformationDetails() {
        return new ApplicantInformationDetails();
    }

    /**
     * Create an instance of {@link Kit }
     * 
     */
    public Kit createKit() {
        return new Kit();
    }

    /**
     * Create an instance of {@link TestGroup }
     * 
     */
    public TestGroup createTestGroup() {
        return new TestGroup();
    }

    /**
     * Create an instance of {@link COMPResistorDetails }
     * 
     */
    public COMPResistorDetails createCOMPResistorDetails() {
        return new COMPResistorDetails();
    }

    /**
     * Create an instance of {@link AssemblyInstructions }
     * 
     */
    public AssemblyInstructions createAssemblyInstructions() {
        return new AssemblyInstructions();
    }

    /**
     * Create an instance of {@link PCBSpecsDetails }
     * 
     */
    public PCBSpecsDetails createPCBSpecsDetails() {
        return new PCBSpecsDetails();
    }

    /**
     * Create an instance of {@link SummariesDetails }
     * 
     */
    public SummariesDetails createSummariesDetails() {
        return new SummariesDetails();
    }

    /**
     * Create an instance of {@link DmrSection }
     * 
     */
    public DmrSection createDmrSection() {
        return new DmrSection();
    }

    /**
     * Create an instance of {@link MarketRestrictions }
     * 
     */
    public MarketRestrictions createMarketRestrictions() {
        return new MarketRestrictions();
    }

    /**
     * Create an instance of {@link OtherStudyReportsDetails }
     * 
     */
    public OtherStudyReportsDetails createOtherStudyReportsDetails() {
        return new OtherStudyReportsDetails();
    }

    /**
     * Create an instance of {@link VariantProperties }
     * 
     */
    public VariantProperties createVariantProperties() {
        return new VariantProperties();
    }

    /**
     * Create an instance of {@link ToxicologyStudyReportsDetails }
     * 
     */
    public ToxicologyStudyReportsDetails createToxicologyStudyReportsDetails() {
        return new ToxicologyStudyReportsDetails();
    }

    /**
     * Create an instance of {@link Comments }
     * 
     */
    public Comments createComments() {
        return new Comments();
    }

    /**
     * Create an instance of {@link AdventitiousAgentsDetails }
     * 
     */
    public AdventitiousAgentsDetails createAdventitiousAgentsDetails() {
        return new AdventitiousAgentsDetails();
    }

    /**
     * Create an instance of {@link DieItemDetails }
     * 
     */
    public DieItemDetails createDieItemDetails() {
        return new DieItemDetails();
    }

    /**
     * Create an instance of {@link LabelingDetails }
     * 
     */
    public LabelingDetails createLabelingDetails() {
        return new LabelingDetails();
    }

    /**
     * Create an instance of {@link DrugSubstanceDetails }
     * 
     */
    public DrugSubstanceDetails createDrugSubstanceDetails() {
        return new DrugSubstanceDetails();
    }

    /**
     * Create an instance of {@link LiteratureReferenceDetails }
     * 
     */
    public LiteratureReferenceDetails createLiteratureReferenceDetails() {
        return new LiteratureReferenceDetails();
    }

    /**
     * Create an instance of {@link HbAttributesGroup }
     * 
     */
    public HbAttributesGroup createHbAttributesGroup() {
        return new HbAttributesGroup();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExternalDocumentDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "externalDocumentDetails")
    public JAXBElement<ExternalDocumentDetails> createExternalDocumentDetails(ExternalDocumentDetails value) {
        return new JAXBElement<ExternalDocumentDetails>(_ExternalDocumentDetails_QNAME, ExternalDocumentDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PCBSpecsDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "pCBSpecsDetails")
    public JAXBElement<PCBSpecsDetails> createPCBSpecsDetails(PCBSpecsDetails value) {
        return new JAXBElement<PCBSpecsDetails>(_PCBSpecsDetails_QNAME, PCBSpecsDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MedicalDeviceDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "medicalDeviceDetails")
    public JAXBElement<MedicalDeviceDetails> createMedicalDeviceDetails(MedicalDeviceDetails value) {
        return new JAXBElement<MedicalDeviceDetails>(_MedicalDeviceDetails_QNAME, MedicalDeviceDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EnvironmentalGovernanceAndComp }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "environmentalGovernanceAndComp")
    public JAXBElement<EnvironmentalGovernanceAndComp> createEnvironmentalGovernanceAndComp(EnvironmentalGovernanceAndComp value) {
        return new JAXBElement<EnvironmentalGovernanceAndComp>(_EnvironmentalGovernanceAndComp_QNAME, EnvironmentalGovernanceAndComp.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TestAttributes }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "testAttributes")
    public JAXBElement<TestAttributes> createTestAttributes(TestAttributes value) {
        return new JAXBElement<TestAttributes>(_TestAttributes_QNAME, TestAttributes.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QualityInformationDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "qualityInformationDetails")
    public JAXBElement<QualityInformationDetails> createQualityInformationDetails(QualityInformationDetails value) {
        return new JAXBElement<QualityInformationDetails>(_QualityInformationDetails_QNAME, QualityInformationDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FgAttribute }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "fgAttribute")
    public JAXBElement<FgAttribute> createFgAttribute(FgAttribute value) {
        return new JAXBElement<FgAttribute>(_FgAttribute_QNAME, FgAttribute.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CellSection }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "cellSection")
    public JAXBElement<CellSection> createCellSection(CellSection value) {
        return new JAXBElement<CellSection>(_CellSection_QNAME, CellSection.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Kit }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "kit")
    public JAXBElement<Kit> createKit(Kit value) {
        return new JAXBElement<Kit>(_Kit_QNAME, Kit.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AgileWizardDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "agileWizardDetails")
    public JAXBElement<AgileWizardDetails> createAgileWizardDetails(AgileWizardDetails value) {
        return new JAXBElement<AgileWizardDetails>(_AgileWizardDetails_QNAME, AgileWizardDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DrugSubstanceDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "drugSubstanceDetails")
    public JAXBElement<DrugSubstanceDetails> createDrugSubstanceDetails(DrugSubstanceDetails value) {
        return new JAXBElement<DrugSubstanceDetails>(_DrugSubstanceDetails_QNAME, DrugSubstanceDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LiteratureReferenceDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "literatureReferenceDetails")
    public JAXBElement<LiteratureReferenceDetails> createLiteratureReferenceDetails(LiteratureReferenceDetails value) {
        return new JAXBElement<LiteratureReferenceDetails>(_LiteratureReferenceDetails_QNAME, LiteratureReferenceDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Details }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "details")
    public JAXBElement<Details> createDetails(Details value) {
        return new JAXBElement<Details>(_Details_QNAME, Details.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ZtestGroup }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "ztestGroup")
    public JAXBElement<ZtestGroup> createZtestGroup(ZtestGroup value) {
        return new JAXBElement<ZtestGroup>(_ZtestGroup_QNAME, ZtestGroup.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SOPDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "sOPDetails")
    public JAXBElement<SOPDetails> createSOPDetails(SOPDetails value) {
        return new JAXBElement<SOPDetails>(_SOPDetails_QNAME, SOPDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FilledGoodDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "filledGoodDetails")
    public JAXBElement<FilledGoodDetails> createFilledGoodDetails(FilledGoodDetails value) {
        return new JAXBElement<FilledGoodDetails>(_FilledGoodDetails_QNAME, FilledGoodDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StyleSKU }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "styleSKU")
    public JAXBElement<StyleSKU> createStyleSKU(StyleSKU value) {
        return new JAXBElement<StyleSKU>(_StyleSKU_QNAME, StyleSKU.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InternalDocumentDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "internalDocumentDetails")
    public JAXBElement<InternalDocumentDetails> createInternalDocumentDetails(InternalDocumentDetails value) {
        return new JAXBElement<InternalDocumentDetails>(_InternalDocumentDetails_QNAME, InternalDocumentDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TestGroup1 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "testGroup1")
    public JAXBElement<TestGroup1> createTestGroup1(TestGroup1 value) {
        return new JAXBElement<TestGroup1>(_TestGroup1_QNAME, TestGroup1 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DrugProductDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "drugProductDetails")
    public JAXBElement<DrugProductDetails> createDrugProductDetails(DrugProductDetails value) {
        return new JAXBElement<DrugProductDetails>(_DrugProductDetails_QNAME, DrugProductDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AssemblyInstructions }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "assemblyInstructions")
    public JAXBElement<AssemblyInstructions> createAssemblyInstructions(AssemblyInstructions value) {
        return new JAXBElement<AssemblyInstructions>(_AssemblyInstructions_QNAME, AssemblyInstructions.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link COMPResistorDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "cOMPResistorDetails")
    public JAXBElement<COMPResistorDetails> createCOMPResistorDetails(COMPResistorDetails value) {
        return new JAXBElement<COMPResistorDetails>(_COMPResistorDetails_QNAME, COMPResistorDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AdventitiousAgentsDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "adventitiousAgentsDetails")
    public JAXBElement<AdventitiousAgentsDetails> createAdventitiousAgentsDetails(AdventitiousAgentsDetails value) {
        return new JAXBElement<AdventitiousAgentsDetails>(_AdventitiousAgentsDetails_QNAME, AdventitiousAgentsDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MultiRow }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "multiRow")
    public JAXBElement<MultiRow> createMultiRow(MultiRow value) {
        return new JAXBElement<MultiRow>(_MultiRow_QNAME, MultiRow.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentsDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "documentsDetails")
    public JAXBElement<DocumentsDetails> createDocumentsDetails(DocumentsDetails value) {
        return new JAXBElement<DocumentsDetails>(_DocumentsDetails_QNAME, DocumentsDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BiopharmaceuticStudyReports }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "biopharmaceuticStudyReports")
    public JAXBElement<BiopharmaceuticStudyReports> createBiopharmaceuticStudyReports(BiopharmaceuticStudyReports value) {
        return new JAXBElement<BiopharmaceuticStudyReports>(_BiopharmaceuticStudyReports_QNAME, BiopharmaceuticStudyReports.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QualityOverallSummaryDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "qualityOverallSummaryDetails")
    public JAXBElement<QualityOverallSummaryDetails> createQualityOverallSummaryDetails(QualityOverallSummaryDetails value) {
        return new JAXBElement<QualityOverallSummaryDetails>(_QualityOverallSummaryDetails_QNAME, QualityOverallSummaryDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SOPDocumentDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "sOPDocumentDetails")
    public JAXBElement<SOPDocumentDetails> createSOPDocumentDetails(SOPDocumentDetails value) {
        return new JAXBElement<SOPDocumentDetails>(_SOPDocumentDetails_QNAME, SOPDocumentDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DhfDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "dhfDetails")
    public JAXBElement<DhfDetails> createDhfDetails(DhfDetails value) {
        return new JAXBElement<DhfDetails>(_DhfDetails_QNAME, DhfDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ToxicologyStudyReportsDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "toxicologyStudyReportsDetails")
    public JAXBElement<ToxicologyStudyReportsDetails> createToxicologyStudyReportsDetails(ToxicologyStudyReportsDetails value) {
        return new JAXBElement<ToxicologyStudyReportsDetails>(_ToxicologyStudyReportsDetails_QNAME, ToxicologyStudyReportsDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FormulaDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "formulaDetails")
    public JAXBElement<FormulaDetails> createFormulaDetails(FormulaDetails value) {
        return new JAXBElement<FormulaDetails>(_FormulaDetails_QNAME, FormulaDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SocketDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "socketDetails")
    public JAXBElement<SocketDetails> createSocketDetails(SocketDetails value) {
        return new JAXBElement<SocketDetails>(_SocketDetails_QNAME, SocketDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SummariesDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "summariesDetails")
    public JAXBElement<SummariesDetails> createSummariesDetails(SummariesDetails value) {
        return new JAXBElement<SummariesDetails>(_SummariesDetails_QNAME, SummariesDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AnalysesOfDataFromMoreThanOneS }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "analysesOfDataFromMoreThanOneS")
    public JAXBElement<AnalysesOfDataFromMoreThanOneS> createAnalysesOfDataFromMoreThanOneS(AnalysesOfDataFromMoreThanOneS value) {
        return new JAXBElement<AnalysesOfDataFromMoreThanOneS>(_AnalysesOfDataFromMoreThanOneS_QNAME, AnalysesOfDataFromMoreThanOneS.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WizardDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "wizardDetails")
    public JAXBElement<WizardDetails> createWizardDetails(WizardDetails value) {
        return new JAXBElement<WizardDetails>(_WizardDetails_QNAME, WizardDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TransistorFETDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "transistorFETDetails")
    public JAXBElement<TransistorFETDetails> createTransistorFETDetails(TransistorFETDetails value) {
        return new JAXBElement<TransistorFETDetails>(_TransistorFETDetails_QNAME, TransistorFETDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UnitProperties }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "unitProperties")
    public JAXBElement<UnitProperties> createUnitProperties(UnitProperties value) {
        return new JAXBElement<UnitProperties>(_UnitProperties_QNAME, UnitProperties.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DmrDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "dmrDetails")
    public JAXBElement<DmrDetails> createDmrDetails(DmrDetails value) {
        return new JAXBElement<DmrDetails>(_DmrDetails_QNAME, DmrDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LiteratureReferencesDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "literatureReferencesDetails")
    public JAXBElement<LiteratureReferencesDetails> createLiteratureReferencesDetails(LiteratureReferencesDetails value) {
        return new JAXBElement<LiteratureReferencesDetails>(_LiteratureReferencesDetails_QNAME, LiteratureReferencesDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VariantProperties }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "variantProperties")
    public JAXBElement<VariantProperties> createVariantProperties(VariantProperties value) {
        return new JAXBElement<VariantProperties>(_VariantProperties_QNAME, VariantProperties.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DieItemDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "dieItemDetails")
    public JAXBElement<DieItemDetails> createDieItemDetails(DieItemDetails value) {
        return new JAXBElement<DieItemDetails>(_DieItemDetails_QNAME, DieItemDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AdministrativeInformationDetai }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "administrativeInformationDetai")
    public JAXBElement<AdministrativeInformationDetai> createAdministrativeInformationDetai(AdministrativeInformationDetai value) {
        return new JAXBElement<AdministrativeInformationDetai>(_AdministrativeInformationDetai_QNAME, AdministrativeInformationDetai.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SOPProcedureDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "sOPProcedureDetails")
    public JAXBElement<SOPProcedureDetails> createSOPProcedureDetails(SOPProcedureDetails value) {
        return new JAXBElement<SOPProcedureDetails>(_SOPProcedureDetails_QNAME, SOPProcedureDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApplicantInformationDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "applicantInformationDetails")
    public JAXBElement<ApplicantInformationDetails> createApplicantInformationDetails(ApplicantInformationDetails value) {
        return new JAXBElement<ApplicantInformationDetails>(_ApplicantInformationDetails_QNAME, ApplicantInformationDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TestGroup }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "testGroup")
    public JAXBElement<TestGroup> createTestGroup(TestGroup value) {
        return new JAXBElement<TestGroup>(_TestGroup_QNAME, TestGroup.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DmrSection }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "dmrSection")
    public JAXBElement<DmrSection> createDmrSection(DmrSection value) {
        return new JAXBElement<DmrSection>(_DmrSection_QNAME, DmrSection.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link HumanPharmacodynamicPdDetail }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "humanPharmacodynamicPdDetail")
    public JAXBElement<HumanPharmacodynamicPdDetail> createHumanPharmacodynamicPdDetail(HumanPharmacodynamicPdDetail value) {
        return new JAXBElement<HumanPharmacodynamicPdDetail>(_HumanPharmacodynamicPdDetail_QNAME, HumanPharmacodynamicPdDetail.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ModuleDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "moduleDetails")
    public JAXBElement<ModuleDetails> createModuleDetails(ModuleDetails value) {
        return new JAXBElement<ModuleDetails>(_ModuleDetails_QNAME, ModuleDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LabelingDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "labelingDetails")
    public JAXBElement<LabelingDetails> createLabelingDetails(LabelingDetails value) {
        return new JAXBElement<LabelingDetails>(_LabelingDetails_QNAME, LabelingDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OtherStudyReportsDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "otherStudyReportsDetails")
    public JAXBElement<OtherStudyReportsDetails> createOtherStudyReportsDetails(OtherStudyReportsDetails value) {
        return new JAXBElement<OtherStudyReportsDetails>(_OtherStudyReportsDetails_QNAME, OtherStudyReportsDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SMSDocumentDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "sMSDocumentDetails")
    public JAXBElement<SMSDocumentDetails> createSMSDocumentDetails(SMSDocumentDetails value) {
        return new JAXBElement<SMSDocumentDetails>(_SMSDocumentDetails_QNAME, SMSDocumentDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link COMPCapacitorALTantalumDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "cOMPCapacitorALTantalumDetails")
    public JAXBElement<COMPCapacitorALTantalumDetails> createCOMPCapacitorALTantalumDetails(COMPCapacitorALTantalumDetails value) {
        return new JAXBElement<COMPCapacitorALTantalumDetails>(_COMPCapacitorALTantalumDetails_QNAME, COMPCapacitorALTantalumDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PartsDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "partsDetails")
    public JAXBElement<PartsDetails> createPartsDetails(PartsDetails value) {
        return new JAXBElement<PartsDetails>(_PartsDetails_QNAME, PartsDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link HumanPharmacokineticPkStudies }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "humanPharmacokineticPkStudies")
    public JAXBElement<HumanPharmacokineticPkStudies> createHumanPharmacokineticPkStudies(HumanPharmacokineticPkStudies value) {
        return new JAXBElement<HumanPharmacokineticPkStudies>(_HumanPharmacokineticPkStudies_QNAME, HumanPharmacokineticPkStudies.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MarketRestrictions }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "marketRestrictions")
    public JAXBElement<MarketRestrictions> createMarketRestrictions(MarketRestrictions value) {
        return new JAXBElement<MarketRestrictions>(_MarketRestrictions_QNAME, MarketRestrictions.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DatasheetsDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "datasheetsDetails")
    public JAXBElement<DatasheetsDetails> createDatasheetsDetails(DatasheetsDetails value) {
        return new JAXBElement<DatasheetsDetails>(_DatasheetsDetails_QNAME, DatasheetsDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link HbAttributesGroup }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "hbAttributesGroup")
    public JAXBElement<HbAttributesGroup> createHbAttributesGroup(HbAttributesGroup value) {
        return new JAXBElement<HbAttributesGroup>(_HbAttributesGroup_QNAME, HbAttributesGroup.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Comments }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "comments")
    public JAXBElement<Comments> createComments(Comments value) {
        return new JAXBElement<Comments>(_Comments_QNAME, Comments.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ComponentDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "componentDetails")
    public JAXBElement<ComponentDetails> createComponentDetails(ComponentDetails value) {
        return new JAXBElement<ComponentDetails>(_ComponentDetails_QNAME, ComponentDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EfficacyAndSafetyDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "efficacyAndSafetyDetails")
    public JAXBElement<EfficacyAndSafetyDetails> createEfficacyAndSafetyDetails(EfficacyAndSafetyDetails value) {
        return new JAXBElement<EfficacyAndSafetyDetails>(_EfficacyAndSafetyDetails_QNAME, EfficacyAndSafetyDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UltrasoundScanners }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "ultrasoundScanners")
    public JAXBElement<UltrasoundScanners> createUltrasoundScanners(UltrasoundScanners value) {
        return new JAXBElement<UltrasoundScanners>(_UltrasoundScanners_QNAME, UltrasoundScanners.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CellStackSection }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "cellStackSection")
    public JAXBElement<CellStackSection> createCellStackSection(CellStackSection value) {
        return new JAXBElement<CellStackSection>(_CellStackSection_QNAME, CellStackSection.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = ApplicantInformationDetails.class)
    public JAXBElement<Boolean> createApplicantInformationDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, ApplicantInformationDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineprojectName", scope = ApplicantInformationDetails.class)
    public JAXBElement<String> createApplicantInformationDetailsRedLineprojectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLineprojectName_QNAME, String.class, ApplicantInformationDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = ApplicantInformationDetails.class)
    public JAXBElement<String> createApplicantInformationDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, ApplicantInformationDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "subGroup", scope = ApplicantInformationDetails.class)
    public JAXBElement<String> createApplicantInformationDetailsSubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsSubGroup_QNAME, String.class, ApplicantInformationDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = ApplicantInformationDetails.class)
    public JAXBElement<String> createApplicantInformationDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, ApplicantInformationDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = ApplicantInformationDetails.class)
    public JAXBElement<Boolean> createApplicantInformationDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, ApplicantInformationDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesubGroup", scope = ApplicantInformationDetails.class)
    public JAXBElement<String> createApplicantInformationDetailsRedLinesubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLinesubGroup_QNAME, String.class, ApplicantInformationDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = ApplicantInformationDetails.class)
    public JAXBElement<Boolean> createApplicantInformationDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, ApplicantInformationDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "projectName", scope = ApplicantInformationDetails.class)
    public JAXBElement<String> createApplicantInformationDetailsProjectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsProjectName_QNAME, String.class, ApplicantInformationDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = CellSection.class)
    public JAXBElement<Boolean> createCellSectionIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, CellSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = CellSection.class)
    public JAXBElement<String> createCellSectionRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, CellSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = CellSection.class)
    public JAXBElement<String> createCellSectionBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, CellSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = CellSection.class)
    public JAXBElement<Boolean> createCellSectionIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, CellSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "size", scope = CellSection.class)
    public JAXBElement<String> createCellSectionSize(String value) {
        return new JAXBElement<String>(_CellSectionSize_QNAME, String.class, CellSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "material", scope = CellSection.class)
    public JAXBElement<String> createCellSectionMaterial(String value) {
        return new JAXBElement<String>(_CellSectionMaterial_QNAME, String.class, CellSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "voltage", scope = CellSection.class)
    public JAXBElement<String> createCellSectionVoltage(String value) {
        return new JAXBElement<String>(_CellSectionVoltage_QNAME, String.class, CellSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinematerial", scope = CellSection.class)
    public JAXBElement<String> createCellSectionRedLinematerial(String value) {
        return new JAXBElement<String>(_CellSectionRedLinematerial_QNAME, String.class, CellSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesize", scope = CellSection.class)
    public JAXBElement<String> createCellSectionRedLinesize(String value) {
        return new JAXBElement<String>(_CellSectionRedLinesize_QNAME, String.class, CellSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinevoltage", scope = CellSection.class)
    public JAXBElement<String> createCellSectionRedLinevoltage(String value) {
        return new JAXBElement<String>(_CellSectionRedLinevoltage_QNAME, String.class, CellSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = CellSection.class)
    public JAXBElement<Boolean> createCellSectionIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, CellSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = WizardDetails.class)
    public JAXBElement<Boolean> createWizardDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, WizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsTemplate", scope = WizardDetails.class)
    public JAXBElement<String> createWizardDetailsIsTemplate(String value) {
        return new JAXBElement<String>(_WizardDetailsIsTemplate_QNAME, String.class, WizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = WizardDetails.class)
    public JAXBElement<String> createWizardDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, WizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = WizardDetails.class)
    public JAXBElement<String> createWizardDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, WizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = WizardDetails.class)
    public JAXBElement<Boolean> createWizardDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, WizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineWizardStatus", scope = WizardDetails.class)
    public JAXBElement<String> createWizardDetailsRedLineWizardStatus(String value) {
        return new JAXBElement<String>(_WizardDetailsRedLineWizardStatus_QNAME, String.class, WizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "WizardStatus", scope = WizardDetails.class)
    public JAXBElement<String> createWizardDetailsWizardStatus(String value) {
        return new JAXBElement<String>(_WizardDetailsWizardStatus_QNAME, String.class, WizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineIsTemplate", scope = WizardDetails.class)
    public JAXBElement<String> createWizardDetailsRedLineIsTemplate(String value) {
        return new JAXBElement<String>(_WizardDetailsRedLineIsTemplate_QNAME, String.class, WizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = WizardDetails.class)
    public JAXBElement<Boolean> createWizardDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, WizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = DatasheetsDetails.class)
    public JAXBElement<Boolean> createDatasheetsDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, DatasheetsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "ExternalDocumentTitle", scope = DatasheetsDetails.class)
    public JAXBElement<String> createDatasheetsDetailsExternalDocumentTitle(String value) {
        return new JAXBElement<String>(_DatasheetsDetailsExternalDocumentTitle_QNAME, String.class, DatasheetsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "ExternalDocumentNumber", scope = DatasheetsDetails.class)
    public JAXBElement<String> createDatasheetsDetailsExternalDocumentNumber(String value) {
        return new JAXBElement<String>(_DatasheetsDetailsExternalDocumentNumber_QNAME, String.class, DatasheetsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = DatasheetsDetails.class)
    public JAXBElement<String> createDatasheetsDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, DatasheetsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = DatasheetsDetails.class)
    public JAXBElement<String> createDatasheetsDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, DatasheetsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = DatasheetsDetails.class)
    public JAXBElement<Boolean> createDatasheetsDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, DatasheetsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "ExternalDocumentRev", scope = DatasheetsDetails.class)
    public JAXBElement<String> createDatasheetsDetailsExternalDocumentRev(String value) {
        return new JAXBElement<String>(_DatasheetsDetailsExternalDocumentRev_QNAME, String.class, DatasheetsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineExternalDocumentTitle", scope = DatasheetsDetails.class)
    public JAXBElement<String> createDatasheetsDetailsRedLineExternalDocumentTitle(String value) {
        return new JAXBElement<String>(_DatasheetsDetailsRedLineExternalDocumentTitle_QNAME, String.class, DatasheetsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineExternalDocumentRev", scope = DatasheetsDetails.class)
    public JAXBElement<String> createDatasheetsDetailsRedLineExternalDocumentRev(String value) {
        return new JAXBElement<String>(_DatasheetsDetailsRedLineExternalDocumentRev_QNAME, String.class, DatasheetsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineExternalDocumentNumber", scope = DatasheetsDetails.class)
    public JAXBElement<String> createDatasheetsDetailsRedLineExternalDocumentNumber(String value) {
        return new JAXBElement<String>(_DatasheetsDetailsRedLineExternalDocumentNumber_QNAME, String.class, DatasheetsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = DatasheetsDetails.class)
    public JAXBElement<Boolean> createDatasheetsDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, DatasheetsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = Details.class)
    public JAXBElement<Boolean> createDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, Details.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "system", scope = Details.class)
    public JAXBElement<String> createDetailsSystem(String value) {
        return new JAXBElement<String>(_DetailsSystem_QNAME, String.class, Details.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = Details.class)
    public JAXBElement<String> createDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, Details.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinestorageConditions", scope = Details.class)
    public JAXBElement<String> createDetailsRedLinestorageConditions(String value) {
        return new JAXBElement<String>(_DetailsRedLinestorageConditions_QNAME, String.class, Details.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = Details.class)
    public JAXBElement<String> createDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, Details.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "materialCompositionChemicalPro", scope = Details.class)
    public JAXBElement<String> createDetailsMaterialCompositionChemicalPro(String value) {
        return new JAXBElement<String>(_DetailsMaterialCompositionChemicalPro_QNAME, String.class, Details.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "documentsToSendToVendor", scope = Details.class)
    public JAXBElement<String> createDetailsDocumentsToSendToVendor(String value) {
        return new JAXBElement<String>(_DetailsDocumentsToSendToVendor_QNAME, String.class, Details.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = Details.class)
    public JAXBElement<Boolean> createDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, Details.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineother", scope = Details.class)
    public JAXBElement<String> createDetailsRedLineother(String value) {
        return new JAXBElement<String>(_DetailsRedLineother_QNAME, String.class, Details.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesystem", scope = Details.class)
    public JAXBElement<String> createDetailsRedLinesystem(String value) {
        return new JAXBElement<String>(_DetailsRedLinesystem_QNAME, String.class, Details.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "other", scope = Details.class)
    public JAXBElement<String> createDetailsOther(String value) {
        return new JAXBElement<String>(_DetailsOther_QNAME, String.class, Details.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinematerialCompositionChemicalPro", scope = Details.class)
    public JAXBElement<String> createDetailsRedLinematerialCompositionChemicalPro(String value) {
        return new JAXBElement<String>(_DetailsRedLinematerialCompositionChemicalPro_QNAME, String.class, Details.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesupplierCode", scope = Details.class)
    public JAXBElement<String> createDetailsRedLinesupplierCode(String value) {
        return new JAXBElement<String>(_DetailsRedLinesupplierCode_QNAME, String.class, Details.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = Details.class)
    public JAXBElement<Boolean> createDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, Details.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "supplierCode", scope = Details.class)
    public JAXBElement<String> createDetailsSupplierCode(String value) {
        return new JAXBElement<String>(_DetailsSupplierCode_QNAME, String.class, Details.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "storageConditions", scope = Details.class)
    public JAXBElement<String> createDetailsStorageConditions(String value) {
        return new JAXBElement<String>(_DetailsStorageConditions_QNAME, String.class, Details.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinedocumentsToSendToVendor", scope = Details.class)
    public JAXBElement<String> createDetailsRedLinedocumentsToSendToVendor(String value) {
        return new JAXBElement<String>(_DetailsRedLinedocumentsToSendToVendor_QNAME, String.class, Details.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = HbAttributesGroup.class)
    public JAXBElement<Boolean> createHbAttributesGroupIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, HbAttributesGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinematerialCost_Display", scope = HbAttributesGroup.class)
    public JAXBElement<String> createHbAttributesGroupRedLinematerialCostDisplay(String value) {
        return new JAXBElement<String>(_HbAttributesGroupRedLinematerialCostDisplay_QNAME, String.class, HbAttributesGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = HbAttributesGroup.class)
    public JAXBElement<String> createHbAttributesGroupRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, HbAttributesGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = HbAttributesGroup.class)
    public JAXBElement<String> createHbAttributesGroupBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, HbAttributesGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = HbAttributesGroup.class)
    public JAXBElement<Boolean> createHbAttributesGroupIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, HbAttributesGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "numberOfPages", scope = HbAttributesGroup.class)
    public JAXBElement<BigDecimal> createHbAttributesGroupNumberOfPages(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_HbAttributesGroupNumberOfPages_QNAME, BigDecimal.class, HbAttributesGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinenumberOfPages", scope = HbAttributesGroup.class)
    public JAXBElement<String> createHbAttributesGroupRedLinenumberOfPages(String value) {
        return new JAXBElement<String>(_HbAttributesGroupRedLinenumberOfPages_QNAME, String.class, HbAttributesGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "materialCost", scope = HbAttributesGroup.class)
    public JAXBElement<BigDecimal> createHbAttributesGroupMaterialCost(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_HbAttributesGroupMaterialCost_QNAME, BigDecimal.class, HbAttributesGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "materialCost_Display", scope = HbAttributesGroup.class)
    public JAXBElement<String> createHbAttributesGroupMaterialCostDisplay(String value) {
        return new JAXBElement<String>(_HbAttributesGroupMaterialCostDisplay_QNAME, String.class, HbAttributesGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = HbAttributesGroup.class)
    public JAXBElement<Boolean> createHbAttributesGroupIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, HbAttributesGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinematerialCost", scope = HbAttributesGroup.class)
    public JAXBElement<String> createHbAttributesGroupRedLinematerialCost(String value) {
        return new JAXBElement<String>(_HbAttributesGroupRedLinematerialCost_QNAME, String.class, HbAttributesGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = SocketDetails.class)
    public JAXBElement<Boolean> createSocketDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, SocketDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = SocketDetails.class)
    public JAXBElement<String> createSocketDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, SocketDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "Approvers", scope = SocketDetails.class)
    public JAXBElement<String> createSocketDetailsApprovers(String value) {
        return new JAXBElement<String>(_SocketDetailsApprovers_QNAME, String.class, SocketDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = SocketDetails.class)
    public JAXBElement<String> createSocketDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, SocketDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = SocketDetails.class)
    public JAXBElement<Boolean> createSocketDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, SocketDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "Reviewers", scope = SocketDetails.class)
    public JAXBElement<String> createSocketDetailsReviewers(String value) {
        return new JAXBElement<String>(_SocketDetailsReviewers_QNAME, String.class, SocketDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineReviewers", scope = SocketDetails.class)
    public JAXBElement<String> createSocketDetailsRedLineReviewers(String value) {
        return new JAXBElement<String>(_SocketDetailsRedLineReviewers_QNAME, String.class, SocketDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineApprovers", scope = SocketDetails.class)
    public JAXBElement<String> createSocketDetailsRedLineApprovers(String value) {
        return new JAXBElement<String>(_SocketDetailsRedLineApprovers_QNAME, String.class, SocketDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineAcknowledgers", scope = SocketDetails.class)
    public JAXBElement<String> createSocketDetailsRedLineAcknowledgers(String value) {
        return new JAXBElement<String>(_SocketDetailsRedLineAcknowledgers_QNAME, String.class, SocketDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "Acknowledgers", scope = SocketDetails.class)
    public JAXBElement<String> createSocketDetailsAcknowledgers(String value) {
        return new JAXBElement<String>(_SocketDetailsAcknowledgers_QNAME, String.class, SocketDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = SocketDetails.class)
    public JAXBElement<Boolean> createSocketDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, SocketDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = MedicalDeviceDetails.class)
    public JAXBElement<Boolean> createMedicalDeviceDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, MedicalDeviceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineprojectName", scope = MedicalDeviceDetails.class)
    public JAXBElement<String> createMedicalDeviceDetailsRedLineprojectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLineprojectName_QNAME, String.class, MedicalDeviceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = MedicalDeviceDetails.class)
    public JAXBElement<String> createMedicalDeviceDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, MedicalDeviceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "subGroup", scope = MedicalDeviceDetails.class)
    public JAXBElement<String> createMedicalDeviceDetailsSubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsSubGroup_QNAME, String.class, MedicalDeviceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = MedicalDeviceDetails.class)
    public JAXBElement<String> createMedicalDeviceDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, MedicalDeviceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = MedicalDeviceDetails.class)
    public JAXBElement<Boolean> createMedicalDeviceDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, MedicalDeviceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesubGroup", scope = MedicalDeviceDetails.class)
    public JAXBElement<String> createMedicalDeviceDetailsRedLinesubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLinesubGroup_QNAME, String.class, MedicalDeviceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = MedicalDeviceDetails.class)
    public JAXBElement<Boolean> createMedicalDeviceDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, MedicalDeviceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "projectName", scope = MedicalDeviceDetails.class)
    public JAXBElement<String> createMedicalDeviceDetailsProjectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsProjectName_QNAME, String.class, MedicalDeviceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = VariantProperties.class)
    public JAXBElement<Boolean> createVariantPropertiesIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, VariantProperties.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinecolor", scope = VariantProperties.class)
    public JAXBElement<String> createVariantPropertiesRedLinecolor(String value) {
        return new JAXBElement<String>(_VariantPropertiesRedLinecolor_QNAME, String.class, VariantProperties.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = VariantProperties.class)
    public JAXBElement<String> createVariantPropertiesRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, VariantProperties.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = VariantProperties.class)
    public JAXBElement<String> createVariantPropertiesBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, VariantProperties.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = VariantProperties.class)
    public JAXBElement<Boolean> createVariantPropertiesIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, VariantProperties.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "color", scope = VariantProperties.class)
    public JAXBElement<String> createVariantPropertiesColor(String value) {
        return new JAXBElement<String>(_VariantPropertiesColor_QNAME, String.class, VariantProperties.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "size", scope = VariantProperties.class)
    public JAXBElement<String> createVariantPropertiesSize(String value) {
        return new JAXBElement<String>(_CellSectionSize_QNAME, String.class, VariantProperties.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesize", scope = VariantProperties.class)
    public JAXBElement<String> createVariantPropertiesRedLinesize(String value) {
        return new JAXBElement<String>(_CellSectionRedLinesize_QNAME, String.class, VariantProperties.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = VariantProperties.class)
    public JAXBElement<Boolean> createVariantPropertiesIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, VariantProperties.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = FilledGoodDetails.class)
    public JAXBElement<Boolean> createFilledGoodDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, FilledGoodDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = FilledGoodDetails.class)
    public JAXBElement<String> createFilledGoodDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, FilledGoodDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = FilledGoodDetails.class)
    public JAXBElement<String> createFilledGoodDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, FilledGoodDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = FilledGoodDetails.class)
    public JAXBElement<Boolean> createFilledGoodDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, FilledGoodDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "data", scope = FilledGoodDetails.class)
    public JAXBElement<String> createFilledGoodDetailsData(String value) {
        return new JAXBElement<String>(_FilledGoodDetailsData_QNAME, String.class, FilledGoodDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "label", scope = FilledGoodDetails.class)
    public JAXBElement<String> createFilledGoodDetailsLabel(String value) {
        return new JAXBElement<String>(_FilledGoodDetailsLabel_QNAME, String.class, FilledGoodDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinelabel", scope = FilledGoodDetails.class)
    public JAXBElement<String> createFilledGoodDetailsRedLinelabel(String value) {
        return new JAXBElement<String>(_FilledGoodDetailsRedLinelabel_QNAME, String.class, FilledGoodDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinedata", scope = FilledGoodDetails.class)
    public JAXBElement<String> createFilledGoodDetailsRedLinedata(String value) {
        return new JAXBElement<String>(_FilledGoodDetailsRedLinedata_QNAME, String.class, FilledGoodDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = FilledGoodDetails.class)
    public JAXBElement<Boolean> createFilledGoodDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, FilledGoodDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = AnalysesOfDataFromMoreThanOneS.class)
    public JAXBElement<Boolean> createAnalysesOfDataFromMoreThanOneSIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, AnalysesOfDataFromMoreThanOneS.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineprojectName", scope = AnalysesOfDataFromMoreThanOneS.class)
    public JAXBElement<String> createAnalysesOfDataFromMoreThanOneSRedLineprojectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLineprojectName_QNAME, String.class, AnalysesOfDataFromMoreThanOneS.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = AnalysesOfDataFromMoreThanOneS.class)
    public JAXBElement<String> createAnalysesOfDataFromMoreThanOneSRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, AnalysesOfDataFromMoreThanOneS.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "subGroup", scope = AnalysesOfDataFromMoreThanOneS.class)
    public JAXBElement<String> createAnalysesOfDataFromMoreThanOneSSubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsSubGroup_QNAME, String.class, AnalysesOfDataFromMoreThanOneS.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = AnalysesOfDataFromMoreThanOneS.class)
    public JAXBElement<String> createAnalysesOfDataFromMoreThanOneSBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, AnalysesOfDataFromMoreThanOneS.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = AnalysesOfDataFromMoreThanOneS.class)
    public JAXBElement<Boolean> createAnalysesOfDataFromMoreThanOneSIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, AnalysesOfDataFromMoreThanOneS.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesubGroup", scope = AnalysesOfDataFromMoreThanOneS.class)
    public JAXBElement<String> createAnalysesOfDataFromMoreThanOneSRedLinesubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLinesubGroup_QNAME, String.class, AnalysesOfDataFromMoreThanOneS.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = AnalysesOfDataFromMoreThanOneS.class)
    public JAXBElement<Boolean> createAnalysesOfDataFromMoreThanOneSIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, AnalysesOfDataFromMoreThanOneS.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "projectName", scope = AnalysesOfDataFromMoreThanOneS.class)
    public JAXBElement<String> createAnalysesOfDataFromMoreThanOneSProjectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsProjectName_QNAME, String.class, AnalysesOfDataFromMoreThanOneS.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = HumanPharmacodynamicPdDetail.class)
    public JAXBElement<Boolean> createHumanPharmacodynamicPdDetailIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, HumanPharmacodynamicPdDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineprojectName", scope = HumanPharmacodynamicPdDetail.class)
    public JAXBElement<String> createHumanPharmacodynamicPdDetailRedLineprojectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLineprojectName_QNAME, String.class, HumanPharmacodynamicPdDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = HumanPharmacodynamicPdDetail.class)
    public JAXBElement<String> createHumanPharmacodynamicPdDetailRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, HumanPharmacodynamicPdDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "subGroup", scope = HumanPharmacodynamicPdDetail.class)
    public JAXBElement<String> createHumanPharmacodynamicPdDetailSubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsSubGroup_QNAME, String.class, HumanPharmacodynamicPdDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = HumanPharmacodynamicPdDetail.class)
    public JAXBElement<String> createHumanPharmacodynamicPdDetailBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, HumanPharmacodynamicPdDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = HumanPharmacodynamicPdDetail.class)
    public JAXBElement<Boolean> createHumanPharmacodynamicPdDetailIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, HumanPharmacodynamicPdDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesubGroup", scope = HumanPharmacodynamicPdDetail.class)
    public JAXBElement<String> createHumanPharmacodynamicPdDetailRedLinesubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLinesubGroup_QNAME, String.class, HumanPharmacodynamicPdDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = HumanPharmacodynamicPdDetail.class)
    public JAXBElement<Boolean> createHumanPharmacodynamicPdDetailIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, HumanPharmacodynamicPdDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "projectName", scope = HumanPharmacodynamicPdDetail.class)
    public JAXBElement<String> createHumanPharmacodynamicPdDetailProjectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsProjectName_QNAME, String.class, HumanPharmacodynamicPdDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = OtherStudyReportsDetails.class)
    public JAXBElement<Boolean> createOtherStudyReportsDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, OtherStudyReportsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineprojectName", scope = OtherStudyReportsDetails.class)
    public JAXBElement<String> createOtherStudyReportsDetailsRedLineprojectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLineprojectName_QNAME, String.class, OtherStudyReportsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = OtherStudyReportsDetails.class)
    public JAXBElement<String> createOtherStudyReportsDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, OtherStudyReportsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "subGroup", scope = OtherStudyReportsDetails.class)
    public JAXBElement<String> createOtherStudyReportsDetailsSubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsSubGroup_QNAME, String.class, OtherStudyReportsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = OtherStudyReportsDetails.class)
    public JAXBElement<String> createOtherStudyReportsDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, OtherStudyReportsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = OtherStudyReportsDetails.class)
    public JAXBElement<Boolean> createOtherStudyReportsDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, OtherStudyReportsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesubGroup", scope = OtherStudyReportsDetails.class)
    public JAXBElement<String> createOtherStudyReportsDetailsRedLinesubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLinesubGroup_QNAME, String.class, OtherStudyReportsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = OtherStudyReportsDetails.class)
    public JAXBElement<Boolean> createOtherStudyReportsDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, OtherStudyReportsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "projectName", scope = OtherStudyReportsDetails.class)
    public JAXBElement<String> createOtherStudyReportsDetailsProjectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsProjectName_QNAME, String.class, OtherStudyReportsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = PCBSpecsDetails.class)
    public JAXBElement<Boolean> createPCBSpecsDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, PCBSpecsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "DepartmentGroup2", scope = PCBSpecsDetails.class)
    public JAXBElement<String> createPCBSpecsDetailsDepartmentGroup2(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsDepartmentGroup2_QNAME, String.class, PCBSpecsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "DepartmentGroup1", scope = PCBSpecsDetails.class)
    public JAXBElement<String> createPCBSpecsDetailsDepartmentGroup1(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsDepartmentGroup1_QNAME, String.class, PCBSpecsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "DepartmentGroup3", scope = PCBSpecsDetails.class)
    public JAXBElement<String> createPCBSpecsDetailsDepartmentGroup3(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsDepartmentGroup3_QNAME, String.class, PCBSpecsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = PCBSpecsDetails.class)
    public JAXBElement<String> createPCBSpecsDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, PCBSpecsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineDepartmentGroup2", scope = PCBSpecsDetails.class)
    public JAXBElement<String> createPCBSpecsDetailsRedLineDepartmentGroup2(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRedLineDepartmentGroup2_QNAME, String.class, PCBSpecsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineAccountTypes", scope = PCBSpecsDetails.class)
    public JAXBElement<String> createPCBSpecsDetailsRedLineAccountTypes(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRedLineAccountTypes_QNAME, String.class, PCBSpecsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineDepartmentGroup3", scope = PCBSpecsDetails.class)
    public JAXBElement<String> createPCBSpecsDetailsRedLineDepartmentGroup3(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRedLineDepartmentGroup3_QNAME, String.class, PCBSpecsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = PCBSpecsDetails.class)
    public JAXBElement<String> createPCBSpecsDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, PCBSpecsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineDepartmentGroup1", scope = PCBSpecsDetails.class)
    public JAXBElement<String> createPCBSpecsDetailsRedLineDepartmentGroup1(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRedLineDepartmentGroup1_QNAME, String.class, PCBSpecsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = PCBSpecsDetails.class)
    public JAXBElement<Boolean> createPCBSpecsDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, PCBSpecsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineDocumentCategory", scope = PCBSpecsDetails.class)
    public JAXBElement<String> createPCBSpecsDetailsRedLineDocumentCategory(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRedLineDocumentCategory_QNAME, String.class, PCBSpecsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineRecordDetails", scope = PCBSpecsDetails.class)
    public JAXBElement<String> createPCBSpecsDetailsRedLineRecordDetails(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRedLineRecordDetails_QNAME, String.class, PCBSpecsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = PCBSpecsDetails.class)
    public JAXBElement<Boolean> createPCBSpecsDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, PCBSpecsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RecordDetails", scope = PCBSpecsDetails.class)
    public JAXBElement<String> createPCBSpecsDetailsRecordDetails(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRecordDetails_QNAME, String.class, PCBSpecsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "DocumentCategory", scope = PCBSpecsDetails.class)
    public JAXBElement<String> createPCBSpecsDetailsDocumentCategory(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsDocumentCategory_QNAME, String.class, PCBSpecsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "AccountTypes", scope = PCBSpecsDetails.class)
    public JAXBElement<String> createPCBSpecsDetailsAccountTypes(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsAccountTypes_QNAME, String.class, PCBSpecsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = ComponentDetails.class)
    public JAXBElement<Boolean> createComponentDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, ComponentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinestatus", scope = ComponentDetails.class)
    public JAXBElement<String> createComponentDetailsRedLinestatus(String value) {
        return new JAXBElement<String>(_ComponentDetailsRedLinestatus_QNAME, String.class, ComponentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = ComponentDetails.class)
    public JAXBElement<String> createComponentDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, ComponentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = ComponentDetails.class)
    public JAXBElement<String> createComponentDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, ComponentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = ComponentDetails.class)
    public JAXBElement<Boolean> createComponentDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, ComponentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "size", scope = ComponentDetails.class)
    public JAXBElement<String> createComponentDetailsSize(String value) {
        return new JAXBElement<String>(_CellSectionSize_QNAME, String.class, ComponentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "status", scope = ComponentDetails.class)
    public JAXBElement<String> createComponentDetailsStatus(String value) {
        return new JAXBElement<String>(_ComponentDetailsStatus_QNAME, String.class, ComponentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesize", scope = ComponentDetails.class)
    public JAXBElement<String> createComponentDetailsRedLinesize(String value) {
        return new JAXBElement<String>(_CellSectionRedLinesize_QNAME, String.class, ComponentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = ComponentDetails.class)
    public JAXBElement<Boolean> createComponentDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, ComponentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = SOPProcedureDetails.class)
    public JAXBElement<Boolean> createSOPProcedureDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, SOPProcedureDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "Category", scope = SOPProcedureDetails.class)
    public JAXBElement<String> createSOPProcedureDetailsCategory(String value) {
        return new JAXBElement<String>(_SOPProcedureDetailsCategory_QNAME, String.class, SOPProcedureDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = SOPProcedureDetails.class)
    public JAXBElement<String> createSOPProcedureDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, SOPProcedureDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = SOPProcedureDetails.class)
    public JAXBElement<String> createSOPProcedureDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, SOPProcedureDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = SOPProcedureDetails.class)
    public JAXBElement<Boolean> createSOPProcedureDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, SOPProcedureDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineNotes", scope = SOPProcedureDetails.class)
    public JAXBElement<String> createSOPProcedureDetailsRedLineNotes(String value) {
        return new JAXBElement<String>(_SOPProcedureDetailsRedLineNotes_QNAME, String.class, SOPProcedureDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineCategory", scope = SOPProcedureDetails.class)
    public JAXBElement<String> createSOPProcedureDetailsRedLineCategory(String value) {
        return new JAXBElement<String>(_SOPProcedureDetailsRedLineCategory_QNAME, String.class, SOPProcedureDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "Notes", scope = SOPProcedureDetails.class)
    public JAXBElement<String> createSOPProcedureDetailsNotes(String value) {
        return new JAXBElement<String>(_SOPProcedureDetailsNotes_QNAME, String.class, SOPProcedureDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = SOPProcedureDetails.class)
    public JAXBElement<Boolean> createSOPProcedureDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, SOPProcedureDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = CellStackSection.class)
    public JAXBElement<Boolean> createCellStackSectionIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, CellStackSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinetotalPowerAh", scope = CellStackSection.class)
    public JAXBElement<String> createCellStackSectionRedLinetotalPowerAh(String value) {
        return new JAXBElement<String>(_CellStackSectionRedLinetotalPowerAh_QNAME, String.class, CellStackSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = CellStackSection.class)
    public JAXBElement<String> createCellStackSectionRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, CellStackSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = CellStackSection.class)
    public JAXBElement<String> createCellStackSectionBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, CellStackSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = CellStackSection.class)
    public JAXBElement<Boolean> createCellStackSectionIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, CellStackSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "numberOfCells", scope = CellStackSection.class)
    public JAXBElement<BigDecimal> createCellStackSectionNumberOfCells(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_CellStackSectionNumberOfCells_QNAME, BigDecimal.class, CellStackSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "totalPowerAh", scope = CellStackSection.class)
    public JAXBElement<String> createCellStackSectionTotalPowerAh(String value) {
        return new JAXBElement<String>(_CellStackSectionTotalPowerAh_QNAME, String.class, CellStackSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = CellStackSection.class)
    public JAXBElement<Boolean> createCellStackSectionIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, CellStackSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinenumberOfCells", scope = CellStackSection.class)
    public JAXBElement<String> createCellStackSectionRedLinenumberOfCells(String value) {
        return new JAXBElement<String>(_CellStackSectionRedLinenumberOfCells_QNAME, String.class, CellStackSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = SMSDocumentDetails.class)
    public JAXBElement<Boolean> createSMSDocumentDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, SMSDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "DepartmentGroup2", scope = SMSDocumentDetails.class)
    public JAXBElement<String> createSMSDocumentDetailsDepartmentGroup2(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsDepartmentGroup2_QNAME, String.class, SMSDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "DepartmentGroup1", scope = SMSDocumentDetails.class)
    public JAXBElement<String> createSMSDocumentDetailsDepartmentGroup1(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsDepartmentGroup1_QNAME, String.class, SMSDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "DepartmentGroup3", scope = SMSDocumentDetails.class)
    public JAXBElement<String> createSMSDocumentDetailsDepartmentGroup3(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsDepartmentGroup3_QNAME, String.class, SMSDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = SMSDocumentDetails.class)
    public JAXBElement<String> createSMSDocumentDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, SMSDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineDepartmentGroup2", scope = SMSDocumentDetails.class)
    public JAXBElement<String> createSMSDocumentDetailsRedLineDepartmentGroup2(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRedLineDepartmentGroup2_QNAME, String.class, SMSDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineAccountTypes", scope = SMSDocumentDetails.class)
    public JAXBElement<String> createSMSDocumentDetailsRedLineAccountTypes(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRedLineAccountTypes_QNAME, String.class, SMSDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineDepartmentGroup3", scope = SMSDocumentDetails.class)
    public JAXBElement<String> createSMSDocumentDetailsRedLineDepartmentGroup3(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRedLineDepartmentGroup3_QNAME, String.class, SMSDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = SMSDocumentDetails.class)
    public JAXBElement<String> createSMSDocumentDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, SMSDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineDepartmentGroup1", scope = SMSDocumentDetails.class)
    public JAXBElement<String> createSMSDocumentDetailsRedLineDepartmentGroup1(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRedLineDepartmentGroup1_QNAME, String.class, SMSDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = SMSDocumentDetails.class)
    public JAXBElement<Boolean> createSMSDocumentDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, SMSDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineDocumentCategory", scope = SMSDocumentDetails.class)
    public JAXBElement<String> createSMSDocumentDetailsRedLineDocumentCategory(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRedLineDocumentCategory_QNAME, String.class, SMSDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineRecordDetails", scope = SMSDocumentDetails.class)
    public JAXBElement<String> createSMSDocumentDetailsRedLineRecordDetails(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRedLineRecordDetails_QNAME, String.class, SMSDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = SMSDocumentDetails.class)
    public JAXBElement<Boolean> createSMSDocumentDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, SMSDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RecordDetails", scope = SMSDocumentDetails.class)
    public JAXBElement<String> createSMSDocumentDetailsRecordDetails(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRecordDetails_QNAME, String.class, SMSDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "DocumentCategory", scope = SMSDocumentDetails.class)
    public JAXBElement<String> createSMSDocumentDetailsDocumentCategory(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsDocumentCategory_QNAME, String.class, SMSDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "AccountTypes", scope = SMSDocumentDetails.class)
    public JAXBElement<String> createSMSDocumentDetailsAccountTypes(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsAccountTypes_QNAME, String.class, SMSDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = UltrasoundScanners.class)
    public JAXBElement<Boolean> createUltrasoundScannersIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, UltrasoundScanners.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinewebManagementPortal", scope = UltrasoundScanners.class)
    public JAXBElement<String> createUltrasoundScannersRedLinewebManagementPortal(String value) {
        return new JAXBElement<String>(_UltrasoundScannersRedLinewebManagementPortal_QNAME, String.class, UltrasoundScanners.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "powerDoppler", scope = UltrasoundScanners.class)
    public JAXBElement<String> createUltrasoundScannersPowerDoppler(String value) {
        return new JAXBElement<String>(_UltrasoundScannersPowerDoppler_QNAME, String.class, UltrasoundScanners.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "colorDoppler", scope = UltrasoundScanners.class)
    public JAXBElement<String> createUltrasoundScannersColorDoppler(String value) {
        return new JAXBElement<String>(_UltrasoundScannersColorDoppler_QNAME, String.class, UltrasoundScanners.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinecolorDoppler", scope = UltrasoundScanners.class)
    public JAXBElement<String> createUltrasoundScannersRedLinecolorDoppler(String value) {
        return new JAXBElement<String>(_UltrasoundScannersRedLinecolorDoppler_QNAME, String.class, UltrasoundScanners.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "needleEnhancement", scope = UltrasoundScanners.class)
    public JAXBElement<String> createUltrasoundScannersNeedleEnhancement(String value) {
        return new JAXBElement<String>(_UltrasoundScannersNeedleEnhancement_QNAME, String.class, UltrasoundScanners.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinevirtualLinear", scope = UltrasoundScanners.class)
    public JAXBElement<String> createUltrasoundScannersRedLinevirtualLinear(String value) {
        return new JAXBElement<String>(_UltrasoundScannersRedLinevirtualLinear_QNAME, String.class, UltrasoundScanners.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineneedleEnhancement", scope = UltrasoundScanners.class)
    public JAXBElement<String> createUltrasoundScannersRedLineneedleEnhancement(String value) {
        return new JAXBElement<String>(_UltrasoundScannersRedLineneedleEnhancement_QNAME, String.class, UltrasoundScanners.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = UltrasoundScanners.class)
    public JAXBElement<String> createUltrasoundScannersRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, UltrasoundScanners.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = UltrasoundScanners.class)
    public JAXBElement<String> createUltrasoundScannersBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, UltrasoundScanners.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "virtualLinear", scope = UltrasoundScanners.class)
    public JAXBElement<String> createUltrasoundScannersVirtualLinear(String value) {
        return new JAXBElement<String>(_UltrasoundScannersVirtualLinear_QNAME, String.class, UltrasoundScanners.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinepulsedWaveDoppler", scope = UltrasoundScanners.class)
    public JAXBElement<String> createUltrasoundScannersRedLinepulsedWaveDoppler(String value) {
        return new JAXBElement<String>(_UltrasoundScannersRedLinepulsedWaveDoppler_QNAME, String.class, UltrasoundScanners.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = UltrasoundScanners.class)
    public JAXBElement<Boolean> createUltrasoundScannersIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, UltrasoundScanners.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "webManagementPortal", scope = UltrasoundScanners.class)
    public JAXBElement<String> createUltrasoundScannersWebManagementPortal(String value) {
        return new JAXBElement<String>(_UltrasoundScannersWebManagementPortal_QNAME, String.class, UltrasoundScanners.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinedicom", scope = UltrasoundScanners.class)
    public JAXBElement<String> createUltrasoundScannersRedLinedicom(String value) {
        return new JAXBElement<String>(_UltrasoundScannersRedLinedicom_QNAME, String.class, UltrasoundScanners.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = UltrasoundScanners.class)
    public JAXBElement<Boolean> createUltrasoundScannersIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, UltrasoundScanners.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "pulsedWaveDoppler", scope = UltrasoundScanners.class)
    public JAXBElement<String> createUltrasoundScannersPulsedWaveDoppler(String value) {
        return new JAXBElement<String>(_UltrasoundScannersPulsedWaveDoppler_QNAME, String.class, UltrasoundScanners.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "dicom", scope = UltrasoundScanners.class)
    public JAXBElement<String> createUltrasoundScannersDicom(String value) {
        return new JAXBElement<String>(_UltrasoundScannersDicom_QNAME, String.class, UltrasoundScanners.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinepowerDoppler", scope = UltrasoundScanners.class)
    public JAXBElement<String> createUltrasoundScannersRedLinepowerDoppler(String value) {
        return new JAXBElement<String>(_UltrasoundScannersRedLinepowerDoppler_QNAME, String.class, UltrasoundScanners.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = ModuleDetails.class)
    public JAXBElement<Boolean> createModuleDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, ModuleDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = ModuleDetails.class)
    public JAXBElement<String> createModuleDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, ModuleDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "text1", scope = ModuleDetails.class)
    public JAXBElement<String> createModuleDetailsText1(String value) {
        return new JAXBElement<String>(_ModuleDetailsText1_QNAME, String.class, ModuleDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = ModuleDetails.class)
    public JAXBElement<String> createModuleDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, ModuleDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = ModuleDetails.class)
    public JAXBElement<Boolean> createModuleDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, ModuleDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "text", scope = ModuleDetails.class)
    public JAXBElement<String> createModuleDetailsText(String value) {
        return new JAXBElement<String>(_ModuleDetailsText_QNAME, String.class, ModuleDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinetext", scope = ModuleDetails.class)
    public JAXBElement<String> createModuleDetailsRedLinetext(String value) {
        return new JAXBElement<String>(_ModuleDetailsRedLinetext_QNAME, String.class, ModuleDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinetext1", scope = ModuleDetails.class)
    public JAXBElement<String> createModuleDetailsRedLinetext1(String value) {
        return new JAXBElement<String>(_ModuleDetailsRedLinetext1_QNAME, String.class, ModuleDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = ModuleDetails.class)
    public JAXBElement<Boolean> createModuleDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, ModuleDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = EfficacyAndSafetyDetails.class)
    public JAXBElement<Boolean> createEfficacyAndSafetyDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, EfficacyAndSafetyDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineprojectName", scope = EfficacyAndSafetyDetails.class)
    public JAXBElement<String> createEfficacyAndSafetyDetailsRedLineprojectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLineprojectName_QNAME, String.class, EfficacyAndSafetyDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = EfficacyAndSafetyDetails.class)
    public JAXBElement<String> createEfficacyAndSafetyDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, EfficacyAndSafetyDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "subGroup", scope = EfficacyAndSafetyDetails.class)
    public JAXBElement<String> createEfficacyAndSafetyDetailsSubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsSubGroup_QNAME, String.class, EfficacyAndSafetyDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = EfficacyAndSafetyDetails.class)
    public JAXBElement<String> createEfficacyAndSafetyDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, EfficacyAndSafetyDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = EfficacyAndSafetyDetails.class)
    public JAXBElement<Boolean> createEfficacyAndSafetyDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, EfficacyAndSafetyDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesubGroup", scope = EfficacyAndSafetyDetails.class)
    public JAXBElement<String> createEfficacyAndSafetyDetailsRedLinesubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLinesubGroup_QNAME, String.class, EfficacyAndSafetyDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = EfficacyAndSafetyDetails.class)
    public JAXBElement<Boolean> createEfficacyAndSafetyDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, EfficacyAndSafetyDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "projectName", scope = EfficacyAndSafetyDetails.class)
    public JAXBElement<String> createEfficacyAndSafetyDetailsProjectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsProjectName_QNAME, String.class, EfficacyAndSafetyDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = COMPCapacitorALTantalumDetails.class)
    public JAXBElement<Boolean> createCOMPCapacitorALTantalumDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, COMPCapacitorALTantalumDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = COMPCapacitorALTantalumDetails.class)
    public JAXBElement<String> createCOMPCapacitorALTantalumDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, COMPCapacitorALTantalumDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "Approvers", scope = COMPCapacitorALTantalumDetails.class)
    public JAXBElement<String> createCOMPCapacitorALTantalumDetailsApprovers(String value) {
        return new JAXBElement<String>(_SocketDetailsApprovers_QNAME, String.class, COMPCapacitorALTantalumDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = COMPCapacitorALTantalumDetails.class)
    public JAXBElement<String> createCOMPCapacitorALTantalumDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, COMPCapacitorALTantalumDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = COMPCapacitorALTantalumDetails.class)
    public JAXBElement<Boolean> createCOMPCapacitorALTantalumDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, COMPCapacitorALTantalumDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "Reviewers", scope = COMPCapacitorALTantalumDetails.class)
    public JAXBElement<String> createCOMPCapacitorALTantalumDetailsReviewers(String value) {
        return new JAXBElement<String>(_SocketDetailsReviewers_QNAME, String.class, COMPCapacitorALTantalumDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineReviewers", scope = COMPCapacitorALTantalumDetails.class)
    public JAXBElement<String> createCOMPCapacitorALTantalumDetailsRedLineReviewers(String value) {
        return new JAXBElement<String>(_SocketDetailsRedLineReviewers_QNAME, String.class, COMPCapacitorALTantalumDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineApprovers", scope = COMPCapacitorALTantalumDetails.class)
    public JAXBElement<String> createCOMPCapacitorALTantalumDetailsRedLineApprovers(String value) {
        return new JAXBElement<String>(_SocketDetailsRedLineApprovers_QNAME, String.class, COMPCapacitorALTantalumDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineAcknowledgers", scope = COMPCapacitorALTantalumDetails.class)
    public JAXBElement<String> createCOMPCapacitorALTantalumDetailsRedLineAcknowledgers(String value) {
        return new JAXBElement<String>(_SocketDetailsRedLineAcknowledgers_QNAME, String.class, COMPCapacitorALTantalumDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "Acknowledgers", scope = COMPCapacitorALTantalumDetails.class)
    public JAXBElement<String> createCOMPCapacitorALTantalumDetailsAcknowledgers(String value) {
        return new JAXBElement<String>(_SocketDetailsAcknowledgers_QNAME, String.class, COMPCapacitorALTantalumDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = COMPCapacitorALTantalumDetails.class)
    public JAXBElement<Boolean> createCOMPCapacitorALTantalumDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, COMPCapacitorALTantalumDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = DmrDetails.class)
    public JAXBElement<Boolean> createDmrDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, DmrDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = DmrDetails.class)
    public JAXBElement<String> createDmrDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, DmrDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = DmrDetails.class)
    public JAXBElement<String> createDmrDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, DmrDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "dmrDescription", scope = DmrDetails.class)
    public JAXBElement<String> createDmrDetailsDmrDescription(String value) {
        return new JAXBElement<String>(_DmrDetailsDmrDescription_QNAME, String.class, DmrDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinedeviceName", scope = DmrDetails.class)
    public JAXBElement<String> createDmrDetailsRedLinedeviceName(String value) {
        return new JAXBElement<String>(_DmrDetailsRedLinedeviceName_QNAME, String.class, DmrDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinedmrDescription", scope = DmrDetails.class)
    public JAXBElement<String> createDmrDetailsRedLinedmrDescription(String value) {
        return new JAXBElement<String>(_DmrDetailsRedLinedmrDescription_QNAME, String.class, DmrDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinefinishedGoodNumber", scope = DmrDetails.class)
    public JAXBElement<String> createDmrDetailsRedLinefinishedGoodNumber(String value) {
        return new JAXBElement<String>(_DmrDetailsRedLinefinishedGoodNumber_QNAME, String.class, DmrDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = DmrDetails.class)
    public JAXBElement<Boolean> createDmrDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, DmrDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "dhf", scope = DmrDetails.class)
    public JAXBElement<String> createDmrDetailsDhf(String value) {
        return new JAXBElement<String>(_DmrDetailsDhf_QNAME, String.class, DmrDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinedhf", scope = DmrDetails.class)
    public JAXBElement<String> createDmrDetailsRedLinedhf(String value) {
        return new JAXBElement<String>(_DmrDetailsRedLinedhf_QNAME, String.class, DmrDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "finishedGoodNumber", scope = DmrDetails.class)
    public JAXBElement<String> createDmrDetailsFinishedGoodNumber(String value) {
        return new JAXBElement<String>(_DmrDetailsFinishedGoodNumber_QNAME, String.class, DmrDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = DmrDetails.class)
    public JAXBElement<Boolean> createDmrDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, DmrDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "deviceName", scope = DmrDetails.class)
    public JAXBElement<String> createDmrDetailsDeviceName(String value) {
        return new JAXBElement<String>(_DmrDetailsDeviceName_QNAME, String.class, DmrDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = QualityOverallSummaryDetails.class)
    public JAXBElement<Boolean> createQualityOverallSummaryDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, QualityOverallSummaryDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineprojectName", scope = QualityOverallSummaryDetails.class)
    public JAXBElement<String> createQualityOverallSummaryDetailsRedLineprojectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLineprojectName_QNAME, String.class, QualityOverallSummaryDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = QualityOverallSummaryDetails.class)
    public JAXBElement<String> createQualityOverallSummaryDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, QualityOverallSummaryDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "subGroup", scope = QualityOverallSummaryDetails.class)
    public JAXBElement<String> createQualityOverallSummaryDetailsSubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsSubGroup_QNAME, String.class, QualityOverallSummaryDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = QualityOverallSummaryDetails.class)
    public JAXBElement<String> createQualityOverallSummaryDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, QualityOverallSummaryDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = QualityOverallSummaryDetails.class)
    public JAXBElement<Boolean> createQualityOverallSummaryDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, QualityOverallSummaryDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesubGroup", scope = QualityOverallSummaryDetails.class)
    public JAXBElement<String> createQualityOverallSummaryDetailsRedLinesubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLinesubGroup_QNAME, String.class, QualityOverallSummaryDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = QualityOverallSummaryDetails.class)
    public JAXBElement<Boolean> createQualityOverallSummaryDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, QualityOverallSummaryDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "projectName", scope = QualityOverallSummaryDetails.class)
    public JAXBElement<String> createQualityOverallSummaryDetailsProjectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsProjectName_QNAME, String.class, QualityOverallSummaryDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = DieItemDetails.class)
    public JAXBElement<Boolean> createDieItemDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, DieItemDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinechangeType", scope = DieItemDetails.class)
    public JAXBElement<String> createDieItemDetailsRedLinechangeType(String value) {
        return new JAXBElement<String>(_DieItemDetailsRedLinechangeType_QNAME, String.class, DieItemDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "baseDevice", scope = DieItemDetails.class)
    public JAXBElement<String> createDieItemDetailsBaseDevice(String value) {
        return new JAXBElement<String>(_DieItemDetailsBaseDevice_QNAME, String.class, DieItemDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "dieDeviceVersion", scope = DieItemDetails.class)
    public JAXBElement<String> createDieItemDetailsDieDeviceVersion(String value) {
        return new JAXBElement<String>(_DieItemDetailsDieDeviceVersion_QNAME, String.class, DieItemDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = DieItemDetails.class)
    public JAXBElement<String> createDieItemDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, DieItemDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "changeType", scope = DieItemDetails.class)
    public JAXBElement<String> createDieItemDetailsChangeType(String value) {
        return new JAXBElement<String>(_DieItemDetailsChangeType_QNAME, String.class, DieItemDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = DieItemDetails.class)
    public JAXBElement<String> createDieItemDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, DieItemDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = DieItemDetails.class)
    public JAXBElement<Boolean> createDieItemDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, DieItemDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinebaseDevice", scope = DieItemDetails.class)
    public JAXBElement<String> createDieItemDetailsRedLinebaseDevice(String value) {
        return new JAXBElement<String>(_DieItemDetailsRedLinebaseDevice_QNAME, String.class, DieItemDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinedieDeviceVersion", scope = DieItemDetails.class)
    public JAXBElement<String> createDieItemDetailsRedLinedieDeviceVersion(String value) {
        return new JAXBElement<String>(_DieItemDetailsRedLinedieDeviceVersion_QNAME, String.class, DieItemDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = DieItemDetails.class)
    public JAXBElement<Boolean> createDieItemDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, DieItemDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = Kit.class)
    public JAXBElement<Boolean> createKitIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, Kit.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinestatus", scope = Kit.class)
    public JAXBElement<String> createKitRedLinestatus(String value) {
        return new JAXBElement<String>(_ComponentDetailsRedLinestatus_QNAME, String.class, Kit.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = Kit.class)
    public JAXBElement<String> createKitRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, Kit.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "segment", scope = Kit.class)
    public JAXBElement<String> createKitSegment(String value) {
        return new JAXBElement<String>(_KitSegment_QNAME, String.class, Kit.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinekitSize", scope = Kit.class)
    public JAXBElement<String> createKitRedLinekitSize(String value) {
        return new JAXBElement<String>(_KitRedLinekitSize_QNAME, String.class, Kit.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesegment", scope = Kit.class)
    public JAXBElement<String> createKitRedLinesegment(String value) {
        return new JAXBElement<String>(_KitRedLinesegment_QNAME, String.class, Kit.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "kitSize", scope = Kit.class)
    public JAXBElement<String> createKitKitSize(String value) {
        return new JAXBElement<String>(_KitKitSize_QNAME, String.class, Kit.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = Kit.class)
    public JAXBElement<String> createKitBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, Kit.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = Kit.class)
    public JAXBElement<Boolean> createKitIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, Kit.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "status", scope = Kit.class)
    public JAXBElement<String> createKitStatus(String value) {
        return new JAXBElement<String>(_ComponentDetailsStatus_QNAME, String.class, Kit.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = Kit.class)
    public JAXBElement<Boolean> createKitIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, Kit.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = MarketRestrictions.class)
    public JAXBElement<Boolean> createMarketRestrictionsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, MarketRestrictions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = MarketRestrictions.class)
    public JAXBElement<String> createMarketRestrictionsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, MarketRestrictions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = MarketRestrictions.class)
    public JAXBElement<String> createMarketRestrictionsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, MarketRestrictions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = MarketRestrictions.class)
    public JAXBElement<Boolean> createMarketRestrictionsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, MarketRestrictions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "data", scope = MarketRestrictions.class)
    public JAXBElement<String> createMarketRestrictionsData(String value) {
        return new JAXBElement<String>(_FilledGoodDetailsData_QNAME, String.class, MarketRestrictions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "label", scope = MarketRestrictions.class)
    public JAXBElement<String> createMarketRestrictionsLabel(String value) {
        return new JAXBElement<String>(_FilledGoodDetailsLabel_QNAME, String.class, MarketRestrictions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinelabel", scope = MarketRestrictions.class)
    public JAXBElement<String> createMarketRestrictionsRedLinelabel(String value) {
        return new JAXBElement<String>(_FilledGoodDetailsRedLinelabel_QNAME, String.class, MarketRestrictions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinedata", scope = MarketRestrictions.class)
    public JAXBElement<String> createMarketRestrictionsRedLinedata(String value) {
        return new JAXBElement<String>(_FilledGoodDetailsRedLinedata_QNAME, String.class, MarketRestrictions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = MarketRestrictions.class)
    public JAXBElement<Boolean> createMarketRestrictionsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, MarketRestrictions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = TestGroup.class)
    public JAXBElement<Boolean> createTestGroupIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, TestGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = TestGroup.class)
    public JAXBElement<String> createTestGroupRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, TestGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = TestGroup.class)
    public JAXBElement<String> createTestGroupBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, TestGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = TestGroup.class)
    public JAXBElement<Boolean> createTestGroupIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, TestGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "testAttribute", scope = TestGroup.class)
    public JAXBElement<BigDecimal> createTestGroupTestAttribute(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_TestGroupTestAttribute_QNAME, BigDecimal.class, TestGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinetestAttribute", scope = TestGroup.class)
    public JAXBElement<String> createTestGroupRedLinetestAttribute(String value) {
        return new JAXBElement<String>(_TestGroupRedLinetestAttribute_QNAME, String.class, TestGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = TestGroup.class)
    public JAXBElement<Boolean> createTestGroupIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, TestGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = Comments.class)
    public JAXBElement<Boolean> createCommentsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, Comments.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = Comments.class)
    public JAXBElement<String> createCommentsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, Comments.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinecommentNotes", scope = Comments.class)
    public JAXBElement<String> createCommentsRedLinecommentNotes(String value) {
        return new JAXBElement<String>(_CommentsRedLinecommentNotes_QNAME, String.class, Comments.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = Comments.class)
    public JAXBElement<String> createCommentsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, Comments.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = Comments.class)
    public JAXBElement<Boolean> createCommentsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, Comments.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinecommentId", scope = Comments.class)
    public JAXBElement<String> createCommentsRedLinecommentId(String value) {
        return new JAXBElement<String>(_CommentsRedLinecommentId_QNAME, String.class, Comments.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinecreatedOn", scope = Comments.class)
    public JAXBElement<String> createCommentsRedLinecreatedOn(String value) {
        return new JAXBElement<String>(_CommentsRedLinecreatedOn_QNAME, String.class, Comments.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "commentId", scope = Comments.class)
    public JAXBElement<String> createCommentsCommentId(String value) {
        return new JAXBElement<String>(_CommentsCommentId_QNAME, String.class, Comments.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "commentNotes", scope = Comments.class)
    public JAXBElement<String> createCommentsCommentNotes(String value) {
        return new JAXBElement<String>(_CommentsCommentNotes_QNAME, String.class, Comments.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "createdOn", scope = Comments.class)
    public JAXBElement<XMLGregorianCalendar> createCommentsCreatedOn(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_CommentsCreatedOn_QNAME, XMLGregorianCalendar.class, Comments.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = Comments.class)
    public JAXBElement<Boolean> createCommentsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, Comments.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = PartsDetails.class)
    public JAXBElement<Boolean> createPartsDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, PartsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineEBSOrg", scope = PartsDetails.class)
    public JAXBElement<String> createPartsDetailsRedLineEBSOrg(String value) {
        return new JAXBElement<String>(_PartsDetailsRedLineEBSOrg_QNAME, String.class, PartsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "ItemCost", scope = PartsDetails.class)
    public JAXBElement<BigDecimal> createPartsDetailsItemCost(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_PartsDetailsItemCost_QNAME, BigDecimal.class, PartsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BaseID", scope = PartsDetails.class)
    public JAXBElement<String> createPartsDetailsBaseID(String value) {
        return new JAXBElement<String>(_PartsDetailsBaseID_QNAME, String.class, PartsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = PartsDetails.class)
    public JAXBElement<String> createPartsDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, PartsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineItemCost", scope = PartsDetails.class)
    public JAXBElement<String> createPartsDetailsRedLineItemCost(String value) {
        return new JAXBElement<String>(_PartsDetailsRedLineItemCost_QNAME, String.class, PartsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineBaseID", scope = PartsDetails.class)
    public JAXBElement<String> createPartsDetailsRedLineBaseID(String value) {
        return new JAXBElement<String>(_PartsDetailsRedLineBaseID_QNAME, String.class, PartsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = PartsDetails.class)
    public JAXBElement<String> createPartsDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, PartsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = PartsDetails.class)
    public JAXBElement<Boolean> createPartsDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, PartsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "EBSOrg", scope = PartsDetails.class)
    public JAXBElement<String> createPartsDetailsEBSOrg(String value) {
        return new JAXBElement<String>(_PartsDetailsEBSOrg_QNAME, String.class, PartsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = PartsDetails.class)
    public JAXBElement<Boolean> createPartsDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, PartsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = LiteratureReferencesDetails.class)
    public JAXBElement<Boolean> createLiteratureReferencesDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, LiteratureReferencesDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineprojectName", scope = LiteratureReferencesDetails.class)
    public JAXBElement<String> createLiteratureReferencesDetailsRedLineprojectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLineprojectName_QNAME, String.class, LiteratureReferencesDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = LiteratureReferencesDetails.class)
    public JAXBElement<String> createLiteratureReferencesDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, LiteratureReferencesDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "subGroup", scope = LiteratureReferencesDetails.class)
    public JAXBElement<String> createLiteratureReferencesDetailsSubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsSubGroup_QNAME, String.class, LiteratureReferencesDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = LiteratureReferencesDetails.class)
    public JAXBElement<String> createLiteratureReferencesDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, LiteratureReferencesDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = LiteratureReferencesDetails.class)
    public JAXBElement<Boolean> createLiteratureReferencesDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, LiteratureReferencesDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesubGroup", scope = LiteratureReferencesDetails.class)
    public JAXBElement<String> createLiteratureReferencesDetailsRedLinesubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLinesubGroup_QNAME, String.class, LiteratureReferencesDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = LiteratureReferencesDetails.class)
    public JAXBElement<Boolean> createLiteratureReferencesDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, LiteratureReferencesDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "projectName", scope = LiteratureReferencesDetails.class)
    public JAXBElement<String> createLiteratureReferencesDetailsProjectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsProjectName_QNAME, String.class, LiteratureReferencesDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = DocumentsDetails.class)
    public JAXBElement<Boolean> createDocumentsDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, DocumentsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineDocCategory", scope = DocumentsDetails.class)
    public JAXBElement<String> createDocumentsDetailsRedLineDocCategory(String value) {
        return new JAXBElement<String>(_DocumentsDetailsRedLineDocCategory_QNAME, String.class, DocumentsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineBusinessUnit", scope = DocumentsDetails.class)
    public JAXBElement<String> createDocumentsDetailsRedLineBusinessUnit(String value) {
        return new JAXBElement<String>(_DocumentsDetailsRedLineBusinessUnit_QNAME, String.class, DocumentsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = DocumentsDetails.class)
    public JAXBElement<String> createDocumentsDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, DocumentsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BusinessUnit", scope = DocumentsDetails.class)
    public JAXBElement<String> createDocumentsDetailsBusinessUnit(String value) {
        return new JAXBElement<String>(_DocumentsDetailsBusinessUnit_QNAME, String.class, DocumentsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = DocumentsDetails.class)
    public JAXBElement<String> createDocumentsDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, DocumentsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = DocumentsDetails.class)
    public JAXBElement<Boolean> createDocumentsDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, DocumentsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "DateofActivation", scope = DocumentsDetails.class)
    public JAXBElement<XMLGregorianCalendar> createDocumentsDetailsDateofActivation(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_DocumentsDetailsDateofActivation_QNAME, XMLGregorianCalendar.class, DocumentsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "DocCategory", scope = DocumentsDetails.class)
    public JAXBElement<String> createDocumentsDetailsDocCategory(String value) {
        return new JAXBElement<String>(_DocumentsDetailsDocCategory_QNAME, String.class, DocumentsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = DocumentsDetails.class)
    public JAXBElement<Boolean> createDocumentsDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, DocumentsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineDateofActivation", scope = DocumentsDetails.class)
    public JAXBElement<String> createDocumentsDetailsRedLineDateofActivation(String value) {
        return new JAXBElement<String>(_DocumentsDetailsRedLineDateofActivation_QNAME, String.class, DocumentsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = DrugProductDetails.class)
    public JAXBElement<Boolean> createDrugProductDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, DrugProductDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineprojectName", scope = DrugProductDetails.class)
    public JAXBElement<String> createDrugProductDetailsRedLineprojectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLineprojectName_QNAME, String.class, DrugProductDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = DrugProductDetails.class)
    public JAXBElement<String> createDrugProductDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, DrugProductDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "subGroup", scope = DrugProductDetails.class)
    public JAXBElement<String> createDrugProductDetailsSubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsSubGroup_QNAME, String.class, DrugProductDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = DrugProductDetails.class)
    public JAXBElement<String> createDrugProductDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, DrugProductDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = DrugProductDetails.class)
    public JAXBElement<Boolean> createDrugProductDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, DrugProductDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesubGroup", scope = DrugProductDetails.class)
    public JAXBElement<String> createDrugProductDetailsRedLinesubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLinesubGroup_QNAME, String.class, DrugProductDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = DrugProductDetails.class)
    public JAXBElement<Boolean> createDrugProductDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, DrugProductDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "projectName", scope = DrugProductDetails.class)
    public JAXBElement<String> createDrugProductDetailsProjectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsProjectName_QNAME, String.class, DrugProductDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = COMPResistorDetails.class)
    public JAXBElement<Boolean> createCOMPResistorDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, COMPResistorDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = COMPResistorDetails.class)
    public JAXBElement<String> createCOMPResistorDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, COMPResistorDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "Approvers", scope = COMPResistorDetails.class)
    public JAXBElement<String> createCOMPResistorDetailsApprovers(String value) {
        return new JAXBElement<String>(_SocketDetailsApprovers_QNAME, String.class, COMPResistorDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = COMPResistorDetails.class)
    public JAXBElement<String> createCOMPResistorDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, COMPResistorDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = COMPResistorDetails.class)
    public JAXBElement<Boolean> createCOMPResistorDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, COMPResistorDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "Reviewers", scope = COMPResistorDetails.class)
    public JAXBElement<String> createCOMPResistorDetailsReviewers(String value) {
        return new JAXBElement<String>(_SocketDetailsReviewers_QNAME, String.class, COMPResistorDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineReviewers", scope = COMPResistorDetails.class)
    public JAXBElement<String> createCOMPResistorDetailsRedLineReviewers(String value) {
        return new JAXBElement<String>(_SocketDetailsRedLineReviewers_QNAME, String.class, COMPResistorDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineApprovers", scope = COMPResistorDetails.class)
    public JAXBElement<String> createCOMPResistorDetailsRedLineApprovers(String value) {
        return new JAXBElement<String>(_SocketDetailsRedLineApprovers_QNAME, String.class, COMPResistorDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineAcknowledgers", scope = COMPResistorDetails.class)
    public JAXBElement<String> createCOMPResistorDetailsRedLineAcknowledgers(String value) {
        return new JAXBElement<String>(_SocketDetailsRedLineAcknowledgers_QNAME, String.class, COMPResistorDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "Acknowledgers", scope = COMPResistorDetails.class)
    public JAXBElement<String> createCOMPResistorDetailsAcknowledgers(String value) {
        return new JAXBElement<String>(_SocketDetailsAcknowledgers_QNAME, String.class, COMPResistorDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = COMPResistorDetails.class)
    public JAXBElement<Boolean> createCOMPResistorDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, COMPResistorDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = FgAttribute.class)
    public JAXBElement<Boolean> createFgAttributeIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, FgAttribute.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinetestCycle", scope = FgAttribute.class)
    public JAXBElement<String> createFgAttributeRedLinetestCycle(String value) {
        return new JAXBElement<String>(_FgAttributeRedLinetestCycle_QNAME, String.class, FgAttribute.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = FgAttribute.class)
    public JAXBElement<String> createFgAttributeRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, FgAttribute.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesku", scope = FgAttribute.class)
    public JAXBElement<String> createFgAttributeRedLinesku(String value) {
        return new JAXBElement<String>(_FgAttributeRedLinesku_QNAME, String.class, FgAttribute.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = FgAttribute.class)
    public JAXBElement<String> createFgAttributeBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, FgAttribute.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = FgAttribute.class)
    public JAXBElement<Boolean> createFgAttributeIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, FgAttribute.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesampleText", scope = FgAttribute.class)
    public JAXBElement<String> createFgAttributeRedLinesampleText(String value) {
        return new JAXBElement<String>(_FgAttributeRedLinesampleText_QNAME, String.class, FgAttribute.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "testCycle", scope = FgAttribute.class)
    public JAXBElement<String> createFgAttributeTestCycle(String value) {
        return new JAXBElement<String>(_FgAttributeTestCycle_QNAME, String.class, FgAttribute.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesampleList", scope = FgAttribute.class)
    public JAXBElement<String> createFgAttributeRedLinesampleList(String value) {
        return new JAXBElement<String>(_FgAttributeRedLinesampleList_QNAME, String.class, FgAttribute.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "sampleText", scope = FgAttribute.class)
    public JAXBElement<String> createFgAttributeSampleText(String value) {
        return new JAXBElement<String>(_FgAttributeSampleText_QNAME, String.class, FgAttribute.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = FgAttribute.class)
    public JAXBElement<Boolean> createFgAttributeIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, FgAttribute.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "sampleList", scope = FgAttribute.class)
    public JAXBElement<String> createFgAttributeSampleList(String value) {
        return new JAXBElement<String>(_FgAttributeSampleList_QNAME, String.class, FgAttribute.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = HumanPharmacokineticPkStudies.class)
    public JAXBElement<Boolean> createHumanPharmacokineticPkStudiesIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, HumanPharmacokineticPkStudies.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineprojectName", scope = HumanPharmacokineticPkStudies.class)
    public JAXBElement<String> createHumanPharmacokineticPkStudiesRedLineprojectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLineprojectName_QNAME, String.class, HumanPharmacokineticPkStudies.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = HumanPharmacokineticPkStudies.class)
    public JAXBElement<String> createHumanPharmacokineticPkStudiesRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, HumanPharmacokineticPkStudies.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "subGroup", scope = HumanPharmacokineticPkStudies.class)
    public JAXBElement<String> createHumanPharmacokineticPkStudiesSubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsSubGroup_QNAME, String.class, HumanPharmacokineticPkStudies.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = HumanPharmacokineticPkStudies.class)
    public JAXBElement<String> createHumanPharmacokineticPkStudiesBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, HumanPharmacokineticPkStudies.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = HumanPharmacokineticPkStudies.class)
    public JAXBElement<Boolean> createHumanPharmacokineticPkStudiesIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, HumanPharmacokineticPkStudies.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesubGroup", scope = HumanPharmacokineticPkStudies.class)
    public JAXBElement<String> createHumanPharmacokineticPkStudiesRedLinesubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLinesubGroup_QNAME, String.class, HumanPharmacokineticPkStudies.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = HumanPharmacokineticPkStudies.class)
    public JAXBElement<Boolean> createHumanPharmacokineticPkStudiesIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, HumanPharmacokineticPkStudies.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "projectName", scope = HumanPharmacokineticPkStudies.class)
    public JAXBElement<String> createHumanPharmacokineticPkStudiesProjectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsProjectName_QNAME, String.class, HumanPharmacokineticPkStudies.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = AgileWizardDetails.class)
    public JAXBElement<Boolean> createAgileWizardDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, AgileWizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = AgileWizardDetails.class)
    public JAXBElement<String> createAgileWizardDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, AgileWizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineAssignmentComments", scope = AgileWizardDetails.class)
    public JAXBElement<String> createAgileWizardDetailsRedLineAssignmentComments(String value) {
        return new JAXBElement<String>(_AgileWizardDetailsRedLineAssignmentComments_QNAME, String.class, AgileWizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = AgileWizardDetails.class)
    public JAXBElement<String> createAgileWizardDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, AgileWizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineCurrentScreen", scope = AgileWizardDetails.class)
    public JAXBElement<String> createAgileWizardDetailsRedLineCurrentScreen(String value) {
        return new JAXBElement<String>(_AgileWizardDetailsRedLineCurrentScreen_QNAME, String.class, AgileWizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "WizardStatus", scope = AgileWizardDetails.class)
    public JAXBElement<String> createAgileWizardDetailsWizardStatus(String value) {
        return new JAXBElement<String>(_WizardDetailsWizardStatus_QNAME, String.class, AgileWizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineIsTemplate", scope = AgileWizardDetails.class)
    public JAXBElement<String> createAgileWizardDetailsRedLineIsTemplate(String value) {
        return new JAXBElement<String>(_WizardDetailsRedLineIsTemplate_QNAME, String.class, AgileWizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = AgileWizardDetails.class)
    public JAXBElement<Boolean> createAgileWizardDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, AgileWizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsTemplate", scope = AgileWizardDetails.class)
    public JAXBElement<String> createAgileWizardDetailsIsTemplate(String value) {
        return new JAXBElement<String>(_WizardDetailsIsTemplate_QNAME, String.class, AgileWizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "CurrentScreen", scope = AgileWizardDetails.class)
    public JAXBElement<String> createAgileWizardDetailsCurrentScreen(String value) {
        return new JAXBElement<String>(_AgileWizardDetailsCurrentScreen_QNAME, String.class, AgileWizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = AgileWizardDetails.class)
    public JAXBElement<Boolean> createAgileWizardDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, AgileWizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineWizardStatus", scope = AgileWizardDetails.class)
    public JAXBElement<String> createAgileWizardDetailsRedLineWizardStatus(String value) {
        return new JAXBElement<String>(_WizardDetailsRedLineWizardStatus_QNAME, String.class, AgileWizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "AssignmentComments", scope = AgileWizardDetails.class)
    public JAXBElement<String> createAgileWizardDetailsAssignmentComments(String value) {
        return new JAXBElement<String>(_AgileWizardDetailsAssignmentComments_QNAME, String.class, AgileWizardDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = TestAttributes.class)
    public JAXBElement<Boolean> createTestAttributesIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, TestAttributes.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesubsetList", scope = TestAttributes.class)
    public JAXBElement<String> createTestAttributesRedLinesubsetList(String value) {
        return new JAXBElement<String>(_TestAttributesRedLinesubsetList_QNAME, String.class, TestAttributes.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = TestAttributes.class)
    public JAXBElement<String> createTestAttributesRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, TestAttributes.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "independentValues", scope = TestAttributes.class)
    public JAXBElement<String> createTestAttributesIndependentValues(String value) {
        return new JAXBElement<String>(_TestAttributesIndependentValues_QNAME, String.class, TestAttributes.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = TestAttributes.class)
    public JAXBElement<String> createTestAttributesBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, TestAttributes.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "formatonly", scope = TestAttributes.class)
    public JAXBElement<String> createTestAttributesFormatonly(String value) {
        return new JAXBElement<String>(_TestAttributesFormatonly_QNAME, String.class, TestAttributes.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineindependentValues", scope = TestAttributes.class)
    public JAXBElement<String> createTestAttributesRedLineindependentValues(String value) {
        return new JAXBElement<String>(_TestAttributesRedLineindependentValues_QNAME, String.class, TestAttributes.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = TestAttributes.class)
    public JAXBElement<Boolean> createTestAttributesIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, TestAttributes.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineformatonly", scope = TestAttributes.class)
    public JAXBElement<String> createTestAttributesRedLineformatonly(String value) {
        return new JAXBElement<String>(_TestAttributesRedLineformatonly_QNAME, String.class, TestAttributes.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "dependentList", scope = TestAttributes.class)
    public JAXBElement<String> createTestAttributesDependentList(String value) {
        return new JAXBElement<String>(_TestAttributesDependentList_QNAME, String.class, TestAttributes.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = TestAttributes.class)
    public JAXBElement<Boolean> createTestAttributesIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, TestAttributes.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "subsetList", scope = TestAttributes.class)
    public JAXBElement<String> createTestAttributesSubsetList(String value) {
        return new JAXBElement<String>(_TestAttributesSubsetList_QNAME, String.class, TestAttributes.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinedependentList", scope = TestAttributes.class)
    public JAXBElement<String> createTestAttributesRedLinedependentList(String value) {
        return new JAXBElement<String>(_TestAttributesRedLinedependentList_QNAME, String.class, TestAttributes.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = AdministrativeInformationDetai.class)
    public JAXBElement<Boolean> createAdministrativeInformationDetaiIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, AdministrativeInformationDetai.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineprojectName", scope = AdministrativeInformationDetai.class)
    public JAXBElement<String> createAdministrativeInformationDetaiRedLineprojectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLineprojectName_QNAME, String.class, AdministrativeInformationDetai.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = AdministrativeInformationDetai.class)
    public JAXBElement<String> createAdministrativeInformationDetaiRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, AdministrativeInformationDetai.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "subGroup", scope = AdministrativeInformationDetai.class)
    public JAXBElement<String> createAdministrativeInformationDetaiSubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsSubGroup_QNAME, String.class, AdministrativeInformationDetai.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = AdministrativeInformationDetai.class)
    public JAXBElement<String> createAdministrativeInformationDetaiBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, AdministrativeInformationDetai.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = AdministrativeInformationDetai.class)
    public JAXBElement<Boolean> createAdministrativeInformationDetaiIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, AdministrativeInformationDetai.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesubGroup", scope = AdministrativeInformationDetai.class)
    public JAXBElement<String> createAdministrativeInformationDetaiRedLinesubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLinesubGroup_QNAME, String.class, AdministrativeInformationDetai.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = AdministrativeInformationDetai.class)
    public JAXBElement<Boolean> createAdministrativeInformationDetaiIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, AdministrativeInformationDetai.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "projectName", scope = AdministrativeInformationDetai.class)
    public JAXBElement<String> createAdministrativeInformationDetaiProjectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsProjectName_QNAME, String.class, AdministrativeInformationDetai.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = QualityInformationDetails.class)
    public JAXBElement<Boolean> createQualityInformationDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, QualityInformationDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineprojectName", scope = QualityInformationDetails.class)
    public JAXBElement<String> createQualityInformationDetailsRedLineprojectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLineprojectName_QNAME, String.class, QualityInformationDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = QualityInformationDetails.class)
    public JAXBElement<String> createQualityInformationDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, QualityInformationDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "subGroup", scope = QualityInformationDetails.class)
    public JAXBElement<String> createQualityInformationDetailsSubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsSubGroup_QNAME, String.class, QualityInformationDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = QualityInformationDetails.class)
    public JAXBElement<String> createQualityInformationDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, QualityInformationDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = QualityInformationDetails.class)
    public JAXBElement<Boolean> createQualityInformationDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, QualityInformationDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesubGroup", scope = QualityInformationDetails.class)
    public JAXBElement<String> createQualityInformationDetailsRedLinesubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLinesubGroup_QNAME, String.class, QualityInformationDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = QualityInformationDetails.class)
    public JAXBElement<Boolean> createQualityInformationDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, QualityInformationDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "projectName", scope = QualityInformationDetails.class)
    public JAXBElement<String> createQualityInformationDetailsProjectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsProjectName_QNAME, String.class, QualityInformationDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = EnvironmentalGovernanceAndComp.class)
    public JAXBElement<Boolean> createEnvironmentalGovernanceAndCompIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, EnvironmentalGovernanceAndComp.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = EnvironmentalGovernanceAndComp.class)
    public JAXBElement<String> createEnvironmentalGovernanceAndCompRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, EnvironmentalGovernanceAndComp.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = EnvironmentalGovernanceAndComp.class)
    public JAXBElement<String> createEnvironmentalGovernanceAndCompBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, EnvironmentalGovernanceAndComp.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinedeclarationStatus", scope = EnvironmentalGovernanceAndComp.class)
    public JAXBElement<String> createEnvironmentalGovernanceAndCompRedLinedeclarationStatus(String value) {
        return new JAXBElement<String>(_EnvironmentalGovernanceAndCompRedLinedeclarationStatus_QNAME, String.class, EnvironmentalGovernanceAndComp.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = EnvironmentalGovernanceAndComp.class)
    public JAXBElement<Boolean> createEnvironmentalGovernanceAndCompIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, EnvironmentalGovernanceAndComp.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "declarationStatus", scope = EnvironmentalGovernanceAndComp.class)
    public JAXBElement<String> createEnvironmentalGovernanceAndCompDeclarationStatus(String value) {
        return new JAXBElement<String>(_EnvironmentalGovernanceAndCompDeclarationStatus_QNAME, String.class, EnvironmentalGovernanceAndComp.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = EnvironmentalGovernanceAndComp.class)
    public JAXBElement<Boolean> createEnvironmentalGovernanceAndCompIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, EnvironmentalGovernanceAndComp.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = BiopharmaceuticStudyReports.class)
    public JAXBElement<Boolean> createBiopharmaceuticStudyReportsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, BiopharmaceuticStudyReports.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineprojectName", scope = BiopharmaceuticStudyReports.class)
    public JAXBElement<String> createBiopharmaceuticStudyReportsRedLineprojectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLineprojectName_QNAME, String.class, BiopharmaceuticStudyReports.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = BiopharmaceuticStudyReports.class)
    public JAXBElement<String> createBiopharmaceuticStudyReportsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, BiopharmaceuticStudyReports.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "subGroup", scope = BiopharmaceuticStudyReports.class)
    public JAXBElement<String> createBiopharmaceuticStudyReportsSubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsSubGroup_QNAME, String.class, BiopharmaceuticStudyReports.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = BiopharmaceuticStudyReports.class)
    public JAXBElement<String> createBiopharmaceuticStudyReportsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, BiopharmaceuticStudyReports.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = BiopharmaceuticStudyReports.class)
    public JAXBElement<Boolean> createBiopharmaceuticStudyReportsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, BiopharmaceuticStudyReports.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesubGroup", scope = BiopharmaceuticStudyReports.class)
    public JAXBElement<String> createBiopharmaceuticStudyReportsRedLinesubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLinesubGroup_QNAME, String.class, BiopharmaceuticStudyReports.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = BiopharmaceuticStudyReports.class)
    public JAXBElement<Boolean> createBiopharmaceuticStudyReportsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, BiopharmaceuticStudyReports.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "projectName", scope = BiopharmaceuticStudyReports.class)
    public JAXBElement<String> createBiopharmaceuticStudyReportsProjectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsProjectName_QNAME, String.class, BiopharmaceuticStudyReports.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = DmrSection.class)
    public JAXBElement<Boolean> createDmrSectionIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, DmrSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinedmrSection", scope = DmrSection.class)
    public JAXBElement<String> createDmrSectionRedLinedmrSection(String value) {
        return new JAXBElement<String>(_DmrSectionRedLinedmrSection_QNAME, String.class, DmrSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = DmrSection.class)
    public JAXBElement<String> createDmrSectionRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, DmrSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = DmrSection.class)
    public JAXBElement<String> createDmrSectionBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, DmrSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = DmrSection.class)
    public JAXBElement<Boolean> createDmrSectionIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, DmrSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "dmrSection", scope = DmrSection.class)
    public JAXBElement<String> createDmrSectionDmrSection(String value) {
        return new JAXBElement<String>(_DmrSection_QNAME, String.class, DmrSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = DmrSection.class)
    public JAXBElement<Boolean> createDmrSectionIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, DmrSection.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = AssemblyInstructions.class)
    public JAXBElement<Boolean> createAssemblyInstructionsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, AssemblyInstructions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineassemblyInstructions", scope = AssemblyInstructions.class)
    public JAXBElement<String> createAssemblyInstructionsRedLineassemblyInstructions(String value) {
        return new JAXBElement<String>(_AssemblyInstructionsRedLineassemblyInstructions_QNAME, String.class, AssemblyInstructions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinecolor", scope = AssemblyInstructions.class)
    public JAXBElement<String> createAssemblyInstructionsRedLinecolor(String value) {
        return new JAXBElement<String>(_VariantPropertiesRedLinecolor_QNAME, String.class, AssemblyInstructions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = AssemblyInstructions.class)
    public JAXBElement<String> createAssemblyInstructionsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, AssemblyInstructions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = AssemblyInstructions.class)
    public JAXBElement<String> createAssemblyInstructionsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, AssemblyInstructions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "attribute", scope = AssemblyInstructions.class)
    public JAXBElement<String> createAssemblyInstructionsAttribute(String value) {
        return new JAXBElement<String>(_AssemblyInstructionsAttribute_QNAME, String.class, AssemblyInstructions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "assemblyInstructions", scope = AssemblyInstructions.class)
    public JAXBElement<String> createAssemblyInstructionsAssemblyInstructions(String value) {
        return new JAXBElement<String>(_AssemblyInstructions_QNAME, String.class, AssemblyInstructions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = AssemblyInstructions.class)
    public JAXBElement<Boolean> createAssemblyInstructionsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, AssemblyInstructions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineattribute", scope = AssemblyInstructions.class)
    public JAXBElement<String> createAssemblyInstructionsRedLineattribute(String value) {
        return new JAXBElement<String>(_AssemblyInstructionsRedLineattribute_QNAME, String.class, AssemblyInstructions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = AssemblyInstructions.class)
    public JAXBElement<Boolean> createAssemblyInstructionsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, AssemblyInstructions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "test", scope = AssemblyInstructions.class)
    public JAXBElement<String> createAssemblyInstructionsTest(String value) {
        return new JAXBElement<String>(_AssemblyInstructionsTest_QNAME, String.class, AssemblyInstructions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "color", scope = AssemblyInstructions.class)
    public JAXBElement<String> createAssemblyInstructionsColor(String value) {
        return new JAXBElement<String>(_VariantPropertiesColor_QNAME, String.class, AssemblyInstructions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinetest", scope = AssemblyInstructions.class)
    public JAXBElement<String> createAssemblyInstructionsRedLinetest(String value) {
        return new JAXBElement<String>(_AssemblyInstructionsRedLinetest_QNAME, String.class, AssemblyInstructions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = SOPDocumentDetails.class)
    public JAXBElement<Boolean> createSOPDocumentDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, SOPDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "DepartmentGroup2", scope = SOPDocumentDetails.class)
    public JAXBElement<String> createSOPDocumentDetailsDepartmentGroup2(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsDepartmentGroup2_QNAME, String.class, SOPDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "DepartmentGroup1", scope = SOPDocumentDetails.class)
    public JAXBElement<String> createSOPDocumentDetailsDepartmentGroup1(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsDepartmentGroup1_QNAME, String.class, SOPDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "DepartmentGroup3", scope = SOPDocumentDetails.class)
    public JAXBElement<String> createSOPDocumentDetailsDepartmentGroup3(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsDepartmentGroup3_QNAME, String.class, SOPDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = SOPDocumentDetails.class)
    public JAXBElement<String> createSOPDocumentDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, SOPDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineDepartmentGroup2", scope = SOPDocumentDetails.class)
    public JAXBElement<String> createSOPDocumentDetailsRedLineDepartmentGroup2(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRedLineDepartmentGroup2_QNAME, String.class, SOPDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineAccountTypes", scope = SOPDocumentDetails.class)
    public JAXBElement<String> createSOPDocumentDetailsRedLineAccountTypes(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRedLineAccountTypes_QNAME, String.class, SOPDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineDepartmentGroup3", scope = SOPDocumentDetails.class)
    public JAXBElement<String> createSOPDocumentDetailsRedLineDepartmentGroup3(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRedLineDepartmentGroup3_QNAME, String.class, SOPDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = SOPDocumentDetails.class)
    public JAXBElement<String> createSOPDocumentDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, SOPDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineDepartmentGroup1", scope = SOPDocumentDetails.class)
    public JAXBElement<String> createSOPDocumentDetailsRedLineDepartmentGroup1(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRedLineDepartmentGroup1_QNAME, String.class, SOPDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = SOPDocumentDetails.class)
    public JAXBElement<Boolean> createSOPDocumentDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, SOPDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineDocumentCategory", scope = SOPDocumentDetails.class)
    public JAXBElement<String> createSOPDocumentDetailsRedLineDocumentCategory(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRedLineDocumentCategory_QNAME, String.class, SOPDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineRecordDetails", scope = SOPDocumentDetails.class)
    public JAXBElement<String> createSOPDocumentDetailsRedLineRecordDetails(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRedLineRecordDetails_QNAME, String.class, SOPDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = SOPDocumentDetails.class)
    public JAXBElement<Boolean> createSOPDocumentDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, SOPDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RecordDetails", scope = SOPDocumentDetails.class)
    public JAXBElement<String> createSOPDocumentDetailsRecordDetails(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsRecordDetails_QNAME, String.class, SOPDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "DocumentCategory", scope = SOPDocumentDetails.class)
    public JAXBElement<String> createSOPDocumentDetailsDocumentCategory(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsDocumentCategory_QNAME, String.class, SOPDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "AccountTypes", scope = SOPDocumentDetails.class)
    public JAXBElement<String> createSOPDocumentDetailsAccountTypes(String value) {
        return new JAXBElement<String>(_PCBSpecsDetailsAccountTypes_QNAME, String.class, SOPDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = UnitProperties.class)
    public JAXBElement<Boolean> createUnitPropertiesIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, UnitProperties.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinecolor", scope = UnitProperties.class)
    public JAXBElement<String> createUnitPropertiesRedLinecolor(String value) {
        return new JAXBElement<String>(_VariantPropertiesRedLinecolor_QNAME, String.class, UnitProperties.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = UnitProperties.class)
    public JAXBElement<String> createUnitPropertiesRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, UnitProperties.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = UnitProperties.class)
    public JAXBElement<String> createUnitPropertiesBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, UnitProperties.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = UnitProperties.class)
    public JAXBElement<Boolean> createUnitPropertiesIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, UnitProperties.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "color", scope = UnitProperties.class)
    public JAXBElement<String> createUnitPropertiesColor(String value) {
        return new JAXBElement<String>(_VariantPropertiesColor_QNAME, String.class, UnitProperties.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "size", scope = UnitProperties.class)
    public JAXBElement<String> createUnitPropertiesSize(String value) {
        return new JAXBElement<String>(_CellSectionSize_QNAME, String.class, UnitProperties.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesize", scope = UnitProperties.class)
    public JAXBElement<String> createUnitPropertiesRedLinesize(String value) {
        return new JAXBElement<String>(_CellSectionRedLinesize_QNAME, String.class, UnitProperties.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = UnitProperties.class)
    public JAXBElement<Boolean> createUnitPropertiesIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, UnitProperties.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = TransistorFETDetails.class)
    public JAXBElement<Boolean> createTransistorFETDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, TransistorFETDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineTransistorType", scope = TransistorFETDetails.class)
    public JAXBElement<String> createTransistorFETDetailsRedLineTransistorType(String value) {
        return new JAXBElement<String>(_TransistorFETDetailsRedLineTransistorType_QNAME, String.class, TransistorFETDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = TransistorFETDetails.class)
    public JAXBElement<String> createTransistorFETDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, TransistorFETDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineIsBipolar", scope = TransistorFETDetails.class)
    public JAXBElement<String> createTransistorFETDetailsRedLineIsBipolar(String value) {
        return new JAXBElement<String>(_TransistorFETDetailsRedLineIsBipolar_QNAME, String.class, TransistorFETDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = TransistorFETDetails.class)
    public JAXBElement<String> createTransistorFETDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, TransistorFETDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = TransistorFETDetails.class)
    public JAXBElement<Boolean> createTransistorFETDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, TransistorFETDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "TransistorType", scope = TransistorFETDetails.class)
    public JAXBElement<String> createTransistorFETDetailsTransistorType(String value) {
        return new JAXBElement<String>(_TransistorFETDetailsTransistorType_QNAME, String.class, TransistorFETDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = TransistorFETDetails.class)
    public JAXBElement<Boolean> createTransistorFETDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, TransistorFETDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsBipolar", scope = TransistorFETDetails.class)
    public JAXBElement<String> createTransistorFETDetailsIsBipolar(String value) {
        return new JAXBElement<String>(_TransistorFETDetailsIsBipolar_QNAME, String.class, TransistorFETDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = LabelingDetails.class)
    public JAXBElement<Boolean> createLabelingDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, LabelingDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineprojectName", scope = LabelingDetails.class)
    public JAXBElement<String> createLabelingDetailsRedLineprojectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLineprojectName_QNAME, String.class, LabelingDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = LabelingDetails.class)
    public JAXBElement<String> createLabelingDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, LabelingDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "subGroup", scope = LabelingDetails.class)
    public JAXBElement<String> createLabelingDetailsSubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsSubGroup_QNAME, String.class, LabelingDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = LabelingDetails.class)
    public JAXBElement<String> createLabelingDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, LabelingDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = LabelingDetails.class)
    public JAXBElement<Boolean> createLabelingDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, LabelingDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesubGroup", scope = LabelingDetails.class)
    public JAXBElement<String> createLabelingDetailsRedLinesubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLinesubGroup_QNAME, String.class, LabelingDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = LabelingDetails.class)
    public JAXBElement<Boolean> createLabelingDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, LabelingDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "projectName", scope = LabelingDetails.class)
    public JAXBElement<String> createLabelingDetailsProjectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsProjectName_QNAME, String.class, LabelingDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = DhfDetails.class)
    public JAXBElement<Boolean> createDhfDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, DhfDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "comments", scope = DhfDetails.class)
    public JAXBElement<String> createDhfDetailsComments(String value) {
        return new JAXBElement<String>(_Comments_QNAME, String.class, DhfDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineapprovalFunctions", scope = DhfDetails.class)
    public JAXBElement<String> createDhfDetailsRedLineapprovalFunctions(String value) {
        return new JAXBElement<String>(_DhfDetailsRedLineapprovalFunctions_QNAME, String.class, DhfDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = DhfDetails.class)
    public JAXBElement<String> createDhfDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, DhfDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = DhfDetails.class)
    public JAXBElement<String> createDhfDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, DhfDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = DhfDetails.class)
    public JAXBElement<Boolean> createDhfDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, DhfDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "approvalFunctions", scope = DhfDetails.class)
    public JAXBElement<String> createDhfDetailsApprovalFunctions(String value) {
        return new JAXBElement<String>(_DhfDetailsApprovalFunctions_QNAME, String.class, DhfDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinecomments", scope = DhfDetails.class)
    public JAXBElement<String> createDhfDetailsRedLinecomments(String value) {
        return new JAXBElement<String>(_DhfDetailsRedLinecomments_QNAME, String.class, DhfDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = DhfDetails.class)
    public JAXBElement<Boolean> createDhfDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, DhfDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = LiteratureReferenceDetails.class)
    public JAXBElement<Boolean> createLiteratureReferenceDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, LiteratureReferenceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineprojectName", scope = LiteratureReferenceDetails.class)
    public JAXBElement<String> createLiteratureReferenceDetailsRedLineprojectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLineprojectName_QNAME, String.class, LiteratureReferenceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = LiteratureReferenceDetails.class)
    public JAXBElement<String> createLiteratureReferenceDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, LiteratureReferenceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "subGroup", scope = LiteratureReferenceDetails.class)
    public JAXBElement<String> createLiteratureReferenceDetailsSubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsSubGroup_QNAME, String.class, LiteratureReferenceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = LiteratureReferenceDetails.class)
    public JAXBElement<String> createLiteratureReferenceDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, LiteratureReferenceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = LiteratureReferenceDetails.class)
    public JAXBElement<Boolean> createLiteratureReferenceDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, LiteratureReferenceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesubGroup", scope = LiteratureReferenceDetails.class)
    public JAXBElement<String> createLiteratureReferenceDetailsRedLinesubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLinesubGroup_QNAME, String.class, LiteratureReferenceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = LiteratureReferenceDetails.class)
    public JAXBElement<Boolean> createLiteratureReferenceDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, LiteratureReferenceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "projectName", scope = LiteratureReferenceDetails.class)
    public JAXBElement<String> createLiteratureReferenceDetailsProjectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsProjectName_QNAME, String.class, LiteratureReferenceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = StyleSKU.class)
    public JAXBElement<Boolean> createStyleSKUIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, StyleSKU.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = StyleSKU.class)
    public JAXBElement<String> createStyleSKURaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, StyleSKU.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = StyleSKU.class)
    public JAXBElement<String> createStyleSKUBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, StyleSKU.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = StyleSKU.class)
    public JAXBElement<Boolean> createStyleSKUIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, StyleSKU.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "text", scope = StyleSKU.class)
    public JAXBElement<String> createStyleSKUText(String value) {
        return new JAXBElement<String>(_ModuleDetailsText_QNAME, String.class, StyleSKU.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinetext", scope = StyleSKU.class)
    public JAXBElement<String> createStyleSKURedLinetext(String value) {
        return new JAXBElement<String>(_ModuleDetailsRedLinetext_QNAME, String.class, StyleSKU.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = StyleSKU.class)
    public JAXBElement<Boolean> createStyleSKUIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, StyleSKU.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = MultiRow.class)
    public JAXBElement<Boolean> createMultiRowIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, MultiRow.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = MultiRow.class)
    public JAXBElement<String> createMultiRowRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, MultiRow.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = MultiRow.class)
    public JAXBElement<String> createMultiRowBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, MultiRow.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = MultiRow.class)
    public JAXBElement<Boolean> createMultiRowIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, MultiRow.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinespecs", scope = MultiRow.class)
    public JAXBElement<String> createMultiRowRedLinespecs(String value) {
        return new JAXBElement<String>(_MultiRowRedLinespecs_QNAME, String.class, MultiRow.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = MultiRow.class)
    public JAXBElement<Boolean> createMultiRowIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, MultiRow.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = ZtestGroup.class)
    public JAXBElement<Boolean> createZtestGroupIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, ZtestGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineztest2", scope = ZtestGroup.class)
    public JAXBElement<String> createZtestGroupRedLineztest2(String value) {
        return new JAXBElement<String>(_ZtestGroupRedLineztest2_QNAME, String.class, ZtestGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineSurfaceMountDeviceSAP", scope = ZtestGroup.class)
    public JAXBElement<String> createZtestGroupRedLineSurfaceMountDeviceSAP(String value) {
        return new JAXBElement<String>(_ZtestGroupRedLineSurfaceMountDeviceSAP_QNAME, String.class, ZtestGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = ZtestGroup.class)
    public JAXBElement<String> createZtestGroupRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, ZtestGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "ztest2", scope = ZtestGroup.class)
    public JAXBElement<String> createZtestGroupZtest2(String value) {
        return new JAXBElement<String>(_ZtestGroupZtest2_QNAME, String.class, ZtestGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineztest3", scope = ZtestGroup.class)
    public JAXBElement<String> createZtestGroupRedLineztest3(String value) {
        return new JAXBElement<String>(_ZtestGroupRedLineztest3_QNAME, String.class, ZtestGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "ztest3", scope = ZtestGroup.class)
    public JAXBElement<String> createZtestGroupZtest3(String value) {
        return new JAXBElement<String>(_ZtestGroupZtest3_QNAME, String.class, ZtestGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = ZtestGroup.class)
    public JAXBElement<String> createZtestGroupBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, ZtestGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = ZtestGroup.class)
    public JAXBElement<Boolean> createZtestGroupIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, ZtestGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "SurfaceMountDeviceSAP", scope = ZtestGroup.class)
    public JAXBElement<String> createZtestGroupSurfaceMountDeviceSAP(String value) {
        return new JAXBElement<String>(_ZtestGroupSurfaceMountDeviceSAP_QNAME, String.class, ZtestGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = ZtestGroup.class)
    public JAXBElement<Boolean> createZtestGroupIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, ZtestGroup.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = InternalDocumentDetails.class)
    public JAXBElement<Boolean> createInternalDocumentDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, InternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "ExternalDocumentTitle", scope = InternalDocumentDetails.class)
    public JAXBElement<String> createInternalDocumentDetailsExternalDocumentTitle(String value) {
        return new JAXBElement<String>(_DatasheetsDetailsExternalDocumentTitle_QNAME, String.class, InternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "ExternalDocumentNumber", scope = InternalDocumentDetails.class)
    public JAXBElement<String> createInternalDocumentDetailsExternalDocumentNumber(String value) {
        return new JAXBElement<String>(_DatasheetsDetailsExternalDocumentNumber_QNAME, String.class, InternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = InternalDocumentDetails.class)
    public JAXBElement<String> createInternalDocumentDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, InternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = InternalDocumentDetails.class)
    public JAXBElement<String> createInternalDocumentDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, InternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = InternalDocumentDetails.class)
    public JAXBElement<Boolean> createInternalDocumentDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, InternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "ExternalDocumentRev", scope = InternalDocumentDetails.class)
    public JAXBElement<String> createInternalDocumentDetailsExternalDocumentRev(String value) {
        return new JAXBElement<String>(_DatasheetsDetailsExternalDocumentRev_QNAME, String.class, InternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineExternalDocumentTitle", scope = InternalDocumentDetails.class)
    public JAXBElement<String> createInternalDocumentDetailsRedLineExternalDocumentTitle(String value) {
        return new JAXBElement<String>(_DatasheetsDetailsRedLineExternalDocumentTitle_QNAME, String.class, InternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineExternalDocumentRev", scope = InternalDocumentDetails.class)
    public JAXBElement<String> createInternalDocumentDetailsRedLineExternalDocumentRev(String value) {
        return new JAXBElement<String>(_DatasheetsDetailsRedLineExternalDocumentRev_QNAME, String.class, InternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineExternalDocumentNumber", scope = InternalDocumentDetails.class)
    public JAXBElement<String> createInternalDocumentDetailsRedLineExternalDocumentNumber(String value) {
        return new JAXBElement<String>(_DatasheetsDetailsRedLineExternalDocumentNumber_QNAME, String.class, InternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = InternalDocumentDetails.class)
    public JAXBElement<Boolean> createInternalDocumentDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, InternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = AdventitiousAgentsDetails.class)
    public JAXBElement<Boolean> createAdventitiousAgentsDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, AdventitiousAgentsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineprojectName", scope = AdventitiousAgentsDetails.class)
    public JAXBElement<String> createAdventitiousAgentsDetailsRedLineprojectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLineprojectName_QNAME, String.class, AdventitiousAgentsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = AdventitiousAgentsDetails.class)
    public JAXBElement<String> createAdventitiousAgentsDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, AdventitiousAgentsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "subGroup", scope = AdventitiousAgentsDetails.class)
    public JAXBElement<String> createAdventitiousAgentsDetailsSubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsSubGroup_QNAME, String.class, AdventitiousAgentsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = AdventitiousAgentsDetails.class)
    public JAXBElement<String> createAdventitiousAgentsDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, AdventitiousAgentsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = AdventitiousAgentsDetails.class)
    public JAXBElement<Boolean> createAdventitiousAgentsDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, AdventitiousAgentsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesubGroup", scope = AdventitiousAgentsDetails.class)
    public JAXBElement<String> createAdventitiousAgentsDetailsRedLinesubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLinesubGroup_QNAME, String.class, AdventitiousAgentsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = AdventitiousAgentsDetails.class)
    public JAXBElement<Boolean> createAdventitiousAgentsDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, AdventitiousAgentsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "projectName", scope = AdventitiousAgentsDetails.class)
    public JAXBElement<String> createAdventitiousAgentsDetailsProjectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsProjectName_QNAME, String.class, AdventitiousAgentsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = SummariesDetails.class)
    public JAXBElement<Boolean> createSummariesDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, SummariesDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineprojectName", scope = SummariesDetails.class)
    public JAXBElement<String> createSummariesDetailsRedLineprojectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLineprojectName_QNAME, String.class, SummariesDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = SummariesDetails.class)
    public JAXBElement<String> createSummariesDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, SummariesDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "subGroup", scope = SummariesDetails.class)
    public JAXBElement<String> createSummariesDetailsSubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsSubGroup_QNAME, String.class, SummariesDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = SummariesDetails.class)
    public JAXBElement<String> createSummariesDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, SummariesDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = SummariesDetails.class)
    public JAXBElement<Boolean> createSummariesDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, SummariesDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesubGroup", scope = SummariesDetails.class)
    public JAXBElement<String> createSummariesDetailsRedLinesubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLinesubGroup_QNAME, String.class, SummariesDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = SummariesDetails.class)
    public JAXBElement<Boolean> createSummariesDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, SummariesDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "projectName", scope = SummariesDetails.class)
    public JAXBElement<String> createSummariesDetailsProjectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsProjectName_QNAME, String.class, SummariesDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = ExternalDocumentDetails.class)
    public JAXBElement<Boolean> createExternalDocumentDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, ExternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "ExternalDocumentTitle", scope = ExternalDocumentDetails.class)
    public JAXBElement<String> createExternalDocumentDetailsExternalDocumentTitle(String value) {
        return new JAXBElement<String>(_DatasheetsDetailsExternalDocumentTitle_QNAME, String.class, ExternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "ExternalDocumentNumber", scope = ExternalDocumentDetails.class)
    public JAXBElement<String> createExternalDocumentDetailsExternalDocumentNumber(String value) {
        return new JAXBElement<String>(_DatasheetsDetailsExternalDocumentNumber_QNAME, String.class, ExternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = ExternalDocumentDetails.class)
    public JAXBElement<String> createExternalDocumentDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, ExternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = ExternalDocumentDetails.class)
    public JAXBElement<String> createExternalDocumentDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, ExternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = ExternalDocumentDetails.class)
    public JAXBElement<Boolean> createExternalDocumentDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, ExternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "ExternalDocumentRev", scope = ExternalDocumentDetails.class)
    public JAXBElement<String> createExternalDocumentDetailsExternalDocumentRev(String value) {
        return new JAXBElement<String>(_DatasheetsDetailsExternalDocumentRev_QNAME, String.class, ExternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineExternalDocumentTitle", scope = ExternalDocumentDetails.class)
    public JAXBElement<String> createExternalDocumentDetailsRedLineExternalDocumentTitle(String value) {
        return new JAXBElement<String>(_DatasheetsDetailsRedLineExternalDocumentTitle_QNAME, String.class, ExternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineExternalDocumentRev", scope = ExternalDocumentDetails.class)
    public JAXBElement<String> createExternalDocumentDetailsRedLineExternalDocumentRev(String value) {
        return new JAXBElement<String>(_DatasheetsDetailsRedLineExternalDocumentRev_QNAME, String.class, ExternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineExternalDocumentNumber", scope = ExternalDocumentDetails.class)
    public JAXBElement<String> createExternalDocumentDetailsRedLineExternalDocumentNumber(String value) {
        return new JAXBElement<String>(_DatasheetsDetailsRedLineExternalDocumentNumber_QNAME, String.class, ExternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = ExternalDocumentDetails.class)
    public JAXBElement<Boolean> createExternalDocumentDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, ExternalDocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = SOPDetails.class)
    public JAXBElement<Boolean> createSOPDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, SOPDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "Category", scope = SOPDetails.class)
    public JAXBElement<String> createSOPDetailsCategory(String value) {
        return new JAXBElement<String>(_SOPProcedureDetailsCategory_QNAME, String.class, SOPDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = SOPDetails.class)
    public JAXBElement<String> createSOPDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, SOPDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = SOPDetails.class)
    public JAXBElement<String> createSOPDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, SOPDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = SOPDetails.class)
    public JAXBElement<Boolean> createSOPDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, SOPDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineNotes", scope = SOPDetails.class)
    public JAXBElement<String> createSOPDetailsRedLineNotes(String value) {
        return new JAXBElement<String>(_SOPProcedureDetailsRedLineNotes_QNAME, String.class, SOPDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineCategory", scope = SOPDetails.class)
    public JAXBElement<String> createSOPDetailsRedLineCategory(String value) {
        return new JAXBElement<String>(_SOPProcedureDetailsRedLineCategory_QNAME, String.class, SOPDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "Notes", scope = SOPDetails.class)
    public JAXBElement<String> createSOPDetailsNotes(String value) {
        return new JAXBElement<String>(_SOPProcedureDetailsNotes_QNAME, String.class, SOPDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = SOPDetails.class)
    public JAXBElement<Boolean> createSOPDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, SOPDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = ToxicologyStudyReportsDetails.class)
    public JAXBElement<Boolean> createToxicologyStudyReportsDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, ToxicologyStudyReportsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineprojectName", scope = ToxicologyStudyReportsDetails.class)
    public JAXBElement<String> createToxicologyStudyReportsDetailsRedLineprojectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLineprojectName_QNAME, String.class, ToxicologyStudyReportsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = ToxicologyStudyReportsDetails.class)
    public JAXBElement<String> createToxicologyStudyReportsDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, ToxicologyStudyReportsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "subGroup", scope = ToxicologyStudyReportsDetails.class)
    public JAXBElement<String> createToxicologyStudyReportsDetailsSubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsSubGroup_QNAME, String.class, ToxicologyStudyReportsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = ToxicologyStudyReportsDetails.class)
    public JAXBElement<String> createToxicologyStudyReportsDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, ToxicologyStudyReportsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = ToxicologyStudyReportsDetails.class)
    public JAXBElement<Boolean> createToxicologyStudyReportsDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, ToxicologyStudyReportsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesubGroup", scope = ToxicologyStudyReportsDetails.class)
    public JAXBElement<String> createToxicologyStudyReportsDetailsRedLinesubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLinesubGroup_QNAME, String.class, ToxicologyStudyReportsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = ToxicologyStudyReportsDetails.class)
    public JAXBElement<Boolean> createToxicologyStudyReportsDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, ToxicologyStudyReportsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "projectName", scope = ToxicologyStudyReportsDetails.class)
    public JAXBElement<String> createToxicologyStudyReportsDetailsProjectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsProjectName_QNAME, String.class, ToxicologyStudyReportsDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = TestGroup1 .class)
    public JAXBElement<Boolean> createTestGroup1IsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, TestGroup1 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = TestGroup1 .class)
    public JAXBElement<String> createTestGroup1RaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, TestGroup1 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = TestGroup1 .class)
    public JAXBElement<String> createTestGroup1BulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, TestGroup1 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = TestGroup1 .class)
    public JAXBElement<Boolean> createTestGroup1IsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, TestGroup1 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "testAttribute", scope = TestGroup1 .class)
    public JAXBElement<BigDecimal> createTestGroup1TestAttribute(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_TestGroupTestAttribute_QNAME, BigDecimal.class, TestGroup1 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinetestAttribute", scope = TestGroup1 .class)
    public JAXBElement<String> createTestGroup1RedLinetestAttribute(String value) {
        return new JAXBElement<String>(_TestGroupRedLinetestAttribute_QNAME, String.class, TestGroup1 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = TestGroup1 .class)
    public JAXBElement<Boolean> createTestGroup1IsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, TestGroup1 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = FormulaDetails.class)
    public JAXBElement<Boolean> createFormulaDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, FormulaDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "unit", scope = FormulaDetails.class)
    public JAXBElement<String> createFormulaDetailsUnit(String value) {
        return new JAXBElement<String>(_FormulaDetailsUnit_QNAME, String.class, FormulaDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinestatus", scope = FormulaDetails.class)
    public JAXBElement<String> createFormulaDetailsRedLinestatus(String value) {
        return new JAXBElement<String>(_ComponentDetailsRedLinestatus_QNAME, String.class, FormulaDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineunit", scope = FormulaDetails.class)
    public JAXBElement<String> createFormulaDetailsRedLineunit(String value) {
        return new JAXBElement<String>(_FormulaDetailsRedLineunit_QNAME, String.class, FormulaDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = FormulaDetails.class)
    public JAXBElement<String> createFormulaDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, FormulaDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = FormulaDetails.class)
    public JAXBElement<String> createFormulaDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, FormulaDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "ownership", scope = FormulaDetails.class)
    public JAXBElement<String> createFormulaDetailsOwnership(String value) {
        return new JAXBElement<String>(_FormulaDetailsOwnership_QNAME, String.class, FormulaDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "state", scope = FormulaDetails.class)
    public JAXBElement<String> createFormulaDetailsState(String value) {
        return new JAXBElement<String>(_FormulaDetailsState_QNAME, String.class, FormulaDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "name", scope = FormulaDetails.class)
    public JAXBElement<String> createFormulaDetailsName(String value) {
        return new JAXBElement<String>(_FormulaDetailsName_QNAME, String.class, FormulaDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "status", scope = FormulaDetails.class)
    public JAXBElement<String> createFormulaDetailsStatus(String value) {
        return new JAXBElement<String>(_ComponentDetailsStatus_QNAME, String.class, FormulaDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = FormulaDetails.class)
    public JAXBElement<Boolean> createFormulaDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, FormulaDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinestate", scope = FormulaDetails.class)
    public JAXBElement<String> createFormulaDetailsRedLinestate(String value) {
        return new JAXBElement<String>(_FormulaDetailsRedLinestate_QNAME, String.class, FormulaDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineownership", scope = FormulaDetails.class)
    public JAXBElement<String> createFormulaDetailsRedLineownership(String value) {
        return new JAXBElement<String>(_FormulaDetailsRedLineownership_QNAME, String.class, FormulaDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinename", scope = FormulaDetails.class)
    public JAXBElement<String> createFormulaDetailsRedLinename(String value) {
        return new JAXBElement<String>(_FormulaDetailsRedLinename_QNAME, String.class, FormulaDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = FormulaDetails.class)
    public JAXBElement<Boolean> createFormulaDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, FormulaDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsAddedToChildEntitiesMap", scope = DrugSubstanceDetails.class)
    public JAXBElement<Boolean> createDrugSubstanceDetailsIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsAddedToChildEntitiesMap_QNAME, Boolean.class, DrugSubstanceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLineprojectName", scope = DrugSubstanceDetails.class)
    public JAXBElement<String> createDrugSubstanceDetailsRedLineprojectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLineprojectName_QNAME, String.class, DrugSubstanceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RaiseEvent", scope = DrugSubstanceDetails.class)
    public JAXBElement<String> createDrugSubstanceDetailsRaiseEvent(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRaiseEvent_QNAME, String.class, DrugSubstanceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "subGroup", scope = DrugSubstanceDetails.class)
    public JAXBElement<String> createDrugSubstanceDetailsSubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsSubGroup_QNAME, String.class, DrugSubstanceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "BulkloadRecCreated", scope = DrugSubstanceDetails.class)
    public JAXBElement<String> createDrugSubstanceDetailsBulkloadRecCreated(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsBulkloadRecCreated_QNAME, String.class, DrugSubstanceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsImportCase", scope = DrugSubstanceDetails.class)
    public JAXBElement<Boolean> createDrugSubstanceDetailsIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsImportCase_QNAME, Boolean.class, DrugSubstanceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "RedLinesubGroup", scope = DrugSubstanceDetails.class)
    public JAXBElement<String> createDrugSubstanceDetailsRedLinesubGroup(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsRedLinesubGroup_QNAME, String.class, DrugSubstanceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "IsPersistentAttributeUpdated", scope = DrugSubstanceDetails.class)
    public JAXBElement<Boolean> createDrugSubstanceDetailsIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_ApplicantInformationDetailsIsPersistentAttributeUpdated_QNAME, Boolean.class, DrugSubstanceDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", name = "projectName", scope = DrugSubstanceDetails.class)
    public JAXBElement<String> createDrugSubstanceDetailsProjectName(String value) {
        return new JAXBElement<String>(_ApplicantInformationDetailsProjectName_QNAME, String.class, DrugSubstanceDetails.class, value);
    }

}
