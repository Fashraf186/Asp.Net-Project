
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.Comments;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.ComponentDetails;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.FilledGoodDetails;


/**
 * <p>Java class for Component complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Component">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}j_ItemRootIccPrivate">
 *       &lt;sequence>
 *         &lt;element name="Comments" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}Comments" minOccurs="0"/>
 *         &lt;element name="ComponentDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}ComponentDetails" minOccurs="0"/>
 *         &lt;element name="FilledGoodDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}FilledGoodDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Component", propOrder = {
    "comments",
    "componentDetails",
    "filledGoodDetails"
})
public class Component
    extends JItemRootIccPrivate
{

    @XmlElement(name = "Comments")
    protected Comments comments;
    @XmlElement(name = "ComponentDetails")
    protected ComponentDetails componentDetails;
    @XmlElement(name = "FilledGoodDetails")
    protected FilledGoodDetails filledGoodDetails;

    /**
     * Gets the value of the comments property.
     * 
     * @return
     *     possible object is
     *     {@link Comments }
     *     
     */
    public Comments getComments() {
        return comments;
    }

    /**
     * Sets the value of the comments property.
     * 
     * @param value
     *     allowed object is
     *     {@link Comments }
     *     
     */
    public void setComments(Comments value) {
        this.comments = value;
    }

    /**
     * Gets the value of the componentDetails property.
     * 
     * @return
     *     possible object is
     *     {@link ComponentDetails }
     *     
     */
    public ComponentDetails getComponentDetails() {
        return componentDetails;
    }

    /**
     * Sets the value of the componentDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link ComponentDetails }
     *     
     */
    public void setComponentDetails(ComponentDetails value) {
        this.componentDetails = value;
    }

    /**
     * Gets the value of the filledGoodDetails property.
     * 
     * @return
     *     possible object is
     *     {@link FilledGoodDetails }
     *     
     */
    public FilledGoodDetails getFilledGoodDetails() {
        return filledGoodDetails;
    }

    /**
     * Sets the value of the filledGoodDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link FilledGoodDetails }
     *     
     */
    public void setFilledGoodDetails(FilledGoodDetails value) {
        this.filledGoodDetails = value;
    }

}
