
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.SMSDocumentDetails;


/**
 * <p>Java class for SMSDocument complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SMSDocument">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Document">
 *       &lt;sequence>
 *         &lt;element name="SMSDocumentDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}SMSDocumentDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SMSDocument", propOrder = {
    "smsDocumentDetails"
})
public class SMSDocument
    extends Document
{

    @XmlElement(name = "SMSDocumentDetails")
    protected SMSDocumentDetails smsDocumentDetails;

    /**
     * Gets the value of the smsDocumentDetails property.
     * 
     * @return
     *     possible object is
     *     {@link SMSDocumentDetails }
     *     
     */
    public SMSDocumentDetails getSMSDocumentDetails() {
        return smsDocumentDetails;
    }

    /**
     * Sets the value of the smsDocumentDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link SMSDocumentDetails }
     *     
     */
    public void setSMSDocumentDetails(SMSDocumentDetails value) {
        this.smsDocumentDetails = value;
    }

}
