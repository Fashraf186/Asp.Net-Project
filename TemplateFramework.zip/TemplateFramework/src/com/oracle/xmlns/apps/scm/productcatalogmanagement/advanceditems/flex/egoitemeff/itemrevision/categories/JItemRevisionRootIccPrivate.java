
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.itemrevision.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for j_ItemRevisionRootIccPrivate complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="j_ItemRevisionRootIccPrivate">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/}j_ItemRevisionVersion">
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "j_ItemRevisionRootIccPrivate")
@XmlSeeAlso({
    IngredientN.class,
    ZtestItemClass.class,
    Cto.class,
    KitFg.class,
    ItemSku.class,
    Folder.class,
    Chemical.class,
    FilleGoodssa.class,
    SubstanceGroup.class,
    TestAttributesClass.class,
    Component.class,
    HoverBoard.class,
    PackageAssembly.class,
    PartFamily.class,
    EquipmentFixturesTools.class,
    Fg.class,
    PartParent.class,
    DocumentParent.class,
    Declaration.class,
    Substance.class,
    Specification.class,
    Fbom.class,
    Part.class,
    FinishedGood.class,
    Document.class
})
public class JItemRevisionRootIccPrivate
    extends JItemRevisionVersion
{


}
