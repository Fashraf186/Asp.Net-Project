
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.DmrDetails;


/**
 * <p>Java class for Dmr complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Dmr">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Document">
 *       &lt;sequence>
 *         &lt;element name="DmrDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}DmrDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Dmr", propOrder = {
    "dmrDetails"
})
public class Dmr
    extends Document
{

    @XmlElement(name = "DmrDetails")
    protected DmrDetails dmrDetails;

    /**
     * Gets the value of the dmrDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DmrDetails }
     *     
     */
    public DmrDetails getDmrDetails() {
        return dmrDetails;
    }

    /**
     * Sets the value of the dmrDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmrDetails }
     *     
     */
    public void setDmrDetails(DmrDetails value) {
        this.dmrDetails = value;
    }

}
