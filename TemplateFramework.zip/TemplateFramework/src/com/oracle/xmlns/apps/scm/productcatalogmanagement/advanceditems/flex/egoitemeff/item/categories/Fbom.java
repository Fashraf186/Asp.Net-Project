
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.ComponentDetails;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.DmrSection;


/**
 * <p>Java class for Fbom complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Fbom">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}j_ItemRootIccPrivate">
 *       &lt;sequence>
 *         &lt;element name="DmrSection" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}DmrSection" minOccurs="0"/>
 *         &lt;element name="ComponentDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}ComponentDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Fbom", propOrder = {
    "dmrSection",
    "componentDetails"
})
@XmlSeeAlso({
    PasbeadsleeveFerrite.class,
    PowerSupply.class,
    Fan.class,
    Model.class,
    Disled.class,
    ComputerAccessory.class,
    Adapters.class,
    ProductProcedures.class,
    Pwbpwba.class,
    IcdigitalLogic.class,
    ConnectorPower.class,
    Module.class,
    Icmemoryromflash.class,
    ConnectorPbMounted.class,
    Icasic.class,
    ConnectorheaderAddMal.class,
    ElectromechanicalAssemblies.class,
    FuseComponents.class,
    Drive.class,
    SheetMetal.class,
    Server.class,
    Distransistor.class,
    Feature.class,
    C7Microconvex.class,
    DisfreqCtrlosccrystal.class,
    Power.class,
    Firmware.class,
    OemCdRoms.class,
    Microprocessorsmicroprocessors.class,
    VirtualPhasedArray.class,
    Dhf.class,
    L7Linear.class,
    Pascapacitors.class,
    Pasinductorscoilschoke.class,
    Screws.class,
    Disrectifswitchdiode.class,
    Casing.class,
    MechanicalComponent.class,
    CableHarness.class,
    Cable.class,
    Spare444 .class,
    C3Convex.class,
    WireAssemblySet.class,
    ElectronicSubassemblies.class,
    Pcbpwbs.class,
    ConnectorAdapters.class,
    RegulatoryDocuments.class,
    HearRateMonitor.class,
    Nuts.class,
    Pasresistors.class,
    Manufacturerspinalelement.class,
    Circuitbreaker.class,
    Legacy.class,
    Memory.class,
    Battery.class,
    Rspl.class,
    Storage.class,
    Switch.class,
    Circuitbreakers.class,
    Kit.class,
    RangePart.class,
    Documentgeneric.class,
    Processes.class,
    A3150611726 .class,
    HeatsinksheatsinkAcc.class,
    Packaging.class,
    Label.class
})
public class Fbom
    extends JItemRootIccPrivate
{

    @XmlElement(name = "DmrSection")
    protected DmrSection dmrSection;
    @XmlElement(name = "ComponentDetails")
    protected ComponentDetails componentDetails;

    /**
     * Gets the value of the dmrSection property.
     * 
     * @return
     *     possible object is
     *     {@link DmrSection }
     *     
     */
    public DmrSection getDmrSection() {
        return dmrSection;
    }

    /**
     * Sets the value of the dmrSection property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmrSection }
     *     
     */
    public void setDmrSection(DmrSection value) {
        this.dmrSection = value;
    }

    /**
     * Gets the value of the componentDetails property.
     * 
     * @return
     *     possible object is
     *     {@link ComponentDetails }
     *     
     */
    public ComponentDetails getComponentDetails() {
        return componentDetails;
    }

    /**
     * Sets the value of the componentDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link ComponentDetails }
     *     
     */
    public void setComponentDetails(ComponentDetails value) {
        this.componentDetails = value;
    }

}
