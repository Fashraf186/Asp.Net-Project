
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.TransistorFETDetails;


/**
 * <p>Java class for TransistorFET complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TransistorFET">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Part">
 *       &lt;sequence>
 *         &lt;element name="TransistorFETDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}TransistorFETDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TransistorFET", propOrder = {
    "transistorFETDetails"
})
public class TransistorFET
    extends Part
{

    @XmlElement(name = "TransistorFETDetails")
    protected TransistorFETDetails transistorFETDetails;

    /**
     * Gets the value of the transistorFETDetails property.
     * 
     * @return
     *     possible object is
     *     {@link TransistorFETDetails }
     *     
     */
    public TransistorFETDetails getTransistorFETDetails() {
        return transistorFETDetails;
    }

    /**
     * Sets the value of the transistorFETDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link TransistorFETDetails }
     *     
     */
    public void setTransistorFETDetails(TransistorFETDetails value) {
        this.transistorFETDetails = value;
    }

}
