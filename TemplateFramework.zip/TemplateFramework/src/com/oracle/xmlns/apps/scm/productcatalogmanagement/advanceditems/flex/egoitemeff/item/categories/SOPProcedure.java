
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.SOPProcedureDetails;


/**
 * <p>Java class for SOPProcedure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SOPProcedure">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}QualityofProducts">
 *       &lt;sequence>
 *         &lt;element name="SOPProcedureDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}SOPProcedureDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SOPProcedure", propOrder = {
    "sopProcedureDetails"
})
public class SOPProcedure
    extends QualityofProducts
{

    @XmlElement(name = "SOPProcedureDetails")
    protected SOPProcedureDetails sopProcedureDetails;

    /**
     * Gets the value of the sopProcedureDetails property.
     * 
     * @return
     *     possible object is
     *     {@link SOPProcedureDetails }
     *     
     */
    public SOPProcedureDetails getSOPProcedureDetails() {
        return sopProcedureDetails;
    }

    /**
     * Sets the value of the sopProcedureDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link SOPProcedureDetails }
     *     
     */
    public void setSOPProcedureDetails(SOPProcedureDetails value) {
        this.sopProcedureDetails = value;
    }

}
