
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.AssemblyInstructions;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.Comments;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.FilledGoodDetails;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.MarketRestrictions;


/**
 * <p>Java class for FilleGoodssa complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FilleGoodssa">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}j_ItemRootIccPrivate">
 *       &lt;sequence>
 *         &lt;element name="Comments" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}Comments" minOccurs="0"/>
 *         &lt;element name="MarketRestrictions" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}MarketRestrictions" minOccurs="0"/>
 *         &lt;element name="AssemblyInstructions" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}AssemblyInstructions" minOccurs="0"/>
 *         &lt;element name="FilledGoodDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}FilledGoodDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FilleGoodssa", propOrder = {
    "comments",
    "marketRestrictions",
    "assemblyInstructions",
    "filledGoodDetails"
})
public class FilleGoodssa
    extends JItemRootIccPrivate
{

    @XmlElement(name = "Comments")
    protected Comments comments;
    @XmlElement(name = "MarketRestrictions")
    protected MarketRestrictions marketRestrictions;
    @XmlElement(name = "AssemblyInstructions")
    protected AssemblyInstructions assemblyInstructions;
    @XmlElement(name = "FilledGoodDetails")
    protected FilledGoodDetails filledGoodDetails;

    /**
     * Gets the value of the comments property.
     * 
     * @return
     *     possible object is
     *     {@link Comments }
     *     
     */
    public Comments getComments() {
        return comments;
    }

    /**
     * Sets the value of the comments property.
     * 
     * @param value
     *     allowed object is
     *     {@link Comments }
     *     
     */
    public void setComments(Comments value) {
        this.comments = value;
    }

    /**
     * Gets the value of the marketRestrictions property.
     * 
     * @return
     *     possible object is
     *     {@link MarketRestrictions }
     *     
     */
    public MarketRestrictions getMarketRestrictions() {
        return marketRestrictions;
    }

    /**
     * Sets the value of the marketRestrictions property.
     * 
     * @param value
     *     allowed object is
     *     {@link MarketRestrictions }
     *     
     */
    public void setMarketRestrictions(MarketRestrictions value) {
        this.marketRestrictions = value;
    }

    /**
     * Gets the value of the assemblyInstructions property.
     * 
     * @return
     *     possible object is
     *     {@link AssemblyInstructions }
     *     
     */
    public AssemblyInstructions getAssemblyInstructions() {
        return assemblyInstructions;
    }

    /**
     * Sets the value of the assemblyInstructions property.
     * 
     * @param value
     *     allowed object is
     *     {@link AssemblyInstructions }
     *     
     */
    public void setAssemblyInstructions(AssemblyInstructions value) {
        this.assemblyInstructions = value;
    }

    /**
     * Gets the value of the filledGoodDetails property.
     * 
     * @return
     *     possible object is
     *     {@link FilledGoodDetails }
     *     
     */
    public FilledGoodDetails getFilledGoodDetails() {
        return filledGoodDetails;
    }

    /**
     * Sets the value of the filledGoodDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link FilledGoodDetails }
     *     
     */
    public void setFilledGoodDetails(FilledGoodDetails value) {
        this.filledGoodDetails = value;
    }

}
