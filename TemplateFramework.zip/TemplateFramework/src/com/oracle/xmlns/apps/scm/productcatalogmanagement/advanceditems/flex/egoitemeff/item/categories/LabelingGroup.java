
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.LabelingDetails;


/**
 * <p>Java class for LabelingGroup complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LabelingGroup">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Labeling">
 *       &lt;sequence>
 *         &lt;element name="LabelingDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}LabelingDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LabelingGroup", propOrder = {
    "labelingDetails"
})
public class LabelingGroup
    extends Labeling
{

    @XmlElement(name = "LabelingDetails")
    protected LabelingDetails labelingDetails;

    /**
     * Gets the value of the labelingDetails property.
     * 
     * @return
     *     possible object is
     *     {@link LabelingDetails }
     *     
     */
    public LabelingDetails getLabelingDetails() {
        return labelingDetails;
    }

    /**
     * Sets the value of the labelingDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link LabelingDetails }
     *     
     */
    public void setLabelingDetails(LabelingDetails value) {
        this.labelingDetails = value;
    }

}
