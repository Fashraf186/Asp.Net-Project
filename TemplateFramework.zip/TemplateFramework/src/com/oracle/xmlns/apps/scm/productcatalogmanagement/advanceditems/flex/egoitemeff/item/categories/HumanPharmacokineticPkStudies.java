
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for HumanPharmacokineticPkStudies complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="HumanPharmacokineticPkStudies">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Clinical">
 *       &lt;sequence>
 *         &lt;element name="HumanPharmacokineticPkStudies" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}HumanPharmacokineticPkStudies" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "HumanPharmacokineticPkStudies", propOrder = {
    "humanPharmacokineticPkStudies"
})
public class HumanPharmacokineticPkStudies
    extends Clinical
{

    @XmlElement(name = "HumanPharmacokineticPkStudies")
    protected com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.HumanPharmacokineticPkStudies humanPharmacokineticPkStudies;

    /**
     * Gets the value of the humanPharmacokineticPkStudies property.
     * 
     * @return
     *     possible object is
     *     {@link com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.HumanPharmacokineticPkStudies }
     *     
     */
    public com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.HumanPharmacokineticPkStudies getHumanPharmacokineticPkStudies() {
        return humanPharmacokineticPkStudies;
    }

    /**
     * Sets the value of the humanPharmacokineticPkStudies property.
     * 
     * @param value
     *     allowed object is
     *     {@link com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.HumanPharmacokineticPkStudies }
     *     
     */
    public void setHumanPharmacokineticPkStudies(com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.HumanPharmacokineticPkStudies value) {
        this.humanPharmacokineticPkStudies = value;
    }

}
