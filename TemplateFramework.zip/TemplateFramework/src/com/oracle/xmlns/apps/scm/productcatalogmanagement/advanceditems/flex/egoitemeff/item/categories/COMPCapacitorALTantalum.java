
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.COMPCapacitorALTantalumDetails;


/**
 * <p>Java class for COMPCapacitorALTantalum complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="COMPCapacitorALTantalum">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Part">
 *       &lt;sequence>
 *         &lt;element name="COMPCapacitorALTantalumDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}COMPCapacitorALTantalumDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "COMPCapacitorALTantalum", propOrder = {
    "compCapacitorALTantalumDetails"
})
public class COMPCapacitorALTantalum
    extends Part
{

    @XmlElement(name = "COMPCapacitorALTantalumDetails")
    protected COMPCapacitorALTantalumDetails compCapacitorALTantalumDetails;

    /**
     * Gets the value of the compCapacitorALTantalumDetails property.
     * 
     * @return
     *     possible object is
     *     {@link COMPCapacitorALTantalumDetails }
     *     
     */
    public COMPCapacitorALTantalumDetails getCOMPCapacitorALTantalumDetails() {
        return compCapacitorALTantalumDetails;
    }

    /**
     * Sets the value of the compCapacitorALTantalumDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link COMPCapacitorALTantalumDetails }
     *     
     */
    public void setCOMPCapacitorALTantalumDetails(COMPCapacitorALTantalumDetails value) {
        this.compCapacitorALTantalumDetails = value;
    }

}
