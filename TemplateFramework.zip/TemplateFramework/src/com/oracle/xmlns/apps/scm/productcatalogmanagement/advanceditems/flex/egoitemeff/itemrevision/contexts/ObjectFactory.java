
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.itemrevision.contexts;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.itemrevision.contexts package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _RevAttr_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/contexts/", "revAttr");
    private final static QName _RevAttrIsPersistentAttributeUpdated_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/contexts/", "IsPersistentAttributeUpdated");
    private final static QName _RevAttrIsImportCase_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/contexts/", "IsImportCase");
    private final static QName _RevAttrRaiseEvent_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/contexts/", "RaiseEvent");
    private final static QName _RevAttrRedLinerev_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/contexts/", "RedLinerev");
    private final static QName _RevAttrRev_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/contexts/", "rev");
    private final static QName _RevAttrIsAddedToChildEntitiesMap_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/contexts/", "IsAddedToChildEntitiesMap");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.itemrevision.contexts
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RevAttr }
     * 
     */
    public RevAttr createRevAttr() {
        return new RevAttr();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RevAttr }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/contexts/", name = "revAttr")
    public JAXBElement<RevAttr> createRevAttr(RevAttr value) {
        return new JAXBElement<RevAttr>(_RevAttr_QNAME, RevAttr.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/contexts/", name = "IsPersistentAttributeUpdated", scope = RevAttr.class)
    public JAXBElement<Boolean> createRevAttrIsPersistentAttributeUpdated(Boolean value) {
        return new JAXBElement<Boolean>(_RevAttrIsPersistentAttributeUpdated_QNAME, Boolean.class, RevAttr.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/contexts/", name = "IsImportCase", scope = RevAttr.class)
    public JAXBElement<Boolean> createRevAttrIsImportCase(Boolean value) {
        return new JAXBElement<Boolean>(_RevAttrIsImportCase_QNAME, Boolean.class, RevAttr.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/contexts/", name = "RaiseEvent", scope = RevAttr.class)
    public JAXBElement<String> createRevAttrRaiseEvent(String value) {
        return new JAXBElement<String>(_RevAttrRaiseEvent_QNAME, String.class, RevAttr.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/contexts/", name = "RedLinerev", scope = RevAttr.class)
    public JAXBElement<String> createRevAttrRedLinerev(String value) {
        return new JAXBElement<String>(_RevAttrRedLinerev_QNAME, String.class, RevAttr.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/contexts/", name = "rev", scope = RevAttr.class)
    public JAXBElement<String> createRevAttrRev(String value) {
        return new JAXBElement<String>(_RevAttrRev_QNAME, String.class, RevAttr.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/contexts/", name = "IsAddedToChildEntitiesMap", scope = RevAttr.class)
    public JAXBElement<Boolean> createRevAttrIsAddedToChildEntitiesMap(Boolean value) {
        return new JAXBElement<Boolean>(_RevAttrIsAddedToChildEntitiesMap_QNAME, Boolean.class, RevAttr.class, value);
    }

}
