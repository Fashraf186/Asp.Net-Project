
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.ApplicantInformationDetails;


/**
 * <p>Java class for ApplicantInformation complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ApplicantInformation">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Regulatoryadmin">
 *       &lt;sequence>
 *         &lt;element name="ApplicantInformationDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}ApplicantInformationDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ApplicantInformation", propOrder = {
    "applicantInformationDetails"
})
public class ApplicantInformation
    extends Regulatoryadmin
{

    @XmlElement(name = "ApplicantInformationDetails")
    protected ApplicantInformationDetails applicantInformationDetails;

    /**
     * Gets the value of the applicantInformationDetails property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicantInformationDetails }
     *     
     */
    public ApplicantInformationDetails getApplicantInformationDetails() {
        return applicantInformationDetails;
    }

    /**
     * Sets the value of the applicantInformationDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicantInformationDetails }
     *     
     */
    public void setApplicantInformationDetails(ApplicantInformationDetails value) {
        this.applicantInformationDetails = value;
    }

}
