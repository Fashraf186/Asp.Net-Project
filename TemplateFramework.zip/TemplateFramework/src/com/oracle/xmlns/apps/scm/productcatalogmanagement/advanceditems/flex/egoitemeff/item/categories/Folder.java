
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.FgAttribute;


/**
 * <p>Java class for Folder complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Folder">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}j_ItemRootIccPrivate">
 *       &lt;sequence>
 *         &lt;element name="FgAttribute" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}FgAttribute" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Folder", propOrder = {
    "fgAttribute"
})
public class Folder
    extends JItemRootIccPrivate
{

    @XmlElement(name = "FgAttribute")
    protected FgAttribute fgAttribute;

    /**
     * Gets the value of the fgAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link FgAttribute }
     *     
     */
    public FgAttribute getFgAttribute() {
        return fgAttribute;
    }

    /**
     * Sets the value of the fgAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link FgAttribute }
     *     
     */
    public void setFgAttribute(FgAttribute value) {
        this.fgAttribute = value;
    }

}
