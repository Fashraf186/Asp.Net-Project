
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.DocumentsDetails;


/**
 * <p>Java class for Document complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Document">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}j_ItemRootIccPrivate">
 *       &lt;sequence>
 *         &lt;element name="DocumentsDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}DocumentsDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Document", propOrder = {
    "documentsDetails"
})
@XmlSeeAlso({
    Dmr.class,
    Datasheets.class,
    SMSDocumentofExternalOrigin.class,
    InternalDocument.class,
    Internalfolder.class,
    PCBSpecs.class,
    QualityDocuments.class,
    SMSDocument.class,
    Newdhf.class,
    SOPDocument.class,
    ExternalDocument.class,
    Regulatorysubmission.class
})
public class Document
    extends JItemRootIccPrivate
{

    @XmlElement(name = "DocumentsDetails")
    protected DocumentsDetails documentsDetails;

    /**
     * Gets the value of the documentsDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DocumentsDetails }
     *     
     */
    public DocumentsDetails getDocumentsDetails() {
        return documentsDetails;
    }

    /**
     * Sets the value of the documentsDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentsDetails }
     *     
     */
    public void setDocumentsDetails(DocumentsDetails value) {
        this.documentsDetails = value;
    }

}
