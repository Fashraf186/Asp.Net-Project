
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.FgAttribute;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.HbAttributesGroup;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.ZtestGroup;


/**
 * <p>Java class for ZtestItemClass complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ZtestItemClass">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}j_ItemRootIccPrivate">
 *       &lt;sequence>
 *         &lt;element name="ZtestGroup" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}ZtestGroup" minOccurs="0"/>
 *         &lt;element name="HbAttributesGroup" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}HbAttributesGroup" minOccurs="0"/>
 *         &lt;element name="FgAttribute" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}FgAttribute" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ZtestItemClass", propOrder = {
    "ztestGroup",
    "hbAttributesGroup",
    "fgAttribute"
})
public class ZtestItemClass
    extends JItemRootIccPrivate
{

    @XmlElement(name = "ZtestGroup")
    protected ZtestGroup ztestGroup;
    @XmlElement(name = "HbAttributesGroup")
    protected HbAttributesGroup hbAttributesGroup;
    @XmlElement(name = "FgAttribute")
    protected FgAttribute fgAttribute;

    /**
     * Gets the value of the ztestGroup property.
     * 
     * @return
     *     possible object is
     *     {@link ZtestGroup }
     *     
     */
    public ZtestGroup getZtestGroup() {
        return ztestGroup;
    }

    /**
     * Sets the value of the ztestGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link ZtestGroup }
     *     
     */
    public void setZtestGroup(ZtestGroup value) {
        this.ztestGroup = value;
    }

    /**
     * Gets the value of the hbAttributesGroup property.
     * 
     * @return
     *     possible object is
     *     {@link HbAttributesGroup }
     *     
     */
    public HbAttributesGroup getHbAttributesGroup() {
        return hbAttributesGroup;
    }

    /**
     * Sets the value of the hbAttributesGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link HbAttributesGroup }
     *     
     */
    public void setHbAttributesGroup(HbAttributesGroup value) {
        this.hbAttributesGroup = value;
    }

    /**
     * Gets the value of the fgAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link FgAttribute }
     *     
     */
    public FgAttribute getFgAttribute() {
        return fgAttribute;
    }

    /**
     * Sets the value of the fgAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link FgAttribute }
     *     
     */
    public void setFgAttribute(FgAttribute value) {
        this.fgAttribute = value;
    }

}
