
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.itemrevision.categories;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.itemrevision.categories package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _PartParent_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "partParent");
    private final static QName _Fg_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "fg");
    private final static QName _SOPDocument_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "sOPDocument");
    private final static QName _LiteratureReferences_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "literatureReferences");
    private final static QName _Circuitbreakers_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "circuitbreakers");
    private final static QName _AnalysisOfDataFromMoreThanOneS_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "analysisOfDataFromMoreThanOneS");
    private final static QName _Electricalelectronic_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "electricalelectronic");
    private final static QName _ExternalDocument_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "externalDocument");
    private final static QName _Label_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "label");
    private final static QName _Packaging_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "packaging");
    private final static QName _Specification_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "specification");
    private final static QName _Summaries_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "summaries");
    private final static QName _Thermist_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "thermist");
    private final static QName _DrugSunstance_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "drugSunstance");
    private final static QName _PartFamily_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "partFamily");
    private final static QName _DrugProduct_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "drugProduct");
    private final static QName _CableHarness_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "cableHarness");
    private final static QName _QualityDocuments_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "qualityDocuments");
    private final static QName _PCBSpecs_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "pCBSpecs");
    private final static QName _Pasresistors_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "pasresistors");
    private final static QName _AdventitiousAgents_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "adventitiousAgents");
    private final static QName _MedicalDevice_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "medicalDevice");
    private final static QName _DisfreqCtrlosccrystal_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "disfreqCtrlosccrystal");
    private final static QName _Dhf_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "dhf");
    private final static QName _InternalDocument_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "internalDocument");
    private final static QName _Pasinductorscoilschoke_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "pasinductorscoilschoke");
    private final static QName _Pascapacitors_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "pascapacitors");
    private final static QName _Component_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "component");
    private final static QName _L7Linear_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "l7Linear");
    private final static QName _Wizard_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "wizard");
    private final static QName _PasbeadsleeveFerrite_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "pasbeadsleeveFerrite");
    private final static QName _PowerSupply_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "powerSupply");
    private final static QName _Resistor_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "resistor");
    private final static QName _ConnectorPower_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "connectorPower");
    private final static QName _ComputerAccessory_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "computerAccessory");
    private final static QName _KitFg_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "kitFg");
    private final static QName _Regulatoryadmin_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "regulatoryadmin");
    private final static QName _SMSDocumentofExternalOrigin_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "sMSDocumentofExternalOrigin");
    private final static QName _Icasic_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "icasic");
    private final static QName _Chemical_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "chemical");
    private final static QName _Folder_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "folder");
    private final static QName _Drive_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "drive");
    private final static QName _Legacy_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "legacy");
    private final static QName _JItemRevisionVersion_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "j_ItemRevisionVersion");
    private final static QName _Switch_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "switch");
    private final static QName _Storage_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "storage");
    private final static QName _Transformer_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "transformer");
    private final static QName _ToxicologyStudyReports_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "toxicologyStudyReports");
    private final static QName _HeatsinksheatsinkAcc_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "heatsinksheatsinkAcc");
    private final static QName _Processes_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "processes");
    private final static QName _RangePart_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "rangePart");
    private final static QName _ChangeOrder_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "changeOrder");
    private final static QName _Socket_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "socket");
    private final static QName _PackageAssembly_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "packageAssembly");
    private final static QName _HoverBoard_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "hoverBoard");
    private final static QName _Disrectifswitchdiode_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "disrectifswitchdiode");
    private final static QName _SOP_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "sOP");
    private final static QName _Casing_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "casing");
    private final static QName _Cable_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "cable");
    private final static QName _Spare444_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "spare444");
    private final static QName _C3Convex_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "c3Convex");
    private final static QName _RegulatoryDocuments_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "regulatoryDocuments");
    private final static QName _COMPResistor_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "cOMPResistor");
    private final static QName _Clinical_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "clinical");
    private final static QName _Server_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "server");
    private final static QName _Cell_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "cell");
    private final static QName _QualityofProducts_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "qualityofProducts");
    private final static QName _ApplicantInformation_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "applicantInformation");
    private final static QName _Microprocessorsmicroprocessors_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "microprocessorsmicroprocessors");
    private final static QName _Dmr_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "dmr");
    private final static QName _Datasheets_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "datasheets");
    private final static QName _ZtestItemClass_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "ztestItemClass");
    private final static QName _Model_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "model");
    private final static QName _HumanPharmacokineticPkStudies_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "humanPharmacokineticPkStudies");
    private final static QName _IcdigitalLogic_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "icdigitalLogic");
    private final static QName _Adapters_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "adapters");
    private final static QName _ConnectorPbMounted_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "connectorPbMounted");
    private final static QName _Icmemoryromflash_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "icmemoryromflash");
    private final static QName _ConnectorheaderAddMal_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "connectorheaderAddMal");
    private final static QName _SheetMetal_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "sheetMetal");
    private final static QName _CellStack_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "cellStack");
    private final static QName _Nonclinical_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "nonclinical");
    private final static QName _Memory_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "memory");
    private final static QName _OtherStudyReports_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "otherStudyReports");
    private final static QName _Kit_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "kit");
    private final static QName _AgileWizard_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "agileWizard");
    private final static QName _Substance_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "substance");
    private final static QName _Documentgeneric_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "documentgeneric");
    private final static QName _Regulatorysubmission_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "regulatorysubmission");
    private final static QName _HumanPharmacodynamicPd_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "humanPharmacodynamicPd");
    private final static QName _Pcbpwbs_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "pcbpwbs");
    private final static QName _ConnectorAdapters_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "connectorAdapters");
    private final static QName _Nuts_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "nuts");
    private final static QName _DocumentParent_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "documentParent");
    private final static QName _HearRateMonitor_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "hearRateMonitor");
    private final static QName _EquipmentFixturesTools_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "equipmentFixturesTools");
    private final static QName _Manufacturerspinalelement_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "manufacturerspinalelement");
    private final static QName _Document_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "document");
    private final static QName _Battery_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "battery");
    private final static QName _SubstanceGroup_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "substanceGroup");
    private final static QName _LiteratureReference_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "literatureReference");
    private final static QName _Distransistor_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "distransistor");
    private final static QName _TestAttributesClass_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "testAttributesClass");
    private final static QName _Declaration_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "declaration");
    private final static QName _QualityOverallSummary_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "qualityOverallSummary");
    private final static QName _IngredientN_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "ingredientN");
    private final static QName _EfficacyAndSafety_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "efficacyAndSafety");
    private final static QName _Disled_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "disled");
    private final static QName _Cto_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "cto");
    private final static QName _Module_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "module");
    private final static QName _ProductProcedures_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "productProcedures");
    private final static QName _Quality_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "quality");
    private final static QName _AdministrativeInformation_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "administrativeInformation");
    private final static QName _FuseComponents_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "fuseComponents");
    private final static QName _Part_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "part");
    private final static QName _Circuitbreaker_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "circuitbreaker");
    private final static QName _Rspl_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "rspl");
    private final static QName _A3150611726_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "a3150611726");
    private final static QName _FormulaN_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "formulaN");
    private final static QName _SOPProcedure_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "sOPProcedure");
    private final static QName _JItemRevisionRootIccPrivate_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "j_ItemRevisionRootIccPrivate");
    private final static QName _Internalfolder_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "internalfolder");
    private final static QName _LabelingGroup_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "labelingGroup");
    private final static QName _MechanicalComponent_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "mechanicalComponent");
    private final static QName _ElectronicSubassemblies_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "electronicSubassemblies");
    private final static QName _WireAssemblySet_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "wireAssemblySet");
    private final static QName _SMSDocument_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "sMSDocument");
    private final static QName _FinishedGood_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "finishedGood");
    private final static QName _Fbom_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "fbom");
    private final static QName _Newdhf_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "newdhf");
    private final static QName _QualityInformation_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "qualityInformation");
    private final static QName _Labeling_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "labeling");
    private final static QName _Feature_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "feature");
    private final static QName _FilleGoodssa_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "filleGoodssa");
    private final static QName _Firmware_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "firmware");
    private final static QName _OemCdRoms_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "oemCdRoms");
    private final static QName _Power_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "power");
    private final static QName _C7Microconvex_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "c7Microconvex");
    private final static QName _VirtualPhasedArray_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "virtualPhasedArray");
    private final static QName _SpecificationDocuments_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "specificationDocuments");
    private final static QName _TransistorFET_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "transistorFET");
    private final static QName _COMPCapacitorALTantalum_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "cOMPCapacitorALTantalum");
    private final static QName _Screws_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "screws");
    private final static QName _Fan_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "fan");
    private final static QName _Pwbpwba_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "pwbpwba");
    private final static QName _ItemSku_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "itemSku");
    private final static QName _BiopharmaceuticStudyReports_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "biopharmaceuticStudyReports");
    private final static QName _ElectromechanicalAssemblies_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "electromechanicalAssemblies");
    private final static QName _JItemRevisionVersionCategoryCode_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "CategoryCode");
    private final static QName _JItemRevisionVersionVersionId_QNAME = new QName("http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", "VersionId");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.itemrevision.categories
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link IngredientN }
     * 
     */
    public IngredientN createIngredientN() {
        return new IngredientN();
    }

    /**
     * Create an instance of {@link PasbeadsleeveFerrite }
     * 
     */
    public PasbeadsleeveFerrite createPasbeadsleeveFerrite() {
        return new PasbeadsleeveFerrite();
    }

    /**
     * Create an instance of {@link Dmr }
     * 
     */
    public Dmr createDmr() {
        return new Dmr();
    }

    /**
     * Create an instance of {@link PowerSupply }
     * 
     */
    public PowerSupply createPowerSupply() {
        return new PowerSupply();
    }

    /**
     * Create an instance of {@link EfficacyAndSafety }
     * 
     */
    public EfficacyAndSafety createEfficacyAndSafety() {
        return new EfficacyAndSafety();
    }

    /**
     * Create an instance of {@link Fan }
     * 
     */
    public Fan createFan() {
        return new Fan();
    }

    /**
     * Create an instance of {@link ZtestItemClass }
     * 
     */
    public ZtestItemClass createZtestItemClass() {
        return new ZtestItemClass();
    }

    /**
     * Create an instance of {@link Datasheets }
     * 
     */
    public Datasheets createDatasheets() {
        return new Datasheets();
    }

    /**
     * Create an instance of {@link Model }
     * 
     */
    public Model createModel() {
        return new Model();
    }

    /**
     * Create an instance of {@link Resistor }
     * 
     */
    public Resistor createResistor() {
        return new Resistor();
    }

    /**
     * Create an instance of {@link Disled }
     * 
     */
    public Disled createDisled() {
        return new Disled();
    }

    /**
     * Create an instance of {@link Cto }
     * 
     */
    public Cto createCto() {
        return new Cto();
    }

    /**
     * Create an instance of {@link ComputerAccessory }
     * 
     */
    public ComputerAccessory createComputerAccessory() {
        return new ComputerAccessory();
    }

    /**
     * Create an instance of {@link KitFg }
     * 
     */
    public KitFg createKitFg() {
        return new KitFg();
    }

    /**
     * Create an instance of {@link Adapters }
     * 
     */
    public Adapters createAdapters() {
        return new Adapters();
    }

    /**
     * Create an instance of {@link ProductProcedures }
     * 
     */
    public ProductProcedures createProductProcedures() {
        return new ProductProcedures();
    }

    /**
     * Create an instance of {@link Pwbpwba }
     * 
     */
    public Pwbpwba createPwbpwba() {
        return new Pwbpwba();
    }

    /**
     * Create an instance of {@link IcdigitalLogic }
     * 
     */
    public IcdigitalLogic createIcdigitalLogic() {
        return new IcdigitalLogic();
    }

    /**
     * Create an instance of {@link HumanPharmacokineticPkStudies }
     * 
     */
    public HumanPharmacokineticPkStudies createHumanPharmacokineticPkStudies() {
        return new HumanPharmacokineticPkStudies();
    }

    /**
     * Create an instance of {@link ConnectorPower }
     * 
     */
    public ConnectorPower createConnectorPower() {
        return new ConnectorPower();
    }

    /**
     * Create an instance of {@link Module }
     * 
     */
    public Module createModule() {
        return new Module();
    }

    /**
     * Create an instance of {@link ItemSku }
     * 
     */
    public ItemSku createItemSku() {
        return new ItemSku();
    }

    /**
     * Create an instance of {@link Icmemoryromflash }
     * 
     */
    public Icmemoryromflash createIcmemoryromflash() {
        return new Icmemoryromflash();
    }

    /**
     * Create an instance of {@link ConnectorPbMounted }
     * 
     */
    public ConnectorPbMounted createConnectorPbMounted() {
        return new ConnectorPbMounted();
    }

    /**
     * Create an instance of {@link Icasic }
     * 
     */
    public Icasic createIcasic() {
        return new Icasic();
    }

    /**
     * Create an instance of {@link SMSDocumentofExternalOrigin }
     * 
     */
    public SMSDocumentofExternalOrigin createSMSDocumentofExternalOrigin() {
        return new SMSDocumentofExternalOrigin();
    }

    /**
     * Create an instance of {@link Quality }
     * 
     */
    public Quality createQuality() {
        return new Quality();
    }

    /**
     * Create an instance of {@link Regulatoryadmin }
     * 
     */
    public Regulatoryadmin createRegulatoryadmin() {
        return new Regulatoryadmin();
    }

    /**
     * Create an instance of {@link ConnectorheaderAddMal }
     * 
     */
    public ConnectorheaderAddMal createConnectorheaderAddMal() {
        return new ConnectorheaderAddMal();
    }

    /**
     * Create an instance of {@link BiopharmaceuticStudyReports }
     * 
     */
    public BiopharmaceuticStudyReports createBiopharmaceuticStudyReports() {
        return new BiopharmaceuticStudyReports();
    }

    /**
     * Create an instance of {@link ElectromechanicalAssemblies }
     * 
     */
    public ElectromechanicalAssemblies createElectromechanicalAssemblies() {
        return new ElectromechanicalAssemblies();
    }

    /**
     * Create an instance of {@link Folder }
     * 
     */
    public Folder createFolder() {
        return new Folder();
    }

    /**
     * Create an instance of {@link Chemical }
     * 
     */
    public Chemical createChemical() {
        return new Chemical();
    }

    /**
     * Create an instance of {@link AdministrativeInformation }
     * 
     */
    public AdministrativeInformation createAdministrativeInformation() {
        return new AdministrativeInformation();
    }

    /**
     * Create an instance of {@link FuseComponents }
     * 
     */
    public FuseComponents createFuseComponents() {
        return new FuseComponents();
    }

    /**
     * Create an instance of {@link Drive }
     * 
     */
    public Drive createDrive() {
        return new Drive();
    }

    /**
     * Create an instance of {@link SheetMetal }
     * 
     */
    public SheetMetal createSheetMetal() {
        return new SheetMetal();
    }

    /**
     * Create an instance of {@link Server }
     * 
     */
    public Server createServer() {
        return new Server();
    }

    /**
     * Create an instance of {@link QualityInformation }
     * 
     */
    public QualityInformation createQualityInformation() {
        return new QualityInformation();
    }

    /**
     * Create an instance of {@link Document }
     * 
     */
    public Document createDocument() {
        return new Document();
    }

    /**
     * Create an instance of {@link MedicalDevice }
     * 
     */
    public MedicalDevice createMedicalDevice() {
        return new MedicalDevice();
    }

    /**
     * Create an instance of {@link AdventitiousAgents }
     * 
     */
    public AdventitiousAgents createAdventitiousAgents() {
        return new AdventitiousAgents();
    }

    /**
     * Create an instance of {@link QualityofProducts }
     * 
     */
    public QualityofProducts createQualityofProducts() {
        return new QualityofProducts();
    }

    /**
     * Create an instance of {@link Cell }
     * 
     */
    public Cell createCell() {
        return new Cell();
    }

    /**
     * Create an instance of {@link Battery }
     * 
     */
    public Battery createBattery() {
        return new Battery();
    }

    /**
     * Create an instance of {@link Distransistor }
     * 
     */
    public Distransistor createDistransistor() {
        return new Distransistor();
    }

    /**
     * Create an instance of {@link LiteratureReference }
     * 
     */
    public LiteratureReference createLiteratureReference() {
        return new LiteratureReference();
    }

    /**
     * Create an instance of {@link Feature }
     * 
     */
    public Feature createFeature() {
        return new Feature();
    }

    /**
     * Create an instance of {@link FilleGoodssa }
     * 
     */
    public FilleGoodssa createFilleGoodssa() {
        return new FilleGoodssa();
    }

    /**
     * Create an instance of {@link ApplicantInformation }
     * 
     */
    public ApplicantInformation createApplicantInformation() {
        return new ApplicantInformation();
    }

    /**
     * Create an instance of {@link Labeling }
     * 
     */
    public Labeling createLabeling() {
        return new Labeling();
    }

    /**
     * Create an instance of {@link SubstanceGroup }
     * 
     */
    public SubstanceGroup createSubstanceGroup() {
        return new SubstanceGroup();
    }

    /**
     * Create an instance of {@link C7Microconvex }
     * 
     */
    public C7Microconvex createC7Microconvex() {
        return new C7Microconvex();
    }

    /**
     * Create an instance of {@link DisfreqCtrlosccrystal }
     * 
     */
    public DisfreqCtrlosccrystal createDisfreqCtrlosccrystal() {
        return new DisfreqCtrlosccrystal();
    }

    /**
     * Create an instance of {@link Power }
     * 
     */
    public Power createPower() {
        return new Power();
    }

    /**
     * Create an instance of {@link Firmware }
     * 
     */
    public Firmware createFirmware() {
        return new Firmware();
    }

    /**
     * Create an instance of {@link OemCdRoms }
     * 
     */
    public OemCdRoms createOemCdRoms() {
        return new OemCdRoms();
    }

    /**
     * Create an instance of {@link Microprocessorsmicroprocessors }
     * 
     */
    public Microprocessorsmicroprocessors createMicroprocessorsmicroprocessors() {
        return new Microprocessorsmicroprocessors();
    }

    /**
     * Create an instance of {@link VirtualPhasedArray }
     * 
     */
    public VirtualPhasedArray createVirtualPhasedArray() {
        return new VirtualPhasedArray();
    }

    /**
     * Create an instance of {@link Dhf }
     * 
     */
    public Dhf createDhf() {
        return new Dhf();
    }

    /**
     * Create an instance of {@link TestAttributesClass }
     * 
     */
    public TestAttributesClass createTestAttributesClass() {
        return new TestAttributesClass();
    }

    /**
     * Create an instance of {@link TransistorFET }
     * 
     */
    public TransistorFET createTransistorFET() {
        return new TransistorFET();
    }

    /**
     * Create an instance of {@link Declaration }
     * 
     */
    public Declaration createDeclaration() {
        return new Declaration();
    }

    /**
     * Create an instance of {@link InternalDocument }
     * 
     */
    public InternalDocument createInternalDocument() {
        return new InternalDocument();
    }

    /**
     * Create an instance of {@link SpecificationDocuments }
     * 
     */
    public SpecificationDocuments createSpecificationDocuments() {
        return new SpecificationDocuments();
    }

    /**
     * Create an instance of {@link L7Linear }
     * 
     */
    public L7Linear createL7Linear() {
        return new L7Linear();
    }

    /**
     * Create an instance of {@link Pascapacitors }
     * 
     */
    public Pascapacitors createPascapacitors() {
        return new Pascapacitors();
    }

    /**
     * Create an instance of {@link COMPCapacitorALTantalum }
     * 
     */
    public COMPCapacitorALTantalum createCOMPCapacitorALTantalum() {
        return new COMPCapacitorALTantalum();
    }

    /**
     * Create an instance of {@link Component }
     * 
     */
    public Component createComponent() {
        return new Component();
    }

    /**
     * Create an instance of {@link Pasinductorscoilschoke }
     * 
     */
    public Pasinductorscoilschoke createPasinductorscoilschoke() {
        return new Pasinductorscoilschoke();
    }

    /**
     * Create an instance of {@link Screws }
     * 
     */
    public Screws createScrews() {
        return new Screws();
    }

    /**
     * Create an instance of {@link Wizard }
     * 
     */
    public Wizard createWizard() {
        return new Wizard();
    }

    /**
     * Create an instance of {@link QualityOverallSummary }
     * 
     */
    public QualityOverallSummary createQualityOverallSummary() {
        return new QualityOverallSummary();
    }

    /**
     * Create an instance of {@link Internalfolder }
     * 
     */
    public Internalfolder createInternalfolder() {
        return new Internalfolder();
    }

    /**
     * Create an instance of {@link Disrectifswitchdiode }
     * 
     */
    public Disrectifswitchdiode createDisrectifswitchdiode() {
        return new Disrectifswitchdiode();
    }

    /**
     * Create an instance of {@link HoverBoard }
     * 
     */
    public HoverBoard createHoverBoard() {
        return new HoverBoard();
    }

    /**
     * Create an instance of {@link HumanPharmacodynamicPd }
     * 
     */
    public HumanPharmacodynamicPd createHumanPharmacodynamicPd() {
        return new HumanPharmacodynamicPd();
    }

    /**
     * Create an instance of {@link PackageAssembly }
     * 
     */
    public PackageAssembly createPackageAssembly() {
        return new PackageAssembly();
    }

    /**
     * Create an instance of {@link DrugSunstance }
     * 
     */
    public DrugSunstance createDrugSunstance() {
        return new DrugSunstance();
    }

    /**
     * Create an instance of {@link Casing }
     * 
     */
    public Casing createCasing() {
        return new Casing();
    }

    /**
     * Create an instance of {@link PartFamily }
     * 
     */
    public PartFamily createPartFamily() {
        return new PartFamily();
    }

    /**
     * Create an instance of {@link LabelingGroup }
     * 
     */
    public LabelingGroup createLabelingGroup() {
        return new LabelingGroup();
    }

    /**
     * Create an instance of {@link SOP }
     * 
     */
    public SOP createSOP() {
        return new SOP();
    }

    /**
     * Create an instance of {@link MechanicalComponent }
     * 
     */
    public MechanicalComponent createMechanicalComponent() {
        return new MechanicalComponent();
    }

    /**
     * Create an instance of {@link CableHarness }
     * 
     */
    public CableHarness createCableHarness() {
        return new CableHarness();
    }

    /**
     * Create an instance of {@link Cable }
     * 
     */
    public Cable createCable() {
        return new Cable();
    }

    /**
     * Create an instance of {@link DrugProduct }
     * 
     */
    public DrugProduct createDrugProduct() {
        return new DrugProduct();
    }

    /**
     * Create an instance of {@link Spare444 }
     * 
     */
    public Spare444 createSpare444() {
        return new Spare444();
    }

    /**
     * Create an instance of {@link C3Convex }
     * 
     */
    public C3Convex createC3Convex() {
        return new C3Convex();
    }

    /**
     * Create an instance of {@link PCBSpecs }
     * 
     */
    public PCBSpecs createPCBSpecs() {
        return new PCBSpecs();
    }

    /**
     * Create an instance of {@link WireAssemblySet }
     * 
     */
    public WireAssemblySet createWireAssemblySet() {
        return new WireAssemblySet();
    }

    /**
     * Create an instance of {@link ElectronicSubassemblies }
     * 
     */
    public ElectronicSubassemblies createElectronicSubassemblies() {
        return new ElectronicSubassemblies();
    }

    /**
     * Create an instance of {@link Pcbpwbs }
     * 
     */
    public Pcbpwbs createPcbpwbs() {
        return new Pcbpwbs();
    }

    /**
     * Create an instance of {@link QualityDocuments }
     * 
     */
    public QualityDocuments createQualityDocuments() {
        return new QualityDocuments();
    }

    /**
     * Create an instance of {@link ConnectorAdapters }
     * 
     */
    public ConnectorAdapters createConnectorAdapters() {
        return new ConnectorAdapters();
    }

    /**
     * Create an instance of {@link COMPResistor }
     * 
     */
    public COMPResistor createCOMPResistor() {
        return new COMPResistor();
    }

    /**
     * Create an instance of {@link RegulatoryDocuments }
     * 
     */
    public RegulatoryDocuments createRegulatoryDocuments() {
        return new RegulatoryDocuments();
    }

    /**
     * Create an instance of {@link SMSDocument }
     * 
     */
    public SMSDocument createSMSDocument() {
        return new SMSDocument();
    }

    /**
     * Create an instance of {@link FinishedGood }
     * 
     */
    public FinishedGood createFinishedGood() {
        return new FinishedGood();
    }

    /**
     * Create an instance of {@link HearRateMonitor }
     * 
     */
    public HearRateMonitor createHearRateMonitor() {
        return new HearRateMonitor();
    }

    /**
     * Create an instance of {@link DocumentParent }
     * 
     */
    public DocumentParent createDocumentParent() {
        return new DocumentParent();
    }

    /**
     * Create an instance of {@link Clinical }
     * 
     */
    public Clinical createClinical() {
        return new Clinical();
    }

    /**
     * Create an instance of {@link Nuts }
     * 
     */
    public Nuts createNuts() {
        return new Nuts();
    }

    /**
     * Create an instance of {@link Fbom }
     * 
     */
    public Fbom createFbom() {
        return new Fbom();
    }

    /**
     * Create an instance of {@link Pasresistors }
     * 
     */
    public Pasresistors createPasresistors() {
        return new Pasresistors();
    }

    /**
     * Create an instance of {@link Newdhf }
     * 
     */
    public Newdhf createNewdhf() {
        return new Newdhf();
    }

    /**
     * Create an instance of {@link Manufacturerspinalelement }
     * 
     */
    public Manufacturerspinalelement createManufacturerspinalelement() {
        return new Manufacturerspinalelement();
    }

    /**
     * Create an instance of {@link EquipmentFixturesTools }
     * 
     */
    public EquipmentFixturesTools createEquipmentFixturesTools() {
        return new EquipmentFixturesTools();
    }

    /**
     * Create an instance of {@link JItemRevisionVersion }
     * 
     */
    public JItemRevisionVersion createJItemRevisionVersion() {
        return new JItemRevisionVersion();
    }

    /**
     * Create an instance of {@link OtherStudyReports }
     * 
     */
    public OtherStudyReports createOtherStudyReports() {
        return new OtherStudyReports();
    }

    /**
     * Create an instance of {@link Circuitbreaker }
     * 
     */
    public Circuitbreaker createCircuitbreaker() {
        return new Circuitbreaker();
    }

    /**
     * Create an instance of {@link Fg }
     * 
     */
    public Fg createFg() {
        return new Fg();
    }

    /**
     * Create an instance of {@link Legacy }
     * 
     */
    public Legacy createLegacy() {
        return new Legacy();
    }

    /**
     * Create an instance of {@link Memory }
     * 
     */
    public Memory createMemory() {
        return new Memory();
    }

    /**
     * Create an instance of {@link PartParent }
     * 
     */
    public PartParent createPartParent() {
        return new PartParent();
    }

    /**
     * Create an instance of {@link Nonclinical }
     * 
     */
    public Nonclinical createNonclinical() {
        return new Nonclinical();
    }

    /**
     * Create an instance of {@link CellStack }
     * 
     */
    public CellStack createCellStack() {
        return new CellStack();
    }

    /**
     * Create an instance of {@link Part }
     * 
     */
    public Part createPart() {
        return new Part();
    }

    /**
     * Create an instance of {@link Rspl }
     * 
     */
    public Rspl createRspl() {
        return new Rspl();
    }

    /**
     * Create an instance of {@link Transformer }
     * 
     */
    public Transformer createTransformer() {
        return new Transformer();
    }

    /**
     * Create an instance of {@link Storage }
     * 
     */
    public Storage createStorage() {
        return new Storage();
    }

    /**
     * Create an instance of {@link LiteratureReferences }
     * 
     */
    public LiteratureReferences createLiteratureReferences() {
        return new LiteratureReferences();
    }

    /**
     * Create an instance of {@link SOPDocument }
     * 
     */
    public SOPDocument createSOPDocument() {
        return new SOPDocument();
    }

    /**
     * Create an instance of {@link Switch }
     * 
     */
    public Switch createSwitch() {
        return new Switch();
    }

    /**
     * Create an instance of {@link Circuitbreakers }
     * 
     */
    public Circuitbreakers createCircuitbreakers() {
        return new Circuitbreakers();
    }

    /**
     * Create an instance of {@link Kit }
     * 
     */
    public Kit createKit() {
        return new Kit();
    }

    /**
     * Create an instance of {@link AgileWizard }
     * 
     */
    public AgileWizard createAgileWizard() {
        return new AgileWizard();
    }

    /**
     * Create an instance of {@link Electricalelectronic }
     * 
     */
    public Electricalelectronic createElectricalelectronic() {
        return new Electricalelectronic();
    }

    /**
     * Create an instance of {@link AnalysisOfDataFromMoreThanOneS }
     * 
     */
    public AnalysisOfDataFromMoreThanOneS createAnalysisOfDataFromMoreThanOneS() {
        return new AnalysisOfDataFromMoreThanOneS();
    }

    /**
     * Create an instance of {@link ToxicologyStudyReports }
     * 
     */
    public ToxicologyStudyReports createToxicologyStudyReports() {
        return new ToxicologyStudyReports();
    }

    /**
     * Create an instance of {@link Regulatorysubmission }
     * 
     */
    public Regulatorysubmission createRegulatorysubmission() {
        return new Regulatorysubmission();
    }

    /**
     * Create an instance of {@link SOPProcedure }
     * 
     */
    public SOPProcedure createSOPProcedure() {
        return new SOPProcedure();
    }

    /**
     * Create an instance of {@link RangePart }
     * 
     */
    public RangePart createRangePart() {
        return new RangePart();
    }

    /**
     * Create an instance of {@link Documentgeneric }
     * 
     */
    public Documentgeneric createDocumentgeneric() {
        return new Documentgeneric();
    }

    /**
     * Create an instance of {@link Processes }
     * 
     */
    public Processes createProcesses() {
        return new Processes();
    }

    /**
     * Create an instance of {@link FormulaN }
     * 
     */
    public FormulaN createFormulaN() {
        return new FormulaN();
    }

    /**
     * Create an instance of {@link A3150611726 }
     * 
     */
    public A3150611726 createA3150611726() {
        return new A3150611726();
    }

    /**
     * Create an instance of {@link HeatsinksheatsinkAcc }
     * 
     */
    public HeatsinksheatsinkAcc createHeatsinksheatsinkAcc() {
        return new HeatsinksheatsinkAcc();
    }

    /**
     * Create an instance of {@link ExternalDocument }
     * 
     */
    public ExternalDocument createExternalDocument() {
        return new ExternalDocument();
    }

    /**
     * Create an instance of {@link Substance }
     * 
     */
    public Substance createSubstance() {
        return new Substance();
    }

    /**
     * Create an instance of {@link Specification }
     * 
     */
    public Specification createSpecification() {
        return new Specification();
    }

    /**
     * Create an instance of {@link JItemRevisionRootIccPrivate }
     * 
     */
    public JItemRevisionRootIccPrivate createJItemRevisionRootIccPrivate() {
        return new JItemRevisionRootIccPrivate();
    }

    /**
     * Create an instance of {@link Packaging }
     * 
     */
    public Packaging createPackaging() {
        return new Packaging();
    }

    /**
     * Create an instance of {@link Label }
     * 
     */
    public Label createLabel() {
        return new Label();
    }

    /**
     * Create an instance of {@link Socket }
     * 
     */
    public Socket createSocket() {
        return new Socket();
    }

    /**
     * Create an instance of {@link Thermist }
     * 
     */
    public Thermist createThermist() {
        return new Thermist();
    }

    /**
     * Create an instance of {@link ChangeOrder }
     * 
     */
    public ChangeOrder createChangeOrder() {
        return new ChangeOrder();
    }

    /**
     * Create an instance of {@link Summaries }
     * 
     */
    public Summaries createSummaries() {
        return new Summaries();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PartParent }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "partParent")
    public JAXBElement<PartParent> createPartParent(PartParent value) {
        return new JAXBElement<PartParent>(_PartParent_QNAME, PartParent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Fg }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "fg")
    public JAXBElement<Fg> createFg(Fg value) {
        return new JAXBElement<Fg>(_Fg_QNAME, Fg.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SOPDocument }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "sOPDocument")
    public JAXBElement<SOPDocument> createSOPDocument(SOPDocument value) {
        return new JAXBElement<SOPDocument>(_SOPDocument_QNAME, SOPDocument.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LiteratureReferences }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "literatureReferences")
    public JAXBElement<LiteratureReferences> createLiteratureReferences(LiteratureReferences value) {
        return new JAXBElement<LiteratureReferences>(_LiteratureReferences_QNAME, LiteratureReferences.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Circuitbreakers }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "circuitbreakers")
    public JAXBElement<Circuitbreakers> createCircuitbreakers(Circuitbreakers value) {
        return new JAXBElement<Circuitbreakers>(_Circuitbreakers_QNAME, Circuitbreakers.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AnalysisOfDataFromMoreThanOneS }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "analysisOfDataFromMoreThanOneS")
    public JAXBElement<AnalysisOfDataFromMoreThanOneS> createAnalysisOfDataFromMoreThanOneS(AnalysisOfDataFromMoreThanOneS value) {
        return new JAXBElement<AnalysisOfDataFromMoreThanOneS>(_AnalysisOfDataFromMoreThanOneS_QNAME, AnalysisOfDataFromMoreThanOneS.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Electricalelectronic }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "electricalelectronic")
    public JAXBElement<Electricalelectronic> createElectricalelectronic(Electricalelectronic value) {
        return new JAXBElement<Electricalelectronic>(_Electricalelectronic_QNAME, Electricalelectronic.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExternalDocument }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "externalDocument")
    public JAXBElement<ExternalDocument> createExternalDocument(ExternalDocument value) {
        return new JAXBElement<ExternalDocument>(_ExternalDocument_QNAME, ExternalDocument.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Label }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "label")
    public JAXBElement<Label> createLabel(Label value) {
        return new JAXBElement<Label>(_Label_QNAME, Label.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Packaging }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "packaging")
    public JAXBElement<Packaging> createPackaging(Packaging value) {
        return new JAXBElement<Packaging>(_Packaging_QNAME, Packaging.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Specification }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "specification")
    public JAXBElement<Specification> createSpecification(Specification value) {
        return new JAXBElement<Specification>(_Specification_QNAME, Specification.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Summaries }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "summaries")
    public JAXBElement<Summaries> createSummaries(Summaries value) {
        return new JAXBElement<Summaries>(_Summaries_QNAME, Summaries.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Thermist }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "thermist")
    public JAXBElement<Thermist> createThermist(Thermist value) {
        return new JAXBElement<Thermist>(_Thermist_QNAME, Thermist.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DrugSunstance }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "drugSunstance")
    public JAXBElement<DrugSunstance> createDrugSunstance(DrugSunstance value) {
        return new JAXBElement<DrugSunstance>(_DrugSunstance_QNAME, DrugSunstance.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PartFamily }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "partFamily")
    public JAXBElement<PartFamily> createPartFamily(PartFamily value) {
        return new JAXBElement<PartFamily>(_PartFamily_QNAME, PartFamily.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DrugProduct }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "drugProduct")
    public JAXBElement<DrugProduct> createDrugProduct(DrugProduct value) {
        return new JAXBElement<DrugProduct>(_DrugProduct_QNAME, DrugProduct.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CableHarness }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "cableHarness")
    public JAXBElement<CableHarness> createCableHarness(CableHarness value) {
        return new JAXBElement<CableHarness>(_CableHarness_QNAME, CableHarness.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QualityDocuments }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "qualityDocuments")
    public JAXBElement<QualityDocuments> createQualityDocuments(QualityDocuments value) {
        return new JAXBElement<QualityDocuments>(_QualityDocuments_QNAME, QualityDocuments.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PCBSpecs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "pCBSpecs")
    public JAXBElement<PCBSpecs> createPCBSpecs(PCBSpecs value) {
        return new JAXBElement<PCBSpecs>(_PCBSpecs_QNAME, PCBSpecs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Pasresistors }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "pasresistors")
    public JAXBElement<Pasresistors> createPasresistors(Pasresistors value) {
        return new JAXBElement<Pasresistors>(_Pasresistors_QNAME, Pasresistors.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AdventitiousAgents }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "adventitiousAgents")
    public JAXBElement<AdventitiousAgents> createAdventitiousAgents(AdventitiousAgents value) {
        return new JAXBElement<AdventitiousAgents>(_AdventitiousAgents_QNAME, AdventitiousAgents.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MedicalDevice }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "medicalDevice")
    public JAXBElement<MedicalDevice> createMedicalDevice(MedicalDevice value) {
        return new JAXBElement<MedicalDevice>(_MedicalDevice_QNAME, MedicalDevice.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DisfreqCtrlosccrystal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "disfreqCtrlosccrystal")
    public JAXBElement<DisfreqCtrlosccrystal> createDisfreqCtrlosccrystal(DisfreqCtrlosccrystal value) {
        return new JAXBElement<DisfreqCtrlosccrystal>(_DisfreqCtrlosccrystal_QNAME, DisfreqCtrlosccrystal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Dhf }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "dhf")
    public JAXBElement<Dhf> createDhf(Dhf value) {
        return new JAXBElement<Dhf>(_Dhf_QNAME, Dhf.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InternalDocument }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "internalDocument")
    public JAXBElement<InternalDocument> createInternalDocument(InternalDocument value) {
        return new JAXBElement<InternalDocument>(_InternalDocument_QNAME, InternalDocument.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Pasinductorscoilschoke }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "pasinductorscoilschoke")
    public JAXBElement<Pasinductorscoilschoke> createPasinductorscoilschoke(Pasinductorscoilschoke value) {
        return new JAXBElement<Pasinductorscoilschoke>(_Pasinductorscoilschoke_QNAME, Pasinductorscoilschoke.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Pascapacitors }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "pascapacitors")
    public JAXBElement<Pascapacitors> createPascapacitors(Pascapacitors value) {
        return new JAXBElement<Pascapacitors>(_Pascapacitors_QNAME, Pascapacitors.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Component }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "component")
    public JAXBElement<Component> createComponent(Component value) {
        return new JAXBElement<Component>(_Component_QNAME, Component.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link L7Linear }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "l7Linear")
    public JAXBElement<L7Linear> createL7Linear(L7Linear value) {
        return new JAXBElement<L7Linear>(_L7Linear_QNAME, L7Linear.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Wizard }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "wizard")
    public JAXBElement<Wizard> createWizard(Wizard value) {
        return new JAXBElement<Wizard>(_Wizard_QNAME, Wizard.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PasbeadsleeveFerrite }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "pasbeadsleeveFerrite")
    public JAXBElement<PasbeadsleeveFerrite> createPasbeadsleeveFerrite(PasbeadsleeveFerrite value) {
        return new JAXBElement<PasbeadsleeveFerrite>(_PasbeadsleeveFerrite_QNAME, PasbeadsleeveFerrite.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PowerSupply }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "powerSupply")
    public JAXBElement<PowerSupply> createPowerSupply(PowerSupply value) {
        return new JAXBElement<PowerSupply>(_PowerSupply_QNAME, PowerSupply.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Resistor }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "resistor")
    public JAXBElement<Resistor> createResistor(Resistor value) {
        return new JAXBElement<Resistor>(_Resistor_QNAME, Resistor.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConnectorPower }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "connectorPower")
    public JAXBElement<ConnectorPower> createConnectorPower(ConnectorPower value) {
        return new JAXBElement<ConnectorPower>(_ConnectorPower_QNAME, ConnectorPower.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ComputerAccessory }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "computerAccessory")
    public JAXBElement<ComputerAccessory> createComputerAccessory(ComputerAccessory value) {
        return new JAXBElement<ComputerAccessory>(_ComputerAccessory_QNAME, ComputerAccessory.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link KitFg }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "kitFg")
    public JAXBElement<KitFg> createKitFg(KitFg value) {
        return new JAXBElement<KitFg>(_KitFg_QNAME, KitFg.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Regulatoryadmin }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "regulatoryadmin")
    public JAXBElement<Regulatoryadmin> createRegulatoryadmin(Regulatoryadmin value) {
        return new JAXBElement<Regulatoryadmin>(_Regulatoryadmin_QNAME, Regulatoryadmin.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SMSDocumentofExternalOrigin }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "sMSDocumentofExternalOrigin")
    public JAXBElement<SMSDocumentofExternalOrigin> createSMSDocumentofExternalOrigin(SMSDocumentofExternalOrigin value) {
        return new JAXBElement<SMSDocumentofExternalOrigin>(_SMSDocumentofExternalOrigin_QNAME, SMSDocumentofExternalOrigin.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Icasic }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "icasic")
    public JAXBElement<Icasic> createIcasic(Icasic value) {
        return new JAXBElement<Icasic>(_Icasic_QNAME, Icasic.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Chemical }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "chemical")
    public JAXBElement<Chemical> createChemical(Chemical value) {
        return new JAXBElement<Chemical>(_Chemical_QNAME, Chemical.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Folder }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "folder")
    public JAXBElement<Folder> createFolder(Folder value) {
        return new JAXBElement<Folder>(_Folder_QNAME, Folder.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Drive }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "drive")
    public JAXBElement<Drive> createDrive(Drive value) {
        return new JAXBElement<Drive>(_Drive_QNAME, Drive.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Legacy }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "legacy")
    public JAXBElement<Legacy> createLegacy(Legacy value) {
        return new JAXBElement<Legacy>(_Legacy_QNAME, Legacy.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link JItemRevisionVersion }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "j_ItemRevisionVersion")
    public JAXBElement<JItemRevisionVersion> createJItemRevisionVersion(JItemRevisionVersion value) {
        return new JAXBElement<JItemRevisionVersion>(_JItemRevisionVersion_QNAME, JItemRevisionVersion.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Switch }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "switch")
    public JAXBElement<Switch> createSwitch(Switch value) {
        return new JAXBElement<Switch>(_Switch_QNAME, Switch.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Storage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "storage")
    public JAXBElement<Storage> createStorage(Storage value) {
        return new JAXBElement<Storage>(_Storage_QNAME, Storage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Transformer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "transformer")
    public JAXBElement<Transformer> createTransformer(Transformer value) {
        return new JAXBElement<Transformer>(_Transformer_QNAME, Transformer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ToxicologyStudyReports }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "toxicologyStudyReports")
    public JAXBElement<ToxicologyStudyReports> createToxicologyStudyReports(ToxicologyStudyReports value) {
        return new JAXBElement<ToxicologyStudyReports>(_ToxicologyStudyReports_QNAME, ToxicologyStudyReports.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link HeatsinksheatsinkAcc }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "heatsinksheatsinkAcc")
    public JAXBElement<HeatsinksheatsinkAcc> createHeatsinksheatsinkAcc(HeatsinksheatsinkAcc value) {
        return new JAXBElement<HeatsinksheatsinkAcc>(_HeatsinksheatsinkAcc_QNAME, HeatsinksheatsinkAcc.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Processes }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "processes")
    public JAXBElement<Processes> createProcesses(Processes value) {
        return new JAXBElement<Processes>(_Processes_QNAME, Processes.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RangePart }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "rangePart")
    public JAXBElement<RangePart> createRangePart(RangePart value) {
        return new JAXBElement<RangePart>(_RangePart_QNAME, RangePart.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChangeOrder }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "changeOrder")
    public JAXBElement<ChangeOrder> createChangeOrder(ChangeOrder value) {
        return new JAXBElement<ChangeOrder>(_ChangeOrder_QNAME, ChangeOrder.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Socket }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "socket")
    public JAXBElement<Socket> createSocket(Socket value) {
        return new JAXBElement<Socket>(_Socket_QNAME, Socket.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PackageAssembly }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "packageAssembly")
    public JAXBElement<PackageAssembly> createPackageAssembly(PackageAssembly value) {
        return new JAXBElement<PackageAssembly>(_PackageAssembly_QNAME, PackageAssembly.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link HoverBoard }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "hoverBoard")
    public JAXBElement<HoverBoard> createHoverBoard(HoverBoard value) {
        return new JAXBElement<HoverBoard>(_HoverBoard_QNAME, HoverBoard.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Disrectifswitchdiode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "disrectifswitchdiode")
    public JAXBElement<Disrectifswitchdiode> createDisrectifswitchdiode(Disrectifswitchdiode value) {
        return new JAXBElement<Disrectifswitchdiode>(_Disrectifswitchdiode_QNAME, Disrectifswitchdiode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SOP }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "sOP")
    public JAXBElement<SOP> createSOP(SOP value) {
        return new JAXBElement<SOP>(_SOP_QNAME, SOP.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Casing }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "casing")
    public JAXBElement<Casing> createCasing(Casing value) {
        return new JAXBElement<Casing>(_Casing_QNAME, Casing.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Cable }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "cable")
    public JAXBElement<Cable> createCable(Cable value) {
        return new JAXBElement<Cable>(_Cable_QNAME, Cable.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Spare444 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "spare444")
    public JAXBElement<Spare444> createSpare444(Spare444 value) {
        return new JAXBElement<Spare444>(_Spare444_QNAME, Spare444 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link C3Convex }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "c3Convex")
    public JAXBElement<C3Convex> createC3Convex(C3Convex value) {
        return new JAXBElement<C3Convex>(_C3Convex_QNAME, C3Convex.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegulatoryDocuments }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "regulatoryDocuments")
    public JAXBElement<RegulatoryDocuments> createRegulatoryDocuments(RegulatoryDocuments value) {
        return new JAXBElement<RegulatoryDocuments>(_RegulatoryDocuments_QNAME, RegulatoryDocuments.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link COMPResistor }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "cOMPResistor")
    public JAXBElement<COMPResistor> createCOMPResistor(COMPResistor value) {
        return new JAXBElement<COMPResistor>(_COMPResistor_QNAME, COMPResistor.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Clinical }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "clinical")
    public JAXBElement<Clinical> createClinical(Clinical value) {
        return new JAXBElement<Clinical>(_Clinical_QNAME, Clinical.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Server }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "server")
    public JAXBElement<Server> createServer(Server value) {
        return new JAXBElement<Server>(_Server_QNAME, Server.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Cell }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "cell")
    public JAXBElement<Cell> createCell(Cell value) {
        return new JAXBElement<Cell>(_Cell_QNAME, Cell.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QualityofProducts }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "qualityofProducts")
    public JAXBElement<QualityofProducts> createQualityofProducts(QualityofProducts value) {
        return new JAXBElement<QualityofProducts>(_QualityofProducts_QNAME, QualityofProducts.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApplicantInformation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "applicantInformation")
    public JAXBElement<ApplicantInformation> createApplicantInformation(ApplicantInformation value) {
        return new JAXBElement<ApplicantInformation>(_ApplicantInformation_QNAME, ApplicantInformation.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Microprocessorsmicroprocessors }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "microprocessorsmicroprocessors")
    public JAXBElement<Microprocessorsmicroprocessors> createMicroprocessorsmicroprocessors(Microprocessorsmicroprocessors value) {
        return new JAXBElement<Microprocessorsmicroprocessors>(_Microprocessorsmicroprocessors_QNAME, Microprocessorsmicroprocessors.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Dmr }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "dmr")
    public JAXBElement<Dmr> createDmr(Dmr value) {
        return new JAXBElement<Dmr>(_Dmr_QNAME, Dmr.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Datasheets }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "datasheets")
    public JAXBElement<Datasheets> createDatasheets(Datasheets value) {
        return new JAXBElement<Datasheets>(_Datasheets_QNAME, Datasheets.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ZtestItemClass }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "ztestItemClass")
    public JAXBElement<ZtestItemClass> createZtestItemClass(ZtestItemClass value) {
        return new JAXBElement<ZtestItemClass>(_ZtestItemClass_QNAME, ZtestItemClass.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Model }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "model")
    public JAXBElement<Model> createModel(Model value) {
        return new JAXBElement<Model>(_Model_QNAME, Model.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link HumanPharmacokineticPkStudies }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "humanPharmacokineticPkStudies")
    public JAXBElement<HumanPharmacokineticPkStudies> createHumanPharmacokineticPkStudies(HumanPharmacokineticPkStudies value) {
        return new JAXBElement<HumanPharmacokineticPkStudies>(_HumanPharmacokineticPkStudies_QNAME, HumanPharmacokineticPkStudies.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IcdigitalLogic }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "icdigitalLogic")
    public JAXBElement<IcdigitalLogic> createIcdigitalLogic(IcdigitalLogic value) {
        return new JAXBElement<IcdigitalLogic>(_IcdigitalLogic_QNAME, IcdigitalLogic.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Adapters }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "adapters")
    public JAXBElement<Adapters> createAdapters(Adapters value) {
        return new JAXBElement<Adapters>(_Adapters_QNAME, Adapters.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConnectorPbMounted }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "connectorPbMounted")
    public JAXBElement<ConnectorPbMounted> createConnectorPbMounted(ConnectorPbMounted value) {
        return new JAXBElement<ConnectorPbMounted>(_ConnectorPbMounted_QNAME, ConnectorPbMounted.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Icmemoryromflash }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "icmemoryromflash")
    public JAXBElement<Icmemoryromflash> createIcmemoryromflash(Icmemoryromflash value) {
        return new JAXBElement<Icmemoryromflash>(_Icmemoryromflash_QNAME, Icmemoryromflash.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConnectorheaderAddMal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "connectorheaderAddMal")
    public JAXBElement<ConnectorheaderAddMal> createConnectorheaderAddMal(ConnectorheaderAddMal value) {
        return new JAXBElement<ConnectorheaderAddMal>(_ConnectorheaderAddMal_QNAME, ConnectorheaderAddMal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SheetMetal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "sheetMetal")
    public JAXBElement<SheetMetal> createSheetMetal(SheetMetal value) {
        return new JAXBElement<SheetMetal>(_SheetMetal_QNAME, SheetMetal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CellStack }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "cellStack")
    public JAXBElement<CellStack> createCellStack(CellStack value) {
        return new JAXBElement<CellStack>(_CellStack_QNAME, CellStack.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Nonclinical }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "nonclinical")
    public JAXBElement<Nonclinical> createNonclinical(Nonclinical value) {
        return new JAXBElement<Nonclinical>(_Nonclinical_QNAME, Nonclinical.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Memory }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "memory")
    public JAXBElement<Memory> createMemory(Memory value) {
        return new JAXBElement<Memory>(_Memory_QNAME, Memory.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OtherStudyReports }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "otherStudyReports")
    public JAXBElement<OtherStudyReports> createOtherStudyReports(OtherStudyReports value) {
        return new JAXBElement<OtherStudyReports>(_OtherStudyReports_QNAME, OtherStudyReports.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Kit }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "kit")
    public JAXBElement<Kit> createKit(Kit value) {
        return new JAXBElement<Kit>(_Kit_QNAME, Kit.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AgileWizard }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "agileWizard")
    public JAXBElement<AgileWizard> createAgileWizard(AgileWizard value) {
        return new JAXBElement<AgileWizard>(_AgileWizard_QNAME, AgileWizard.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Substance }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "substance")
    public JAXBElement<Substance> createSubstance(Substance value) {
        return new JAXBElement<Substance>(_Substance_QNAME, Substance.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Documentgeneric }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "documentgeneric")
    public JAXBElement<Documentgeneric> createDocumentgeneric(Documentgeneric value) {
        return new JAXBElement<Documentgeneric>(_Documentgeneric_QNAME, Documentgeneric.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Regulatorysubmission }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "regulatorysubmission")
    public JAXBElement<Regulatorysubmission> createRegulatorysubmission(Regulatorysubmission value) {
        return new JAXBElement<Regulatorysubmission>(_Regulatorysubmission_QNAME, Regulatorysubmission.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link HumanPharmacodynamicPd }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "humanPharmacodynamicPd")
    public JAXBElement<HumanPharmacodynamicPd> createHumanPharmacodynamicPd(HumanPharmacodynamicPd value) {
        return new JAXBElement<HumanPharmacodynamicPd>(_HumanPharmacodynamicPd_QNAME, HumanPharmacodynamicPd.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Pcbpwbs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "pcbpwbs")
    public JAXBElement<Pcbpwbs> createPcbpwbs(Pcbpwbs value) {
        return new JAXBElement<Pcbpwbs>(_Pcbpwbs_QNAME, Pcbpwbs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConnectorAdapters }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "connectorAdapters")
    public JAXBElement<ConnectorAdapters> createConnectorAdapters(ConnectorAdapters value) {
        return new JAXBElement<ConnectorAdapters>(_ConnectorAdapters_QNAME, ConnectorAdapters.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Nuts }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "nuts")
    public JAXBElement<Nuts> createNuts(Nuts value) {
        return new JAXBElement<Nuts>(_Nuts_QNAME, Nuts.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentParent }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "documentParent")
    public JAXBElement<DocumentParent> createDocumentParent(DocumentParent value) {
        return new JAXBElement<DocumentParent>(_DocumentParent_QNAME, DocumentParent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link HearRateMonitor }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "hearRateMonitor")
    public JAXBElement<HearRateMonitor> createHearRateMonitor(HearRateMonitor value) {
        return new JAXBElement<HearRateMonitor>(_HearRateMonitor_QNAME, HearRateMonitor.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EquipmentFixturesTools }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "equipmentFixturesTools")
    public JAXBElement<EquipmentFixturesTools> createEquipmentFixturesTools(EquipmentFixturesTools value) {
        return new JAXBElement<EquipmentFixturesTools>(_EquipmentFixturesTools_QNAME, EquipmentFixturesTools.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Manufacturerspinalelement }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "manufacturerspinalelement")
    public JAXBElement<Manufacturerspinalelement> createManufacturerspinalelement(Manufacturerspinalelement value) {
        return new JAXBElement<Manufacturerspinalelement>(_Manufacturerspinalelement_QNAME, Manufacturerspinalelement.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Document }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "document")
    public JAXBElement<Document> createDocument(Document value) {
        return new JAXBElement<Document>(_Document_QNAME, Document.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Battery }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "battery")
    public JAXBElement<Battery> createBattery(Battery value) {
        return new JAXBElement<Battery>(_Battery_QNAME, Battery.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubstanceGroup }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "substanceGroup")
    public JAXBElement<SubstanceGroup> createSubstanceGroup(SubstanceGroup value) {
        return new JAXBElement<SubstanceGroup>(_SubstanceGroup_QNAME, SubstanceGroup.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LiteratureReference }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "literatureReference")
    public JAXBElement<LiteratureReference> createLiteratureReference(LiteratureReference value) {
        return new JAXBElement<LiteratureReference>(_LiteratureReference_QNAME, LiteratureReference.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Distransistor }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "distransistor")
    public JAXBElement<Distransistor> createDistransistor(Distransistor value) {
        return new JAXBElement<Distransistor>(_Distransistor_QNAME, Distransistor.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TestAttributesClass }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "testAttributesClass")
    public JAXBElement<TestAttributesClass> createTestAttributesClass(TestAttributesClass value) {
        return new JAXBElement<TestAttributesClass>(_TestAttributesClass_QNAME, TestAttributesClass.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Declaration }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "declaration")
    public JAXBElement<Declaration> createDeclaration(Declaration value) {
        return new JAXBElement<Declaration>(_Declaration_QNAME, Declaration.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QualityOverallSummary }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "qualityOverallSummary")
    public JAXBElement<QualityOverallSummary> createQualityOverallSummary(QualityOverallSummary value) {
        return new JAXBElement<QualityOverallSummary>(_QualityOverallSummary_QNAME, QualityOverallSummary.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IngredientN }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "ingredientN")
    public JAXBElement<IngredientN> createIngredientN(IngredientN value) {
        return new JAXBElement<IngredientN>(_IngredientN_QNAME, IngredientN.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EfficacyAndSafety }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "efficacyAndSafety")
    public JAXBElement<EfficacyAndSafety> createEfficacyAndSafety(EfficacyAndSafety value) {
        return new JAXBElement<EfficacyAndSafety>(_EfficacyAndSafety_QNAME, EfficacyAndSafety.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Disled }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "disled")
    public JAXBElement<Disled> createDisled(Disled value) {
        return new JAXBElement<Disled>(_Disled_QNAME, Disled.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Cto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "cto")
    public JAXBElement<Cto> createCto(Cto value) {
        return new JAXBElement<Cto>(_Cto_QNAME, Cto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Module }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "module")
    public JAXBElement<Module> createModule(Module value) {
        return new JAXBElement<Module>(_Module_QNAME, Module.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProductProcedures }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "productProcedures")
    public JAXBElement<ProductProcedures> createProductProcedures(ProductProcedures value) {
        return new JAXBElement<ProductProcedures>(_ProductProcedures_QNAME, ProductProcedures.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Quality }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "quality")
    public JAXBElement<Quality> createQuality(Quality value) {
        return new JAXBElement<Quality>(_Quality_QNAME, Quality.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AdministrativeInformation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "administrativeInformation")
    public JAXBElement<AdministrativeInformation> createAdministrativeInformation(AdministrativeInformation value) {
        return new JAXBElement<AdministrativeInformation>(_AdministrativeInformation_QNAME, AdministrativeInformation.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FuseComponents }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "fuseComponents")
    public JAXBElement<FuseComponents> createFuseComponents(FuseComponents value) {
        return new JAXBElement<FuseComponents>(_FuseComponents_QNAME, FuseComponents.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Part }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "part")
    public JAXBElement<Part> createPart(Part value) {
        return new JAXBElement<Part>(_Part_QNAME, Part.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Circuitbreaker }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "circuitbreaker")
    public JAXBElement<Circuitbreaker> createCircuitbreaker(Circuitbreaker value) {
        return new JAXBElement<Circuitbreaker>(_Circuitbreaker_QNAME, Circuitbreaker.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Rspl }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "rspl")
    public JAXBElement<Rspl> createRspl(Rspl value) {
        return new JAXBElement<Rspl>(_Rspl_QNAME, Rspl.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link A3150611726 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "a3150611726")
    public JAXBElement<A3150611726> createA3150611726(A3150611726 value) {
        return new JAXBElement<A3150611726>(_A3150611726_QNAME, A3150611726 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FormulaN }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "formulaN")
    public JAXBElement<FormulaN> createFormulaN(FormulaN value) {
        return new JAXBElement<FormulaN>(_FormulaN_QNAME, FormulaN.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SOPProcedure }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "sOPProcedure")
    public JAXBElement<SOPProcedure> createSOPProcedure(SOPProcedure value) {
        return new JAXBElement<SOPProcedure>(_SOPProcedure_QNAME, SOPProcedure.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link JItemRevisionRootIccPrivate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "j_ItemRevisionRootIccPrivate")
    public JAXBElement<JItemRevisionRootIccPrivate> createJItemRevisionRootIccPrivate(JItemRevisionRootIccPrivate value) {
        return new JAXBElement<JItemRevisionRootIccPrivate>(_JItemRevisionRootIccPrivate_QNAME, JItemRevisionRootIccPrivate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Internalfolder }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "internalfolder")
    public JAXBElement<Internalfolder> createInternalfolder(Internalfolder value) {
        return new JAXBElement<Internalfolder>(_Internalfolder_QNAME, Internalfolder.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LabelingGroup }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "labelingGroup")
    public JAXBElement<LabelingGroup> createLabelingGroup(LabelingGroup value) {
        return new JAXBElement<LabelingGroup>(_LabelingGroup_QNAME, LabelingGroup.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MechanicalComponent }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "mechanicalComponent")
    public JAXBElement<MechanicalComponent> createMechanicalComponent(MechanicalComponent value) {
        return new JAXBElement<MechanicalComponent>(_MechanicalComponent_QNAME, MechanicalComponent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ElectronicSubassemblies }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "electronicSubassemblies")
    public JAXBElement<ElectronicSubassemblies> createElectronicSubassemblies(ElectronicSubassemblies value) {
        return new JAXBElement<ElectronicSubassemblies>(_ElectronicSubassemblies_QNAME, ElectronicSubassemblies.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WireAssemblySet }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "wireAssemblySet")
    public JAXBElement<WireAssemblySet> createWireAssemblySet(WireAssemblySet value) {
        return new JAXBElement<WireAssemblySet>(_WireAssemblySet_QNAME, WireAssemblySet.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SMSDocument }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "sMSDocument")
    public JAXBElement<SMSDocument> createSMSDocument(SMSDocument value) {
        return new JAXBElement<SMSDocument>(_SMSDocument_QNAME, SMSDocument.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FinishedGood }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "finishedGood")
    public JAXBElement<FinishedGood> createFinishedGood(FinishedGood value) {
        return new JAXBElement<FinishedGood>(_FinishedGood_QNAME, FinishedGood.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Fbom }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "fbom")
    public JAXBElement<Fbom> createFbom(Fbom value) {
        return new JAXBElement<Fbom>(_Fbom_QNAME, Fbom.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Newdhf }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "newdhf")
    public JAXBElement<Newdhf> createNewdhf(Newdhf value) {
        return new JAXBElement<Newdhf>(_Newdhf_QNAME, Newdhf.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QualityInformation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "qualityInformation")
    public JAXBElement<QualityInformation> createQualityInformation(QualityInformation value) {
        return new JAXBElement<QualityInformation>(_QualityInformation_QNAME, QualityInformation.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Labeling }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "labeling")
    public JAXBElement<Labeling> createLabeling(Labeling value) {
        return new JAXBElement<Labeling>(_Labeling_QNAME, Labeling.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Feature }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "feature")
    public JAXBElement<Feature> createFeature(Feature value) {
        return new JAXBElement<Feature>(_Feature_QNAME, Feature.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FilleGoodssa }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "filleGoodssa")
    public JAXBElement<FilleGoodssa> createFilleGoodssa(FilleGoodssa value) {
        return new JAXBElement<FilleGoodssa>(_FilleGoodssa_QNAME, FilleGoodssa.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Firmware }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "firmware")
    public JAXBElement<Firmware> createFirmware(Firmware value) {
        return new JAXBElement<Firmware>(_Firmware_QNAME, Firmware.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OemCdRoms }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "oemCdRoms")
    public JAXBElement<OemCdRoms> createOemCdRoms(OemCdRoms value) {
        return new JAXBElement<OemCdRoms>(_OemCdRoms_QNAME, OemCdRoms.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Power }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "power")
    public JAXBElement<Power> createPower(Power value) {
        return new JAXBElement<Power>(_Power_QNAME, Power.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link C7Microconvex }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "c7Microconvex")
    public JAXBElement<C7Microconvex> createC7Microconvex(C7Microconvex value) {
        return new JAXBElement<C7Microconvex>(_C7Microconvex_QNAME, C7Microconvex.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VirtualPhasedArray }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "virtualPhasedArray")
    public JAXBElement<VirtualPhasedArray> createVirtualPhasedArray(VirtualPhasedArray value) {
        return new JAXBElement<VirtualPhasedArray>(_VirtualPhasedArray_QNAME, VirtualPhasedArray.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SpecificationDocuments }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "specificationDocuments")
    public JAXBElement<SpecificationDocuments> createSpecificationDocuments(SpecificationDocuments value) {
        return new JAXBElement<SpecificationDocuments>(_SpecificationDocuments_QNAME, SpecificationDocuments.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TransistorFET }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "transistorFET")
    public JAXBElement<TransistorFET> createTransistorFET(TransistorFET value) {
        return new JAXBElement<TransistorFET>(_TransistorFET_QNAME, TransistorFET.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link COMPCapacitorALTantalum }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "cOMPCapacitorALTantalum")
    public JAXBElement<COMPCapacitorALTantalum> createCOMPCapacitorALTantalum(COMPCapacitorALTantalum value) {
        return new JAXBElement<COMPCapacitorALTantalum>(_COMPCapacitorALTantalum_QNAME, COMPCapacitorALTantalum.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Screws }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "screws")
    public JAXBElement<Screws> createScrews(Screws value) {
        return new JAXBElement<Screws>(_Screws_QNAME, Screws.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Fan }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "fan")
    public JAXBElement<Fan> createFan(Fan value) {
        return new JAXBElement<Fan>(_Fan_QNAME, Fan.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Pwbpwba }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "pwbpwba")
    public JAXBElement<Pwbpwba> createPwbpwba(Pwbpwba value) {
        return new JAXBElement<Pwbpwba>(_Pwbpwba_QNAME, Pwbpwba.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ItemSku }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "itemSku")
    public JAXBElement<ItemSku> createItemSku(ItemSku value) {
        return new JAXBElement<ItemSku>(_ItemSku_QNAME, ItemSku.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BiopharmaceuticStudyReports }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "biopharmaceuticStudyReports")
    public JAXBElement<BiopharmaceuticStudyReports> createBiopharmaceuticStudyReports(BiopharmaceuticStudyReports value) {
        return new JAXBElement<BiopharmaceuticStudyReports>(_BiopharmaceuticStudyReports_QNAME, BiopharmaceuticStudyReports.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ElectromechanicalAssemblies }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "electromechanicalAssemblies")
    public JAXBElement<ElectromechanicalAssemblies> createElectromechanicalAssemblies(ElectromechanicalAssemblies value) {
        return new JAXBElement<ElectromechanicalAssemblies>(_ElectromechanicalAssemblies_QNAME, ElectromechanicalAssemblies.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "CategoryCode", scope = JItemRevisionVersion.class)
    public JAXBElement<String> createJItemRevisionVersionCategoryCode(String value) {
        return new JAXBElement<String>(_JItemRevisionVersionCategoryCode_QNAME, String.class, JItemRevisionVersion.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/", name = "VersionId", scope = JItemRevisionVersion.class, defaultValue = "-1")
    public JAXBElement<Long> createJItemRevisionVersionVersionId(Long value) {
        return new JAXBElement<Long>(_JItemRevisionVersionVersionId_QNAME, Long.class, JItemRevisionVersion.class, value);
    }

}
