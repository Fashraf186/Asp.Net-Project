@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts;
