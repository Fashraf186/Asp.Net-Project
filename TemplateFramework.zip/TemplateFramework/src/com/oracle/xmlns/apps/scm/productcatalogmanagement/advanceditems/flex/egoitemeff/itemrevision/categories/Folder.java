
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.itemrevision.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.itemrevision.contexts.RevAttr;


/**
 * <p>Java class for Folder complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Folder">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/}j_ItemRevisionRootIccPrivate">
 *       &lt;sequence>
 *         &lt;element name="RevAttr" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/contexts/}RevAttr" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Folder", propOrder = {
    "revAttr"
})
public class Folder
    extends JItemRevisionRootIccPrivate
{

    @XmlElement(name = "RevAttr")
    protected RevAttr revAttr;

    /**
     * Gets the value of the revAttr property.
     * 
     * @return
     *     possible object is
     *     {@link RevAttr }
     *     
     */
    public RevAttr getRevAttr() {
        return revAttr;
    }

    /**
     * Sets the value of the revAttr property.
     * 
     * @param value
     *     allowed object is
     *     {@link RevAttr }
     *     
     */
    public void setRevAttr(RevAttr value) {
        this.revAttr = value;
    }

}
