
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.MedicalDeviceDetails;


/**
 * <p>Java class for MedicalDevice complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MedicalDevice">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Quality">
 *       &lt;sequence>
 *         &lt;element name="MedicalDeviceDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}MedicalDeviceDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MedicalDevice", propOrder = {
    "medicalDeviceDetails"
})
public class MedicalDevice
    extends Quality
{

    @XmlElement(name = "MedicalDeviceDetails")
    protected MedicalDeviceDetails medicalDeviceDetails;

    /**
     * Gets the value of the medicalDeviceDetails property.
     * 
     * @return
     *     possible object is
     *     {@link MedicalDeviceDetails }
     *     
     */
    public MedicalDeviceDetails getMedicalDeviceDetails() {
        return medicalDeviceDetails;
    }

    /**
     * Sets the value of the medicalDeviceDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link MedicalDeviceDetails }
     *     
     */
    public void setMedicalDeviceDetails(MedicalDeviceDetails value) {
        this.medicalDeviceDetails = value;
    }

}
