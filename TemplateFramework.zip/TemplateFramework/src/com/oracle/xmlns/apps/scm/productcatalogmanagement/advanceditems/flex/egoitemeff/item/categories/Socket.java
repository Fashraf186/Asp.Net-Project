
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.SocketDetails;


/**
 * <p>Java class for Socket complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Socket">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Part">
 *       &lt;sequence>
 *         &lt;element name="SocketDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}SocketDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Socket", propOrder = {
    "socketDetails"
})
public class Socket
    extends Part
{

    @XmlElement(name = "SocketDetails")
    protected SocketDetails socketDetails;

    /**
     * Gets the value of the socketDetails property.
     * 
     * @return
     *     possible object is
     *     {@link SocketDetails }
     *     
     */
    public SocketDetails getSocketDetails() {
        return socketDetails;
    }

    /**
     * Sets the value of the socketDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link SocketDetails }
     *     
     */
    public void setSocketDetails(SocketDetails value) {
        this.socketDetails = value;
    }

}
