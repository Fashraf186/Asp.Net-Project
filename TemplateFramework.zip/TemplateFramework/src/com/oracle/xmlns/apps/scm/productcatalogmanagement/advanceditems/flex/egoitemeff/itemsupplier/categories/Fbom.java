
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.itemsupplier.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Fbom complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Fbom">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemSupplier/categories/}j_ItemSupplierRootIccPrivate">
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Fbom")
@XmlSeeAlso({
    PasbeadsleeveFerrite.class,
    PowerSupply.class,
    Fan.class,
    Model.class,
    Disled.class,
    ComputerAccessory.class,
    Adapters.class,
    ProductProcedures.class,
    Pwbpwba.class,
    IcdigitalLogic.class,
    ConnectorPower.class,
    Module.class,
    Icmemoryromflash.class,
    ConnectorPbMounted.class,
    Icasic.class,
    ConnectorheaderAddMal.class,
    ElectromechanicalAssemblies.class,
    FuseComponents.class,
    Drive.class,
    SheetMetal.class,
    Server.class,
    Distransistor.class,
    Feature.class,
    C7Microconvex.class,
    DisfreqCtrlosccrystal.class,
    Power.class,
    Firmware.class,
    OemCdRoms.class,
    Microprocessorsmicroprocessors.class,
    VirtualPhasedArray.class,
    Dhf.class,
    L7Linear.class,
    Pascapacitors.class,
    Pasinductorscoilschoke.class,
    Screws.class,
    Disrectifswitchdiode.class,
    Casing.class,
    MechanicalComponent.class,
    CableHarness.class,
    Cable.class,
    Spare444 .class,
    C3Convex.class,
    WireAssemblySet.class,
    ElectronicSubassemblies.class,
    Pcbpwbs.class,
    ConnectorAdapters.class,
    RegulatoryDocuments.class,
    HearRateMonitor.class,
    Nuts.class,
    Pasresistors.class,
    Manufacturerspinalelement.class,
    Circuitbreaker.class,
    Legacy.class,
    Memory.class,
    Battery.class,
    Rspl.class,
    Storage.class,
    Switch.class,
    Circuitbreakers.class,
    Kit.class,
    RangePart.class,
    Documentgeneric.class,
    Processes.class,
    A3150611726 .class,
    HeatsinksheatsinkAcc.class,
    Packaging.class,
    Label.class
})
public class Fbom
    extends JItemSupplierRootIccPrivate
{


}
