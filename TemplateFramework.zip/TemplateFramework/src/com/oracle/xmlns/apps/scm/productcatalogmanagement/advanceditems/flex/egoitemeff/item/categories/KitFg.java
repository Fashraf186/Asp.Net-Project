
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.Kit;


/**
 * <p>Java class for KitFg complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="KitFg">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}j_ItemRootIccPrivate">
 *       &lt;sequence>
 *         &lt;element name="Kit" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}Kit" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "KitFg", propOrder = {
    "kit"
})
public class KitFg
    extends JItemRootIccPrivate
{

    @XmlElement(name = "Kit")
    protected Kit kit;

    /**
     * Gets the value of the kit property.
     * 
     * @return
     *     possible object is
     *     {@link Kit }
     *     
     */
    public Kit getKit() {
        return kit;
    }

    /**
     * Sets the value of the kit property.
     * 
     * @param value
     *     allowed object is
     *     {@link Kit }
     *     
     */
    public void setKit(Kit value) {
        this.kit = value;
    }

}
