
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.COMPResistorDetails;


/**
 * <p>Java class for COMPResistor complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="COMPResistor">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Part">
 *       &lt;sequence>
 *         &lt;element name="COMPResistorDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}COMPResistorDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "COMPResistor", propOrder = {
    "compResistorDetails"
})
public class COMPResistor
    extends Part
{

    @XmlElement(name = "COMPResistorDetails")
    protected COMPResistorDetails compResistorDetails;

    /**
     * Gets the value of the compResistorDetails property.
     * 
     * @return
     *     possible object is
     *     {@link COMPResistorDetails }
     *     
     */
    public COMPResistorDetails getCOMPResistorDetails() {
        return compResistorDetails;
    }

    /**
     * Sets the value of the compResistorDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link COMPResistorDetails }
     *     
     */
    public void setCOMPResistorDetails(COMPResistorDetails value) {
        this.compResistorDetails = value;
    }

}
