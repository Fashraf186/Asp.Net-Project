
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.InternalDocumentDetails;


/**
 * <p>Java class for InternalDocument complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InternalDocument">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Document">
 *       &lt;sequence>
 *         &lt;element name="InternalDocumentDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}InternalDocumentDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InternalDocument", propOrder = {
    "internalDocumentDetails"
})
public class InternalDocument
    extends Document
{

    @XmlElement(name = "InternalDocumentDetails")
    protected InternalDocumentDetails internalDocumentDetails;

    /**
     * Gets the value of the internalDocumentDetails property.
     * 
     * @return
     *     possible object is
     *     {@link InternalDocumentDetails }
     *     
     */
    public InternalDocumentDetails getInternalDocumentDetails() {
        return internalDocumentDetails;
    }

    /**
     * Sets the value of the internalDocumentDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link InternalDocumentDetails }
     *     
     */
    public void setInternalDocumentDetails(InternalDocumentDetails value) {
        this.internalDocumentDetails = value;
    }

}
