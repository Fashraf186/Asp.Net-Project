
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.PartsDetails;


/**
 * <p>Java class for Part complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Part">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}j_ItemRootIccPrivate">
 *       &lt;sequence>
 *         &lt;element name="PartsDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}PartsDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Part", propOrder = {
    "partsDetails"
})
@XmlSeeAlso({
    TransistorFET.class,
    COMPCapacitorALTantalum.class,
    Wizard.class,
    COMPResistor.class,
    Transformer.class,
    AgileWizard.class,
    Electricalelectronic.class,
    Socket.class,
    Thermist.class
})
public class Part
    extends JItemRootIccPrivate
{

    @XmlElement(name = "PartsDetails")
    protected PartsDetails partsDetails;

    /**
     * Gets the value of the partsDetails property.
     * 
     * @return
     *     possible object is
     *     {@link PartsDetails }
     *     
     */
    public PartsDetails getPartsDetails() {
        return partsDetails;
    }

    /**
     * Sets the value of the partsDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartsDetails }
     *     
     */
    public void setPartsDetails(PartsDetails value) {
        this.partsDetails = value;
    }

}
