
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.MultiRow;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.TestAttributes;


/**
 * <p>Java class for TestAttributesClass complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TestAttributesClass">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}j_ItemRootIccPrivate">
 *       &lt;sequence>
 *         &lt;element name="MultiRow" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}MultiRow" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="TestAttributes" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}TestAttributes" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TestAttributesClass", propOrder = {
    "multiRow",
    "testAttributes"
})
public class TestAttributesClass
    extends JItemRootIccPrivate
{

    @XmlElement(name = "MultiRow")
    protected List<MultiRow> multiRow;
    @XmlElement(name = "TestAttributes")
    protected TestAttributes testAttributes;

    /**
     * Gets the value of the multiRow property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the multiRow property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMultiRow().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MultiRow }
     * 
     * 
     */
    public List<MultiRow> getMultiRow() {
        if (multiRow == null) {
            multiRow = new ArrayList<MultiRow>();
        }
        return this.multiRow;
    }

    /**
     * Gets the value of the testAttributes property.
     * 
     * @return
     *     possible object is
     *     {@link TestAttributes }
     *     
     */
    public TestAttributes getTestAttributes() {
        return testAttributes;
    }

    /**
     * Sets the value of the testAttributes property.
     * 
     * @param value
     *     allowed object is
     *     {@link TestAttributes }
     *     
     */
    public void setTestAttributes(TestAttributes value) {
        this.testAttributes = value;
    }

}
