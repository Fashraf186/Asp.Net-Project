
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.DatasheetsDetails;


/**
 * <p>Java class for Datasheets complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Datasheets">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Document">
 *       &lt;sequence>
 *         &lt;element name="DatasheetsDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}DatasheetsDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Datasheets", propOrder = {
    "datasheetsDetails"
})
public class Datasheets
    extends Document
{

    @XmlElement(name = "DatasheetsDetails")
    protected DatasheetsDetails datasheetsDetails;

    /**
     * Gets the value of the datasheetsDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DatasheetsDetails }
     *     
     */
    public DatasheetsDetails getDatasheetsDetails() {
        return datasheetsDetails;
    }

    /**
     * Sets the value of the datasheetsDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatasheetsDetails }
     *     
     */
    public void setDatasheetsDetails(DatasheetsDetails value) {
        this.datasheetsDetails = value;
    }

}
