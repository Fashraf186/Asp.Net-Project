
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.AdventitiousAgentsDetails;


/**
 * <p>Java class for AdventitiousAgents complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AdventitiousAgents">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Quality">
 *       &lt;sequence>
 *         &lt;element name="AdventitiousAgentsDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}AdventitiousAgentsDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AdventitiousAgents", propOrder = {
    "adventitiousAgentsDetails"
})
public class AdventitiousAgents
    extends Quality
{

    @XmlElement(name = "AdventitiousAgentsDetails")
    protected AdventitiousAgentsDetails adventitiousAgentsDetails;

    /**
     * Gets the value of the adventitiousAgentsDetails property.
     * 
     * @return
     *     possible object is
     *     {@link AdventitiousAgentsDetails }
     *     
     */
    public AdventitiousAgentsDetails getAdventitiousAgentsDetails() {
        return adventitiousAgentsDetails;
    }

    /**
     * Sets the value of the adventitiousAgentsDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdventitiousAgentsDetails }
     *     
     */
    public void setAdventitiousAgentsDetails(AdventitiousAgentsDetails value) {
        this.adventitiousAgentsDetails = value;
    }

}
