
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.ExternalDocumentDetails;


/**
 * <p>Java class for ExternalDocument complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ExternalDocument">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Document">
 *       &lt;sequence>
 *         &lt;element name="ExternalDocumentDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}ExternalDocumentDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ExternalDocument", propOrder = {
    "externalDocumentDetails"
})
public class ExternalDocument
    extends Document
{

    @XmlElement(name = "ExternalDocumentDetails")
    protected ExternalDocumentDetails externalDocumentDetails;

    /**
     * Gets the value of the externalDocumentDetails property.
     * 
     * @return
     *     possible object is
     *     {@link ExternalDocumentDetails }
     *     
     */
    public ExternalDocumentDetails getExternalDocumentDetails() {
        return externalDocumentDetails;
    }

    /**
     * Sets the value of the externalDocumentDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExternalDocumentDetails }
     *     
     */
    public void setExternalDocumentDetails(ExternalDocumentDetails value) {
        this.externalDocumentDetails = value;
    }

}
