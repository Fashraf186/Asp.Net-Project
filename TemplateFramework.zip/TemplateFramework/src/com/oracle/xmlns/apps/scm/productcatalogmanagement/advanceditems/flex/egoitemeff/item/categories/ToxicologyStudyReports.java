
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.item.contexts.ToxicologyStudyReportsDetails;


/**
 * <p>Java class for ToxicologyStudyReports complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ToxicologyStudyReports">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/}Nonclinical">
 *       &lt;sequence>
 *         &lt;element name="ToxicologyStudyReportsDetails" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/contexts/}ToxicologyStudyReportsDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ToxicologyStudyReports", propOrder = {
    "toxicologyStudyReportsDetails"
})
public class ToxicologyStudyReports
    extends Nonclinical
{

    @XmlElement(name = "ToxicologyStudyReportsDetails")
    protected ToxicologyStudyReportsDetails toxicologyStudyReportsDetails;

    /**
     * Gets the value of the toxicologyStudyReportsDetails property.
     * 
     * @return
     *     possible object is
     *     {@link ToxicologyStudyReportsDetails }
     *     
     */
    public ToxicologyStudyReportsDetails getToxicologyStudyReportsDetails() {
        return toxicologyStudyReportsDetails;
    }

    /**
     * Sets the value of the toxicologyStudyReportsDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link ToxicologyStudyReportsDetails }
     *     
     */
    public void setToxicologyStudyReportsDetails(ToxicologyStudyReportsDetails value) {
        this.toxicologyStudyReportsDetails = value;
    }

}
