
package com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.itemsupplier.categories;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.scm.productcatalogmanagement.advanceditems.flex.egoitemeff.itemsupplier.contexts.SItems;


/**
 * <p>Java class for j_ItemSupplierRootIccPrivate complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="j_ItemSupplierRootIccPrivate">
 *   &lt;complexContent>
 *     &lt;extension base="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemSupplier/categories/}j_RevisedItemSupplierAssociation">
 *       &lt;sequence>
 *         &lt;element name="ItemSupplierEFFBS_2DItemsPrivateVO" type="{http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemSupplier/contexts/}SItems" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "j_ItemSupplierRootIccPrivate", propOrder = {
    "itemSupplierEFFBS2DItemsPrivateVO"
})
@XmlSeeAlso({
    IngredientN.class,
    ZtestItemClass.class,
    Cto.class,
    KitFg.class,
    ItemSku.class,
    Folder.class,
    Chemical.class,
    FilleGoodssa.class,
    SubstanceGroup.class,
    TestAttributesClass.class,
    Component.class,
    HoverBoard.class,
    PackageAssembly.class,
    PartFamily.class,
    EquipmentFixturesTools.class,
    Fg.class,
    PartParent.class,
    DocumentParent.class,
    Declaration.class,
    Substance.class,
    Specification.class,
    Fbom.class,
    Part.class,
    FinishedGood.class,
    Document.class
})
public class JItemSupplierRootIccPrivate
    extends JRevisedItemSupplierAssociation
{

    @XmlElement(name = "ItemSupplierEFFBS_2DItemsPrivateVO")
    protected SItems itemSupplierEFFBS2DItemsPrivateVO;

    /**
     * Gets the value of the itemSupplierEFFBS2DItemsPrivateVO property.
     * 
     * @return
     *     possible object is
     *     {@link SItems }
     *     
     */
    public SItems getItemSupplierEFFBS2DItemsPrivateVO() {
        return itemSupplierEFFBS2DItemsPrivateVO;
    }

    /**
     * Sets the value of the itemSupplierEFFBS2DItemsPrivateVO property.
     * 
     * @param value
     *     allowed object is
     *     {@link SItems }
     *     
     */
    public void setItemSupplierEFFBS2DItemsPrivateVO(SItems value) {
        this.itemSupplierEFFBS2DItemsPrivateVO = value;
    }

}
